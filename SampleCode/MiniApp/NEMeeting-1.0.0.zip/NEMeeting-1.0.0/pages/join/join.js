import { prevent } from '../../utils/index'

Page({
  data: {
    debug: false,
    roomId: '559735229',
    nickName: 'winsan',
    username: '18720915657',
    password: '12345678',
    openCamera: false,
    openMicrophone: false,
    tag: '',
    appKey: '',
    baseDomain: '', // 请求的domain地址，可不填
    accountId: '',
    accountToken: '',
    loginTypeArr: [
      { value: 1, title: '账号密码登录' },
      { value: 2, title: 'token登录' },
      { value: 3, title: '匿名登录' },
    ],
    type: 1
  },
  onload() {
    wx.getAvailableAudioSources(res => {
      console.log(res, 'wx.getAvailableAudioSources')
    })
  },
  changeHandler(e) {
    const key = e.currentTarget.dataset.key
    this.setData({
      [key]: e.detail.value
    })
  },
  joinRoom: prevent(function() {
    if (!this.data.roomId) {
      wx.showToast({
        title: '请填写会议Id',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (!this.data.nickName) {
      wx.showToast({
        title: '请填写昵称',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (type == 1 && (!this.data.username || !this.data.password)) {
      wx.showToast({
        title: '请填写您的账号密码',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (type == 2 && (!this.data.accountToken || !this.data.accountId)) {
      wx.showToast({
        title: '请填写您的账号密码',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (!/^\d{1,12}$/.test(this.data.roomId)) {
      wx.showToast({
        title: '仅支持12位及以下纯数字',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (this.data.nickName && !/^[\u4e00-\u9fa5\da-zA-Z]{1,12}$/.test(this.data.nickName)) {
      wx.showToast({
        title: '仅支持12位及以下文本、字母及数字组合',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    const url = '/pages/meeting/index';
  
    const {
      debug,
      roomId,
      nickName,
      username,
      password,
      openCamera,
      openMicrophone,
      appKey,
      tag,
      type,
      accountId,
      baseDomain
    } = this.data;

    const queryParams = {
      debug,
      roomId,
      nickName,
      username,
      password,
      openCamera,
      openMicrophone,
      appKey,
      tag,
      type,
      accountId,
      accountToken: encodeURIComponent(this.data.accountToken),
      baseDomain
    };

    const finalUrl = Object.keys(queryParams).reduce((prev, cur) => {
      return `${prev}${prev === url ? '?' : '&'}${cur}=${queryParams[cur]}`
    }, url)
    wx.navigateTo({ url: finalUrl })
  }, 2000),
});
