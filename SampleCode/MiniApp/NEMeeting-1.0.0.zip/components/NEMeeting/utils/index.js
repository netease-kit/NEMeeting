export const uuid = () => Math.ceil(Math.random() * 1e5) + '';
export const requestId = () => `${+new Date() + uuid()}_id`;

export const toast = (title, icon = 'none', duration, options) => {
    wx.showToast({
        title: title || '',
        icon: icon,
        image: (options && options.image) || '',
        duration: duration || 2000,
        mask: false,
    });
}

export const compareVersion = (curVersion = '', target = '') => {
  const cur = curVersion.split('.');
  const targets = target.split('.');

  if (cur.length !== 3 || targets.length !== 3) {
    return false
  }

  return cur.reduce((p, c, index) => {
    const _c = Number(c);
    const _t = Number(targets[index]);

    if (_c < _t) {
      return p && false
    }

    if (_c >= _t) {
      return p && true
    }
  }, true)
}

export const parseAttachExt = (attachExt) => {
  try {
    attachExt = JSON.parse(attachExt)
    const { version, channelName } = attachExt
    if (version && channelName && compareVersion(version, '1.1.0')) {
      return attachExt
    }
    return false
  } catch (error) {
    return false
  }
}

export const prevent = (fn, delay) => {
  let last = 0
  return function(...args) {
    const cur = Date.now()
    if (cur - last > delay) {
      fn.apply(this, args);
      last = cur;
    }
  }
}

/**
 * 是否为iphoneX系列（带有底部bar）
 */
export const isIphoneX = () => {
  let model = wx.getSystemInfoSync().model && wx.getSystemInfoSync().model.toLowerCase()
  if (model.indexOf('iphone x') > -1 || model.indexOf('iphone 11') > -1 || model.indexOf('iphone 12') > -1 || (model.indexOf('unknown') > -1 && model.indexOf('iphone') > -1))  {
    return true
  } else {
    return false
  }
}


/** 
 * "yyyy-MM-dd hh:mm:ss.S" ==> 2006-07-02 08:09:04.423 
 * "yyyy-M-d h:m:s.S"      ==> 2006-7-2 8:9:4.18 
*/
export function formatDate(date, fmt = 'yyyy-MM-dd hh:mm:ss') {         
	if(!date) {
		return
	}	
	date = new Date(date)
	var o = {         
	"M+" : date.getMonth()+1, //月份         
	"d+" : date.getDate(), //日         
	"h+" : date.getHours()%12 == 0 ? 12 : date.getHours()%12, //小时         
	"H+" : date.getHours(), //小时         
	"m+" : date.getMinutes(), //分         
	"s+" : date.getSeconds(), //秒         
	"q+" : Math.floor((date.getMonth()+3)/3), //季度         
	"S" : date.getMilliseconds() //毫秒         
	};         
	var week = {         
	"0" : "/u65e5",         
	"1" : "/u4e00",         
	"2" : "/u4e8c",         
	"3" : "/u4e09",         
	"4" : "/u56db",         
	"5" : "/u4e94",         
	"6" : "/u516d"        
	};         
	if(/(y+)/.test(fmt)){         
		fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
	}         
	if(/(E+)/.test(fmt)){         
		fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "/u661f/u671f" : "/u5468") : "") + week[date.getDay()+""]);
	}         
	for(const k in o){         
		if(new RegExp("("+ k +")").test(fmt)){         
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr(("" + o[k]).length))); 
		}         
	}         
	return fmt;         
}  
