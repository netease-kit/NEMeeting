import { prevent } from '../../utils/index'
const { miniProgram: { envVersion } } = wx.getAccountInfoSync()

Page({
  data: {
    debug: false,
    roomId: '559735229',
    nickName: 'winsan',
    username: '18720915657',
    password: '12345678',
    openCamera: false,
    openMicrophone: false,
    tag: '',
    appKey: envVersion === 'develop' ? '092dcd94d2c2566d1ed66061891cdf15' : 'm6266fa59e8eb654fd98c3c80b5b',
    baseDomain: envVersion === 'develop' ? 'https://meeting-api-test.netease.im': 'https://meeting-api.netease.im', // 请求的domain地址，可不填
    accountId: '',
    accountToken: '',
    loginTypeArr: [
      { value: 1, title: '账号密码登录' },
      { value: 2, title: 'token登录' },
      { value: 3, title: '匿名登录' },
    ],
    users: [
      {
        username: '18720915657',
        password: '12345678',
        accountId: '1158682928649759',
        accountToken: 'U3hoUUlIRG0zMExrR1ZnWTBKSlZCUFkwbk5Ddk5JRnFSN0NZczk1NUdDVmt3OGJidTVUaHp0eEYxZkxOVy9TZXJ3MGIwNldCMkJJNnBadFlwaHM0YmJGaW1sS0F0MTBRWFFpUmp2amVtRU54V3luYmZBSzB6YVlaYzJHU2l5R2cwQTM0cUxuS216STFWdDFqUTNLbFhLODF2alVTZ21vRjdSUGtVWjdDT2VBPQ=='
      },
      {
        username: '17639806390',
        password: '12345678',
        accountId: '1159895293255225',
        accountToken: 'TWhBcVc0clp5TlRiU0pHNHZYZ2ZDa2NYbm1uWnR4azA5ODlscU1zTFZyZEJYdjZnbVl0Z1ZWdGtIWTNycGZXVDQxOTh6NG50Vm1TZ2c1RDZOcW03eHFobEh0cHpuYmkydGFvTnlyWXpNQmZtOHlpcVZRSlhaNXZ6UHlXdkhQMm5vTTVrUDJDL0t2UVdQNlk1YWF5TXptUEZEdlpYbXp2VW50aDU0eWxaaFlRPQ=='
      },
      {
        username: '19521624003',
        password: '12345678',
        accountId: '117629833818673152',
        accountToken: 'RnhMc2RIbU5LWlE0NWF4eWxJOGtyN3RzYkJ6aXhJR3JKQ1ZMTVc5Mm11T2dtT3R3emVyejgvendGbnFiMjBzeWgyekNuSk5ITys3eG5WQW5pamUwNnMybzIybklJNGZsMmVqNTdXRkhRaE1oMUtMWjBoTkowelkxMmZ5ZFFaU29KQ1NvMVd2MGUwQkVlanFYRFNqdVRpYlBiRms4SWdUdC92ZnFNY0ZpVFNZPQ=='
      },
    ],
    // users: [
    //   {
    //     username: '17000000002',
    //     password: '12345678',
    //     accountId: '1160127844690430',
    //     accountToken: 'Y28xeDZrUzVXaXVlVzhNNG5ncDMzQ21BVU9SejhIVUIvQ1ZQcGI4NDZ3Y2dTY1RYQ3M1MlBmWEx6NGd6UUxra2tqOThZSHUxNUpZUWltdzlLWW45YWRoVjZ0MGNyTjNYRjBCVFJsMVBjQjVxR0tWTGR0eUJjd0hDV1RIY3RqTHdGa2hBendZUmo3c2VFMDFueTFtYXZDaEtaVzRsM3d3NnQrdXVRSFRXby9VPQ=='
    //   },
    //   {
    //     username: '19100000002',
    //     password: '00000000',
    //     accountId: '1159037236285218',
    //     accountToken: 'ZWJQWmlBZDZrKzVnNURBdktVeWMyTHdqaUQyRmx5R2htelZDWFlhSGkrTXhQbXpSQ3BVaklzNUtncjBxdk5aYkhZLzdQNnVCV25wVUJrUVFCQ1hkR0pTdkxzeDBwdmZZRkYvTUxRVnhiMk9xdHY3Zk9xamVMd1NxejVvWHBHQXA0VDZFS3dvTUphazdDb1JmQ04xaDVnZ0VkWXNZdCtDUXM3YVZVYmpuOGRFPQ=='
    //   },
    //   {
    //     username: '17000000000',
    //     password: '12345678',
    //     accountId: '114014525937688576',
    //     accountToken: 'WnBwSDF1WE84US83MmQrY2g5NVdJT1BxRXpWMFJjVGlwYjR4dU1qcWJONFlwbDdZVDFtK3BZYWxEWnhyWlgxNVFXV2ZXbnkybSsvYUNIVUJYMWFaOG4vbGdPM242UDdFTUcwT25kaE1jcGlycnhWVjFiZksvV0h1V1M4Kzd1cWhJemNWYkUrcmx1UGNnb25hb0dibVE5aVpxMkc0YzJHN3ZhWjNWQy9Fdk1RPQ=='
    //   },
    //   {
    //     username: '18012340001',
    //     password: '123456789',
    //     accountId: '237891944527699968',
    //     accountToken: 'WjVMdkFOV01XQmtNTWE4cjFtaHd0TWtORUlVcDN2cEljK2hyVGFFZjJ5aUJSalo5bUVQc1dnN0pDT09HUjNTazFScUdEUHZTa0UxeVVhaEtmN2dkcXVEVTNhR2tIcEl0amU2V3laT3RwNlE5cjhUcmxyRCs1d3dpY1hCcG8ydXQvRlQ2VlJZWG9wK282WkRyMzRkZlhhZkZqWU5rWmdkWlZjN05FWjU3YVVJPQ==',
    //   },
    //   {
    //     username: '18012340002',
    //     password: '123456789',
    //     accountId: '237892140141649920',
    //     accountToken: 'TjAzRHlkNGpNNjhUQlFreVhMOVN5eThtcERTSGdnQ2U0YlRoOHEwN2JyQUFldWxWSW9kNk1EZnB1ZW9NYjJmVmhCcGp0Qk9NdjkyOEo5NkdMaU1iSTRJVFpCL096V1Q4TkxtWXZTWlAwNWwvY3FaUTVLOUZhc2lQTEZtYkYvMGJMQ2VTM1VMczZZVkhSbFpmUmk5MmpkSU1CZEZlT0ZJUFFWUy9CSFgwTVZjPQ==',
    //   }
    // ],
    type: 1
  },
  onload() {
    wx.getAvailableAudioSources(res => {
      console.log(res, 'wx.getAvailableAudioSources')
    })
  },
  bindPickerChange(e) {
    const index = e.detail.value
    const {username, password, accountId, accountToken} = this.data.users[index]
    this.setData({
      username,
      password,
      accountToken,
      accountId
    })
  },
  changeHandler(e) {
    const key = e.currentTarget.dataset.key
    this.setData({
      [key]: e.detail.value
    })
  },
  joinRoom: prevent(function() {
    if (!this.data.roomId) {
      wx.showToast({
        title: '请填写会议Id',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (!this.data.nickName) {
      wx.showToast({
        title: '请填写昵称',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (type == 1 && (!this.data.username || !this.data.password)) {
      wx.showToast({
        title: '请填写您的账号密码',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (type == 2 && (!this.data.accountToken || !this.data.accountId)) {
      wx.showToast({
        title: '请填写您的账号密码',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (!/^\d{1,12}$/.test(this.data.roomId)) {
      wx.showToast({
        title: '仅支持12位及以下纯数字',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    if (this.data.nickName && !/^[\u4e00-\u9fa5\da-zA-Z]{1,12}$/.test(this.data.nickName)) {
      wx.showToast({
        title: '仅支持12位及以下文本、字母及数字组合',
        icon: 'none',
        duration: 2000,
      })
      return;
    }
    const url = '/pages/meeting/index';
  
    const {
      debug,
      roomId,
      nickName,
      username,
      password,
      openCamera,
      openMicrophone,
      appKey,
      tag,
      type,
      accountId,
      baseDomain
    } = this.data;

    const queryParams = {
      debug,
      roomId,
      nickName,
      username,
      password,
      openCamera,
      openMicrophone,
      appKey,
      tag,
      type,
      accountId,
      accountToken: encodeURIComponent(this.data.accountToken),
      baseDomain
    };

    const finalUrl = Object.keys(queryParams).reduce((prev, cur) => {
      return `${prev}${prev === url ? '?' : '&'}${cur}=${queryParams[cur]}`
    }, url)
    wx.navigateTo({ url: finalUrl })
  }, 2000),
});
