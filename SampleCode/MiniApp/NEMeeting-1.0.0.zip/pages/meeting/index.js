Page({
  data: {
    config: {
      debug: true, // 是否开启调试模式
      appKey: '', // 云信 appKey
      deviceId: '', // 设备唯一id
      nickName: '', //昵称
      tag: '', // 用户标签，可不填
      baseDomain: '' // 请求的domain地址，可不填
    }
  },
  
  onLoad: function (options) {
    const config = Object.assign(this.data.config, options)
    Object.keys(config).forEach(item => {
      const optionVal = decodeURIComponent(config[item])
      let configData = `config.${item}`
      this.setData({
        [configData]: optionVal
      })
    })
    this.setData({
      'config.debug': config.debug === 'true'
    })
    this.setData({
      config
    })
    const {debug, appKey, baseDomain, neRtcServerAddresses, imPrivateConf} = this.data.config
    this.meetingComponent = this.selectComponent('#meeting-component')
    this.meetingComponent.initSDK({debug, appKey, baseDomain, neRtcServerAddresses, imPrivateConf})
    console.log('初始化SDK完成')
    if (config.type == 1) {
      this.loginWithAccount({
        username: options.username,
        password: options.password
      })
    }
    if (config.type == 2) {
      this.loginWithToken({
        accountId: options.accountId,
        token: decodeURIComponent(options.accountToken)
      })
    }
    if (config.type == 3) {
      const {roomId, nickName, openCamera, openMicrophone, tag} = options
      this.meetingComponent.anonymousJoinMeeting({
        roomId, 
        nickName, 
        openCamera, 
        openMicrophone, 
        tag
      }).catch(err => {
        wx.showToast({
          title: err,
          icon: 'none',
          duration: 2000,
          complete: () => {
            setTimeout(() =>{
              wx.navigateBack({
                delta: 1,
              })
            }, 1000)
          }
        })
      })
    }
  },

  // 离开页面需要调登出接口，否则无法销毁im房间
  onUnload: function () {
    this.meetingComponent.logout()
  },

  // 除非页面销毁和登出操作，否则登录一直有效，不能登录2次哦
  async loginWithAccount (params) {
    this.meetingComponent.loginWithAccount(params).catch(err => {
      wx.showToast({
        title: err,
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() =>{
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      })
    })
  },

  async loginWithToken (params) {
    this.meetingComponent.loginWithToken(params).catch(err => {
      wx.showToast({
        title: err,
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() =>{
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      })
    })
  },

  onLoginStateChange(status) {
    console.log(status.detail, 'login status')
    if (status.detail === 'logined') {
      const {roomId, nickName, openCamera, openMicrophone, tag} = this.data.config
      this.meetingComponent.joinRoom({
        roomId, 
        nickName, 
        openCamera, 
        openMicrophone, 
        tag
      }).catch(err => {
        wx.showToast({
          title: err,
          icon: 'none',
          duration: 1500,
          complete: () => {
            setTimeout(() =>{
              wx.navigateBack({
                delta: 1,
              })
            }, 1500)
          }
        })
      })
    }
  },
  // 离开房间的一些处理在这里
  leaveRoom() {
    console.log('收到离开会议')
    wx.reLaunch({ url: '/pages/join/join' })
  },
  onMeetingClosed() {
    console.log('onMeetingClosed')
    this.destroy()
  },
  onDisconnect() {
    console.log('onDisconnect')
    this.destroy()
  },
  onKicked() {
    console.log('onKicked')
    this.destroy()
  }, 
  destroy() {
    this.meetingComponent.destroy()
    setTimeout(() => {
      wx.navigateBack()
    }, 2000)
  }
})