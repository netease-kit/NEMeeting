// components/NEChatRoomUI/chatRoomUI.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    msgs: {
      type: Array,
      value: [],
      observer: function(newVal, oldVal) { // 收到新消息滚动到底部
        const len = newVal.length || 1;
        this.setShowToBottom();
        this.setToView(len - 1);
      }
    },
    visiable: {
      type: Boolean,
      observer: function(newVal, oldVal) { // 显示聊天室 执行滚动
        newVal && this.setToView(this.properties.msgs.length - 1);
      }
    }
  },

  lifetimes: {
    created: function () {
      // 在组件实例刚刚被创建时执行
      this.needScrollToBottom = true
      let model = wx.getSystemInfoSync().model && wx.getSystemInfoSync().model.toLowerCase();
      this.isIPhone = model.indexOf('iphone') > -1;
      this.scrolled = false; // 表示是否滚动浏览过消息
    },
    attached: function () {
      // 在组件实例进入页面节点树时执行
    },
    ready: function () {
      // 在组件在视图层布局完成后执行
      this.setMsgContainerHeight()
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    text: '',
    lastMsgId: '',
    keybordHeight: 0, // 保存键盘弹起的高度
    textareaHeight: 0, // 设置键盘弹起之后输入框的高度
    showToBottom: false, // 是否显示到达底部按钮
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onClose() {
      this.triggerEvent('close');
    },
    setShowToBottom() { // 设置是否显示新消息到底底部按钮
      // 1、是否不再底部 2、判断是否滚动过 
      this.setData({
        showToBottom: !this.needScrollToBottom && this.scrolled
      })
    },
    setMsgContainerHeight() {
      const windowHeight = wx.getSystemInfoSync().windowHeight
      const otherHeight = (40 + 40 + 56) * 0.75 //  outHeader + header + input
      this.msgContainerHeight = windowHeight - otherHeight  // 横屏消息容器高度
    },
    setToView(index) { // 跳转到指定消息位置
      this.needScrollToBottom && this.toPosition(index)
    },
    toPosition(index) {
      wx.nextTick(() => {
        this.setData({
          lastMsgId: `msg${index}`
        })
      })
    },
    onInputChange(event) {
      const {value} = event.detail
      this.data.text = value
    },
    onSendMsg() {
      this.triggerEvent('sendMsg', { 
        content: this.data.text,
        type: 'text'
      });
      this.clearInput()
    },
    clearInput() {
      this.setData({
        text: ''
      });
    },
    onKeybordHeightChange(event) {
      const detail = event.detail
      if(this.data.keybordHeight === detail.height) {
        return
      }
      this.setData({
        keybordHeight: detail.height
      })
    },
    onFocus() {
      this.toBottom()
      if(this.isIPhone) {
        return
      }
      this.setData({
        textareaHeight: Math.max(this.data.keybordHeight - 35, 0)
      })
    },
    onBlur() { // 失去焦点
      this.setData({
        textareaHeight: 0
      })
    },
    onMsgScroll(event) {
      // 滚动过页面
      !this.scrolled && (this.scrolled = true)
      const { scrollTop, scrollHeight } = event.detail
      // 当前滚动条不再底部不需要滚动到底部
      this.needScrollToBottom = scrollHeight - (this.msgContainerHeight + scrollTop) < 20
      if(this.needScrollToBottom) { // 如果滚动到底部则隐藏新消息提醒
        this.setData({
          showToBottom: false
        })
      }
    },
    onResendMsg(event) {
      const {msg} = event.detail
      this.triggerEvent('resendMsg', { 
        msg,
      });
    },
    onToBottom() {
      this.toBottom() 
      this.setData({
        showToBottom: false
      });
    },
    toBottom() {
      const msgs = this.properties.msgs;
      const len = msgs.length || 1;
      this.toPosition(len - 1);
    }
  }
})
