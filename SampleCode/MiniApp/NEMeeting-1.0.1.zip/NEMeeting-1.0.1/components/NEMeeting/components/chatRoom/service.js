import { formatDate } from '../../utils/index';
export function getHistoryService(request, imAccid, options={
  limit: 100,
  reverse: true,
}) {
  return request.getHistoryMsgs(options).then(res => {
    let msgs = res.msgs;
    return msgs.filter(msg => {
        return msg.type !== 'notification' || (msg.type === 'notification' && msg.text)
      }).map(msg => {
        msg = formateMsg(msg, imAccid)
        return msg
      })
  }) 
}

export function handleRecMsgService(msgs) {
  let unReadMsgsCount = 0 // 获取未读消息
  msgs =  msgs.filter(msg => {
    if(msg.type !== 'notification') {
      unReadMsgsCount += 1
    }
    return msg.type !== 'notification' || (msg.type === 'notification' && msg.text)
  }).map(msg => {
      msg = formateMsg(msg)
      return msg
  }) 
  return {
    msgs,
    unReadMsgsCount
  }
}

function formateMsg(msg, myAccountId) {
  msg.time = formatDate(msg.time, 'yyyy-MM-dd hh:mm:ss')
  msg.fromAvatar = msg.fromAvatar || ''
  myAccountId && (msg.isMe = msg.from === myAccountId)
  return msg
}
const handleMap = {
  text: (request, params, myId) => {
    return new Promise((resolve, reject) => {
      console.log('params', params)
      request.sendTextMessage({
        ...params,
        done (err, msg) {
          msg = formateMsg(msg, myId)
          resolve(msg)
        }
      })
    })
  }
}
export function handleSendMsgService(request, params, myId) {
  return handleMap[params.type](request, params, myId)
}