const version = '1.0.1'

export default version
