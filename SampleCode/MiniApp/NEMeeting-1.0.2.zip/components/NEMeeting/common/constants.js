export const CLIENT_EVENT = {
  ERROR: 'onRtcError',
  STREAM_ADDED: 'onRoomUserStreamAdded', // 通知应用程序已添加远端音视频流
  STREAM_REMOVED: 'onRoomUserStreamRemove', // 通知应用程序已删除远端音视频流
  SYNC_DONE: 'onRtcSyncDone', // 通知应用程序更新后的推流地址和拉流地址
  CLIENT_LEAVE: 'onRoomUserLeave', // 通知应用程序有人离开房间
  CLIENT_JOIN: 'onRoomUserJoin', // 通知应用程序有人加入房间
  CLIENT_BANNED: 'onRtcClientBanned', // 通知应用程序自己被踢出
  OPEN: 'onRtcOpen', // 通知应用程序socket建立成功
  RECONNECT: 'onRtcReconnected', // 通知应用程序音视频socket重连
  DISCONNECT: 'onRtcChannelDisconnected', // 通知应用程序音视频socket关闭
  WILLRECONNECT: 'onRtcWillReconnect', // 通知应用程序信令准备重连
  SENDCOMMANDOVERTIME: 'onRtcSendCommandOverTime', // 通知应用程序发送命令超时
  LIVEROOMCLOSE: 'onRtcChannelClosed', // 通知应用程序房间被解散
  MUTE_AUDIO: 'onRoomUserMuteAudio', // 远端mute了自己的audio
  UNMUTE_AUDIO: 'onRoomUserUnMuteAudio', // 远端unmute了自己的audio
  MUTE_VIDEO: 'onRoomUserMuteVideo', // 远端mute了自己的video
  UNMUTE_VIDEO: 'onRoomUserUnMuteVideo', // 远端unmute了自己的video
  ABILITY_NOT_SUPPORT: 'onRtcAbilityNotSupport', // 通知应用程序协商不支持
}

export const EVENT = {
  INVITED: 'onInvited',
  USER_CANCEL: 'onUserCancel',
  USER_ACCEPT: 'onUserAccept',
  USER_ENTER: 'onUserEnter',
  USER_REJECT: 'onUserReject',
  USER_LEAVE: "onUserLeave",
  USER_BUSY: "onUserBusy",
  USER_DISCONNECT: "onUserDisconnect",
  USER_NETWORK_QUALITY: 'onUserNetworkQuality',

  DISCONNECT: "onDisconnect",
  AUDIO_AVAILABLE: "onAudioAvailable",
  VIDEO_AVAILABLE: 'onCameraAvailable',
  CALL_END: "onCallEnd",
  CALLING_TIMEOUT: 'onCallingTimeOut',
  CALL_TYPE_CHANGE: 'onCallTypeChange',
  OTHER_CLIENT_ACCEPT: 'onOtherClientAccept',
  OTHER_CLIENT_REJECT: 'onOtherClientReject',

  FIRST_VIDEO_FRAME_DECODED: 'onFirstVideoFrameDecoded',

  VIDEO_MUTED: 'onVideoMuted',
  AUDIO_MUTED: 'onAudioMuted',
  MESSAGE_SENT: 'onMessageSent',
  JOIN_CHANNEL: 'onJoinChannel',
  ERROR: 'onError', // 组件内部抛出的错误
}

export const MEETING_EVENT = {
  ROOM_USER_HANGUP: 'onRoomUserHangup',
  ROOM_USER_SCREEN_SHARE_STATUS_CHANGED: 'onRoomUserScreenShareStatusChanged',
  ROOM_USER_VIDEO_STATUS_CHANGED: 'onRoomUserVideoStatusChanged',
  ROOM_USER_AUDIO_STATUS_CHANGED: 'onRoomUserAudioStatusChanged',
  ROOM_USER_JOIN: "onRoomUserJoin",
  ROOM_USER_LEAVE: 'onRoomUserLeave',
  ROOM_USER_STREAM_ADDED: "onRoomUserStreamAdded",
  ROOM_USER_STREAM_REMOVE: 'onRoomUserStreamRemove',
  ROOM_USER_STREAM_SUBSCRIBED: 'onRoomUserStreamSubscribed',
  ROOM_USER_VIDEO_PINSTATUS_CHANGED: "onRoomUserVideoPinStatusChanged",
  ROOM_HOST_CHANGED: "onRoomHostChanged",
  ROOM_LOCKSTATUS_CHANGED: "onRoomLockStatusChanged",
  ROOM_USERNAME_CHANGED: 'onRoomUserNameChanged',

  ROOM_CALLTYPE_CHANGED: 'onRoomCallTypeChanged',
  NETWORK_QUALITY: 'onNetworkQuality',
  RTC_CLIENT_BANNED: 'onRtcClientBanned',
  RTC_CHANNEL_CLOSED: 'onRtcChannelClosed',
  RTC_CHANNEL_DISCONNECTED: 'onRtcChannelDisconnected',
  ROOM_CHAT_MESSAGE_RECEIVED: 'onRoomChatMessageReceived',
  ROOM_USER_HANGUP: 'onRoomUserHangup',
  ROOM_CALL_TYPE_CHANGED: 'onRoomCallTypeChanged',
  ROOM_USER_AUDIO_STATUS_CHANGED: 'onRoomUserAudioStatusChanged', // 音频开关
  ROOM_USER_VIDEO_STATUS_CHANGED: 'onRoomUserVideoStatusChanged', // 视频开关
  ROOM_USER_VIDEO_PIN_STATUS_CHANGED: 'onRoomUserVideoPinStatusChanged', // 视频焦点
  ROOM_HOST_CHANGED: 'onRoomHostChanged', // 更新主持人
  ROOM_USER_NAME_CHANGED: 'onRoomUserNameChanged', // 昵称变化
  ROOM_USER_SCREEN_SHARE_STATUS_CHANGED: 'onRoomUserScreenShareStatusChanged', // 更新屏幕共享状态
  ROOM_LOCK_STATUS_CHANGED: 'onRoomLockStatusChanged', // 会议锁定
}

export const DEFAULT_COMPONENT_CONFIG = {
  appKey: '',
  token: '',
  mode: 0,
  uid: null,
  debug: false,
  openCamera: false,
  openMicrophone: false,
  resolution: 'SD',
  audioQuality: 'low',
  videoWidth: 360,
  videoHeight: 640,
  minBitrate: 600,
  maxBitrate: 900,
}

export const CallingStatus = {
  idle: 0, // 闲置
  calling: 1, // 正在呼叫
  called: 2, // 正在被呼叫
  inCall: 3, // 通话中
}
