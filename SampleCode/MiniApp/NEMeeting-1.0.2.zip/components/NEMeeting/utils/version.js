const version = '1.0.0'

export default version
