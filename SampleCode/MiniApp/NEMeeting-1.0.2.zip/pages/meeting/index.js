Page({
  data: {
    config: {
      debug: true, // 是否开启调试模式
      appKey: '', // 云信 appKey
      deviceId: '', // 设备唯一id
      nickName: '', // 昵称
      tag: '', // [可选] 用户标签
      tags: '', // [可选] 聊天室当前用户的标签分组，最多填写一个
      defaultDirectionalTags: '', // [可选] 聊天室定向发送消息的标签组
      enableOrientChat: true, // [可选] 是否开启聊天室定向发送消息模式，默认关闭
      baseDomain: '', // [可选] 请求的domain地址
      offChatRoom: false, // [可选] 关闭聊天室功能，默认开启
      neRtcServerAddresses: {},
      imPrivateConf: {}
    }
  },
  
  onLoad: function (options) {
    const config = Object.assign(this.data.config, options)
    this.setData({
      config,
      'config.accountToken': decodeURIComponent(config.accountToken),
      'config.baseDomain': decodeURIComponent(config.baseDomain),
      'config.debug': config.debug === 'true'
    })
    // 开启私有化部署(这里保证两个对象的参数准确)
    if (options.isPrivatization === 'true' && options.neRtcServerAddresses && options.imPrivateConf) {
      this.setData({
        'config.neRtcServerAddresses': JSON.parse(config.neRtcServerAddresses),
        'config.imPrivateConf': JSON.parse(config.imPrivateConf),
      })
    }
    const {debug, appKey, baseDomain, offChatRoom, tags, enableOrientChat, neRtcServerAddresses, imPrivateConf} = this.data.config
    let defaultDirectionalTags = this.data.config.defaultDirectionalTags.split(/[,，]/).filter(item => !!item)
    this.meetingComponent = this.selectComponent('#meeting-component')
    this.meetingComponent.initSDK({debug, appKey, baseDomain, offChatRoom, tags, defaultDirectionalTags, enableOrientChat, neRtcServerAddresses, imPrivateConf})
    console.log('初始化SDK完成')
    if (config.type == 1) {
      this.loginWithAccount({
        username: options.username,
        password: options.password
      })
    }
    if (config.type == 2) {
      this.loginWithToken({
        accountId: options.accountId,
        token: decodeURIComponent(options.accountToken)
      })
    }
    if (config.type == 3) {
      const {meetingId, nickName, openCamera, openMicrophone, tag} = this.data.config
      this.meetingComponent.anonymousJoinMeeting({
        roomId: meetingId,
        nickName, 
        openCamera, 
        openMicrophone, 
        tag
      }).catch(err => {
        wx.showToast({
          title: err,
          icon: 'none',
          duration: 2000,
          complete: () => {
            setTimeout(() =>{
              wx.navigateBack({
                delta: 1,
              })
            }, 1000)
          }
        })
      })
    }
  },

  // 离开页面需要调登出接口，否则无法销毁im房间
  onUnload: function () {
    this.meetingComponent.logout()
  },

  // 除非页面销毁和登出操作，否则登录一直有效，不能登录2次哦
  async loginWithAccount (params) {
    this.meetingComponent.loginWithAccount(params).catch(err => {
      wx.showToast({
        title: err,
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() =>{
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      })
    })
  },

  async loginWithToken (params) {
    this.meetingComponent.loginWithToken(params).catch(err => {
      wx.showToast({
        title: err,
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() =>{
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      })
    })
  },

  onLoginStateChange(status) {
    console.log(status.detail, 'login status')
    if (status.detail === 'logined') {
      const {meetingId, nickName, openCamera, openMicrophone, tag} = this.data.config
      this.meetingComponent.joinRoom({
        roomId: meetingId,
        nickName, 
        openCamera, 
        openMicrophone, 
        tag
      }).catch(err => {
        wx.showToast({
          title: err,
          icon: 'none',
          duration: 1500,
          complete: () => {
            setTimeout(() =>{
              wx.navigateBack({
                delta: 1,
              })
            }, 1500)
          }
        })
      })
    }
  },
  // 离开房间的一些处理在这里
  leaveRoom() {
    console.log('收到离开会议')
    wx.reLaunch({ url: '/pages/join/join' })
  },
  onMeetingClosed() {
    console.log('onMeetingClosed')
    this.destroy()
  },
  onDisconnect() {
    console.log('onDisconnect')
    this.destroy()
  },
  onKicked() {
    console.log('onKicked')
    this.destroy()
  }, 
  destroy() {
    this.meetingComponent.destroy()
    setTimeout(() => {
      wx.navigateBack()
    }, 2000)
  }
})