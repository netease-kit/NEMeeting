import { logger } from './utils/logger.js'

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    msgs: {
      type: Array,
      value: [],
      observer: function(newVal, oldVal) { // 收到新消息滚动到底部
        const len = newVal.length || 1;
        this.setShowToBottom();
        this.setToView(len - 1);
      }
    },
    visiable: {
      type: Boolean,
      observer: function(newVal, oldVal) { // 显示聊天室 执行滚动
        newVal && this.setToView(this.properties.msgs.length - 1);
      }
    },
    tagInfo: {
      type: Object,
      observer: function(newVal, oldVal) { // 用户标签相关信息
        logger.log(newVal, 'properties tagInfo')
        // 用户数量更新
        if ((newVal.allMembers && newVal.allMembers.length) !== (oldVal && oldVal.allMembers && oldVal.allMembers.length)) {
          logger.log(newVal.allMembers, '成员数量更新')
          this.initTagStatus()
        }
      }
    }
  },

  lifetimes: {
    created: function () {
      // 在组件实例刚刚被创建时执行
      this.needScrollToBottom = true
      let model = wx.getSystemInfoSync().model && wx.getSystemInfoSync().model.toLowerCase();
      this.isIPhone = model.indexOf('iphone') > -1;
      this.scrolled = false; // 表示是否滚动浏览过消息
      this.checkedElArr = []; // 选中的标签和名称
    },
    attached: function () {
      // 在组件实例进入页面节点树时执行
      this.initTagStatus()
    },
    ready: function () {
      // 在组件在视图层布局完成后执行
      this.setMsgContainerHeight()
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    text: '',
    lastMsgId: '',
    keybordHeight: 0, // 保存键盘弹起的高度
    textareaHeight: 0, // 设置键盘弹起之后输入框的高度
    showToBottom: false, // 是否显示到达底部按钮
    memberListShow: false, // 是否显示成员分组列表
    allChecked: false,
    selectedMemberListStr: '所有人', // 已选中成员字符串
    selectedMemberAccids: [], // 已选中成员account列表
    selectedMemberNames: [], // 已选中成员名称列表
    filterMemberList: [], // 搜索时展示的列表，避免操作原数据，影响状态和结构
    memberList: [
      // {
      //   value: '第一小组',
      //   children: [
      //     {
      //       value: '成员1A',
      //       checked: true
      //     }
      //   ]
      // }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 标签状态初始化
    initTagStatus() {
      const tagInfoProps = this.properties.tagInfo
      const {selectedMemberAccids, selectedMemberNames} = this.data
      const defaultAccids = selectedMemberAccids.length ? selectedMemberAccids : tagInfoProps.defaultAccids
      const defaultNames = selectedMemberNames.length ? selectedMemberNames : tagInfoProps.defaultNames

      if (!Object.keys(tagInfoProps).length) return
      tagInfoProps.members && tagInfoProps.members.forEach(item => {
        // 存在定向发送标签组
        if (tagInfoProps.defaultDirectionalTags && tagInfoProps.defaultDirectionalTags.length) {
          tagInfoProps.defaultDirectionalTags.forEach(defaultTags => {
            // 定向tag和其子节点全选
            const hasNotChecked = item.children.filter(item => !item.checked)
            if(item.tags === defaultTags || !hasNotChecked.length) {
              item.checked = true
              item.disabled = false
              // 子节点遍历
              if (item.children) {
                item.children.forEach(child => {
                  child.checked = true
                  child.disabled = false
                })
              }
              return
            }
            // 非定向的置灰不可选
            item.disabled = true
            if (item.children) {
              item.children.forEach(child => {
                child.disabled = true
              })
            }
          })
        } else {
          this.data.memberList.forEach(oldMember => {
            if (item.account) { // 无子节点
              // 存在相同的数据
              if (item.account === oldMember.account) {
                item.checked = oldMember.checked
                item.disabled = oldMember.disabled
              }
            } else { // 有子节点
              if (item.tags === oldMember.tags) {
                const hasNotChecked = item.children.filter(child => !child.checked)
                // 成员离开或不变-父节点用原来的状态，子节点全勾选时，父节点也要勾选上
                if (oldMember.children.length >= item.children.length) {
                  item.checked = !hasNotChecked.length || oldMember.checked
                } else {
                  // 成员增加-取消勾选父节点和全选按钮
                  this.setData({
                    allChecked: false
                  })
                  item.checked = false
                }
              }
            }
            // 子节点状态还原
            if (item.children && oldMember.children) {
              item.children.forEach(child => {
                oldMember.children.forEach(oldChild => {
                  // 存在相同的数据
                  if (child.account === oldChild.account) {
                    child.checked = oldChild.checked
                    child.disabled = oldChild.disabled
                  }
                })
              })
            }
          })
        }
      })
      defaultAccids && defaultAccids.forEach((accid, index) => {
        // 删除离开的已选中成员
        if (JSON.stringify(tagInfoProps.members).indexOf(accid) === -1) {
          logger.log(accid, '成员已离开')
          defaultAccids.splice(index, 1)
          defaultNames.splice(index, 1)
        }
      })
      this.setData({
        memberList: tagInfoProps.members || [],
        filterMemberList: tagInfoProps.members || [],
        selectedMemberAccids: defaultAccids || [],
        selectedMemberNames: defaultNames || [],
        selectedMemberListStr: defaultNames && defaultNames.toString()
      })
    },
    onClose() {
      this.triggerEvent('close');
    },
    setShowToBottom() { // 设置是否显示新消息到底底部按钮
      // 1、是否不再底部 2、判断是否滚动过 
      this.setData({
        showToBottom: !this.needScrollToBottom && this.scrolled
      })
    },
    setMsgContainerHeight() {
      const windowHeight = wx.getSystemInfoSync().windowHeight
      const otherHeight = (40 + 40 + 56) * 0.75 //  outHeader + header + input
      this.msgContainerHeight = windowHeight - otherHeight  // 横屏消息容器高度
    },
    setToView(index) { // 跳转到指定消息位置
      this.needScrollToBottom && this.toPosition(index)
    },
    toPosition(index) {
      wx.nextTick(() => {
        this.setData({
          lastMsgId: `msg${index}`
        })
      })
    },
    onInputChange(event) {
      const {value} = event.detail
      this.data.text = value
    },
    onSendMsg() {
      // 私聊
      const isPrivate = this.data.allChecked ? false : !!this.data.selectedMemberAccids.length
      let toAccidsArr = this.data.allChecked ? [] : this.data.selectedMemberAccids

      this.triggerEvent('sendMsg', { 
        content: this.data.text,
        type: 'text',
        toAccids: toAccidsArr,
        custom:  this.data.allChecked ? '' : JSON.stringify({ toAccids: toAccidsArr, isPrivate }),
      });
      this.clearInput()
    },
    clearInput() {
      this.setData({
        text: ''
      });
    },
    onKeybordHeightChange(event) {
      const detail = event.detail
      if(this.data.keybordHeight === detail.height) {
        return
      }
      this.setData({
        keybordHeight: detail.height
      })
    },
    onFocus() {
      this.toBottom()
      if(this.isIPhone) {
        return
      }
      this.setData({
        textareaHeight: Math.max(this.data.keybordHeight - 35, 0)
      })
    },
    onBlur() { // 失去焦点
      this.setData({
        textareaHeight: 0
      })
    },
    onMsgScroll(event) {
      // 滚动过页面
      !this.scrolled && (this.scrolled = true)
      const { scrollTop, scrollHeight } = event.detail
      // 当前滚动条不再底部不需要滚动到底部
      this.needScrollToBottom = scrollHeight - (this.msgContainerHeight + scrollTop) < 20
      if(this.needScrollToBottom) { // 如果滚动到底部则隐藏新消息提醒
        this.setData({
          showToBottom: false
        })
      }
    },
    onResendMsg(event) {
      const {msg} = event.detail
      this.triggerEvent('resendMsg', { 
        msg,
      });
    },
    onToBottom() {
      this.toBottom() 
      this.setData({
        showToBottom: false
      });
    },
    toBottom() {
      const msgs = this.properties.msgs;
      const len = msgs.length || 1;
      this.toPosition(len - 1);
    },
    // 显示成员分组列表
    onMemberListShow () {
      this.setData({
        memberListShow: true
      })
    },
    // 关闭成员分组列表
    onMemberListHide () {
      this.setData({
        memberListShow: false
      })
    },

    // 搜索（标签和昵称）
    bindSearch: function (e) {
      const text = e.detail.value
      const members = this.bindCheckStatusMap(this.data.filterMemberList)
      let filterList = []

      if (text) {
        for(let i = 0; i < members.length; i++) {
          const item = members[i]
          // 先查询标签组
          if (item.tags.indexOf(text) > -1) {
            filterList.push(item)
          }
          // 再查询成员昵称
          if (item.children) {
            filterList = filterList.concat(item.children.filter(child => JSON.stringify(child.value).indexOf(text) > -1))
          }
        }
      }
      this.setData({
        memberList: text ? filterList : members,
        searchText: text
      })
    },

    // 成员选中状态的映射
    bindCheckStatusMap (arr) {
      if (!arr.length) return
      arr.forEach(item => {
        if (!item.account && item.children) {
          // 成员状态还原
          item.children.forEach(child => {
            const filterChild = this.checkedElArr.filter(checkItem => child.account === checkItem.account)
            child.checked = filterChild.length > 0
          })
          // 成员全选时,选中标签组
          const childNotCheckIndex = item.children.findIndex(item => !item.checked)
          item.checked = childNotCheckIndex === -1
        } else {
          const filterItem = this.checkedElArr.filter(checkItem => item.account === checkItem.account)
          item.checked = filterItem.length > 0
        }
      })
      return arr
    },

    bindCheckChange (e) {
      const {checked, parentindex, index} = e.currentTarget.dataset
      const data = this.data.memberList

      // 取消选中
      if (checked) {
        let self = parentindex === undefined ? data[index] : data[parentindex].children[index]

        // 更新选中信息
        const updateSelectedFn = (data) => {
          this.updateSelectedMemberList.bind(this)(data,'delete')
        }
        // 更新选中状态
        const updateCheckStatusFn = (data) => {
          this.updateMemberCheckStatus.bind(this)(data, false)
        }
        // 记录状态改变数组
        const checkedStatusChangeFn = (data) => {
          this.checkedStatusChange.bind(this)(data,'delete')
        }
        this.execute([self], [updateSelectedFn, updateCheckStatusFn, checkedStatusChangeFn])

        // 取消父节点
        if (parentindex !== undefined) {
          data[parentindex].checked = false
          this.checkedStatusChange(data[parentindex], 'delete')
        }
      } else { // 选中
        let self = parentindex === undefined ? data[index] : data[parentindex].children[index]

        // 更新选中信息
        const updateSelectedFn = (data) => {
          this.updateSelectedMemberList.bind(this)(data, 'add')
        }
        // 更新选中状态
        const updateCheckStatusFn = (data) => {
          this.updateMemberCheckStatus.bind(this)(data, true)
        }
        // 记录状态改变数组
        const checkedStatusChangeFn = (data) => {
          this.checkedStatusChange.bind(this)(data, 'add')
        }

        this.execute([self], [updateSelectedFn, updateCheckStatusFn, checkedStatusChangeFn])

        // 兄弟节点全选时,选中父节点
        if (parentindex !== undefined) {
          const childNotCheckArr = data[parentindex].children.filter(item => !item.checked)
          if (!childNotCheckArr.length) {
            data[parentindex].checked = true
            this.checkedStatusChange(data[parentindex], 'add')
          }
        }
      }
      this.allCheckedFilter()
      this.setData({
        memberList: data
      })
    },

    // 全选状态处理
    allCheckedFilter() {
      if (this.properties.tagInfo.allMembers.length === this.data.selectedMemberAccids.length) {
        this.setData({
          allChecked: true,
          selectedMemberListStr: '所有人',
        })
      } else {
        this.setData({
          allChecked: false,
          selectedMemberListStr: this.data.selectedMemberNames.toString(),
        })
      }
    },

    // 更新选中名单
    updateSelectedMemberList (data, status = 'add') {
      let memberAccIds = this.data.selectedMemberAccids
      let memberNames = this.data.selectedMemberNames
      const accidIdx = memberAccIds.indexOf(data.account)

      if (status === 'delete') {
        // 取消勾选时删除
        if (accidIdx > -1) {
          memberAccIds.splice(accidIdx, 1)
          memberNames.splice(accidIdx, 1)
        }
      } else {
        if (!data.children && accidIdx < 0) {
          memberAccIds.push(data.account)
          memberNames.push(data.value)
        }
      }

      this.setData({
        selectedMemberAccids: memberAccIds,
        selectedMemberNames: memberNames,
      })
      logger.log(memberAccIds, memberNames, '选中的成员')
    },

    // 更新勾选状态
    updateMemberCheckStatus (data, status = true) {
      data.checked = status
    },

    // 状态改变记录数组
    checkedStatusChange(data, status = 'add') {
      // 标签组不记录，bindCheckStatusMap里面有判断逻辑
      if (!data.account) return

      if (status === 'delete') {
        const index = this.checkedElArr.findIndex(item => item.account === data.account)
        if(index > -1) {
          this.checkedElArr.splice(index, 1)
        }
      } else {
        this.checkedElArr.push(data)
      }
    },

    // 成员树遍历
    execute (tree, funcArr) {
      tree.forEach(data => {
        funcArr.forEach(func => {
          func(data)
        })
        data.children && this.execute(data.children, funcArr)
      })
    },

    selectAll (e) {
      let list = this.data.memberList  
      const updateSelectedFn = (data) => {
        this.updateSelectedMemberList.bind(this)(data, this.data.allChecked ? 'delete' : 'add')
      }
      const updateCheckStatusFn = (data) => {
        this.updateMemberCheckStatus.bind(this)(data, this.data.allChecked === false)
      }
      const checkedStatusChangeFn = (data) => {
        this.checkedStatusChange.bind(this)(data, this.data.allChecked ? 'delete' : 'add')
      }
      this.execute(list, [updateSelectedFn, updateCheckStatusFn, checkedStatusChangeFn])
      this.setData({
        allChecked: !this.data.allChecked,
        memberList: list,
        filterMemberList: list,
        selectedMemberListStr: '所有人',
      })
    }
  }
})
