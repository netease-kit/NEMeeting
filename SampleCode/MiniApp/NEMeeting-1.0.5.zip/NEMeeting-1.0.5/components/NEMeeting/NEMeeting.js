import { MEETING_EVENT, CLIENT_EVENT, DEFAULT_COMPONENT_CONFIG } from './common/constants.js'
const RoomKitMiniappSDK = require('./resources/sdk/index.cjs.js').default;
import { uuid, isIphoneX, prevent } from './utils/index.js'
import { logger } from './utils/logger.js'
const TAG_NAME = 'meeting-component'
const LoginState = {
  idle: 'idle',
  logining: 'logining',
  logined: 'logined',
  logouting: 'logouting',
}

Component({
  lifetimes: {
    created: function () {
      // 在组件实例刚刚被创建时执行
    },
    attached: function () {
      // 在组件实例进入页面节点树时执行
      this._init()
    },
    ready: function () {
      // 在组件在视图层布局完成后执行
    },
    detached: function () {
      // 在组件实例被从页面节点树移除时执行
      this.destroy()
    },
    error: function (error) {
      // 每当组件方法抛出错误时执行
    },
  },
  // 组件所在页面的生命周期
  pageLifetimes: {
    show: function() {
      // 页面被展示
      this.onShowToast()
      logger.addFilterMsg(TAG_NAME)
    },
    hide: function() {
      if (this.data.isHideMute) {
        // 页面被隐藏
        this.setData({
          hasHided: true
        })
        this.muteMyMedia()
      }
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    debug: false,
    offChatRoom: false,
    enableOrientChat: false,
    extraData: {}, // 会议额外信息
    userList: [],
    smallScreenShow: true,
    cameraPosition: 'front', // back-后置，front-前置
    audioOutPutMode: 'speaker', // speaker-扬声器， ear-听筒
    isIphoneX: isIphoneX(),
    showChatRoom: false, // 显示聊天室
    meetingInfo: null,
    hostNickName: '',
    meetingInfoDialogShow: false,
    memberListDialogShow: false,
    chatRoomController: null,
    chatRoomInfo: null,
    unReadCount: 0, // 未读消息
    leaveRoomSheetShow: false, // 离开会议弹窗开关
    focusSheetShow: false, // 设置焦点用户开关
    toolsVisible: true, // 操作栏显示开关
    onlineUserMember: 1, // 在线人数
    meetingMaxCount: 0, // 会议预置总人数
    selectedUserNickName: '', // 当前选择置顶的用户昵称
    focusSheetBtns: [
      { text: '置顶', value: true },
    ],
    leaveRoomBtns: [
      { text: '退出会议', value: true },
    ],
    loading: true,
    isAudioConfirm: false,
    isVideoConfirm: false,
    isSettingConfirm: false,
    videoAttendeeOff: false, // 允许开启视频
    audioAttendeeOff: false, // 允许开启音频
    noAudioAuthSetting: false, // 是否关闭麦克风权限
    noVideoAuthSetting: false, // 是否关闭摄像头权限
    btnAudioLoading: false, // 开启音频的按钮loading
    btnVideoLoading: false, // 开启视频的按钮loading
    isConnected: true, // 断网是否重连，用于当用户wifi和流量同时开启时候会走两次网络监听
    sortListTimer: null, // 刷新排序做节流
    isHideMute: true, // 小程序最小化后是否需要后台关闭音视频
    enableRealtimeLog: true, // 是否开启实时日志上报（微信公众号后台查看）
    retryRemoteObj: {},
  },

  /**
   * 组件的方法列表
   */
  methods: {
    _init() {
      logger.log(TAG_NAME, '_init')
      this._keepScreenOn()
    },

    /**
     * 初始化客户
     * @param param
     * @param param.appKey appKey
     * @param param.debug 是否开启调试模式
     * @param param.baseDomain [可选] 发起请求的domain
     * @param param.deviceId [可选] 设备id
     * @param param.offChatRoom [可选] 关闭聊天室功能
     * @param param.tags [可选] 聊天室当前用户的标签分组，最多填写一个
     * @param param.defaultDirectionalTags [可选] 聊天室定向发送消息的标签组
     * @param param.enableOrientChat [可选] 是否开启聊天室定向发送消息模式，默认关闭
     * @param param.neRtcServerAddresses [可选] G2 sdk 私有化配置
     * @param param.imPrivateConf [可选] IM sdk 私有化配置
     */
    initSDK({
      debug,
      appKey,
      baseDomain,
      deviceId,
      offChatRoom,
      tags,
      defaultDirectionalTags,
      enableOrientChat,
      neRtcServerAddresses,
      imPrivateConf,
      isHideMute,
      enableRealtimeLog
    }) {
      // 初始化
      const roomkit = new RoomKitMiniappSDK({
        debug,
        deviceId: deviceId || uuid(),
      })
      // 聊天室用户标签
      const tagsArr = tags ? [tags] : ['未分类']

      roomkit.initialize({
        appKey,
        baseDomain: baseDomain || 'https://meeting-api.netease.im',
        neRtcServerAddresses,
        imPrivateConf,
        tags: tagsArr,
      })

      isHideMute = isHideMute  === undefined ? this.data.isHideMute : (isHideMute === 'true' || isHideMute === true) 
      enableRealtimeLog = enableRealtimeLog === undefined ? this.data.enableRealtimeLog : (enableRealtimeLog === 'true' || enableRealtimeLog === true)

      this.setData({debug, offChatRoom, enableOrientChat, tags: tagsArr, defaultDirectionalTags, isHideMute})
      
      // 初始化im实例
      this.imImpl = roomkit.getImImpl()
      this.roomkit = roomkit
      this.inRoomService = roomkit.getInRoomService()
      logger.log('inRoomService', this.inRoomService)
      this.roomService = roomkit.getRoomService()
      this.getInRoomVideoController = this.inRoomService.getInRoomVideoController()
      this.getInRoomAudioController = this.inRoomService.getInRoomAudioController()
      logger.log(TAG_NAME, '_initSDK', roomkit)
      // 注册监听
      this.bindInRoomServiceListener();
      this.bindClientEventListener()
      // 开启实时日志上传
      if (enableRealtimeLog) {
        wx.setStorageSync(TAG_NAME + "-enableRealtimeLog", true)
      } else {
        wx.removeStorageSync(TAG_NAME + "-enableRealtimeLog")
      }
    },

    // 组件销毁reset
    async destroy() {
      if(!this.roomkit) {
        logger.log('destroy: roomkit已销毁')
        return
      }
      logger.log(TAG_NAME, 'destroy')
      wx.offNetworkStatusChange()
      this.unbindInRoomServiceListener()
      this.unbindClientEventListener()
      try {
        // await this.logout()
        this.roomkit && this.roomkit.release()
        this.roomkit = null
        this._resetState()
      } catch (error) {
        logger.log('logout failed', error)
      }
    },

    // 获取roomkit
    getRoomKit() {
      return this.roomkit
    },
    // 匿名登录
    anonymousJoinMeeting({roomId, nickName, openCamera, openMicrophone, tag}) {
      logger.log('anonymousJoinMeeting')
      // 超时未加入处理
      this._joinOverTime()
      return this.joinRoom({
        roomId,
        nickName,
        openCamera,
        openMicrophone,
        tag
      })
    },
    // 用户名密码登录
    loginWithAccount (params) {
      return new Promise((resolve, reject) => {
        logger.log(TAG_NAME, 'loginWithAccount', params)
        this.loginState = LoginState.logining
        // 超时未加入处理
        this._joinOverTime()
        this.triggerEvent('onLoginStateChange', this.loginState)
        if (!this.roomkit) {
          throw Error('SDK_UN_INITIALIZE')
        }
        this.roomkit.getAuthService().loginWithAccount(params).then(res => {
          logger.log(TAG_NAME,'loginWithAccount response', res)
          this.loginState = LoginState.logined
          this.triggerEvent('onLoginStateChange', this.loginState)
          resolve()
        }).catch(error => {
          logger.error(TAG_NAME, 'loginWithAccount fail: ', error)
          reject(error)
        })
      })
    },

    // token登录
    loginWithToken(params) {
      return new Promise((resolve, reject) => {
        logger.log(TAG_NAME, 'loginWithToken', params)
        this.loginState = LoginState.logining
        // 超时未加入处理
        this._joinOverTime()
        this.triggerEvent('onLoginStateChange', this.loginState)
        if (!this.roomkit) {
          throw Error('SDK_UN_INITIALIZE')
        }
        this.roomkit.getAuthService().loginWithToken({
          accountId: params.accountId,
          token: params.token,
        }).then(res => {
          logger.log(TAG_NAME,'loginWithToken response', res)
          this.loginState = LoginState.logined
          this.triggerEvent('onLoginStateChange', this.loginState)
          resolve()
        }).catch(error => {
          logger.error(TAG_NAME, 'loginWithToken fail: ', error)
          reject(error)
        })
      })
    },

    // 登出
    async logout() {
      logger.log(TAG_NAME, 'logout')
      if (this.loginState === LoginState.logouting) {
        return
      }
      try {
        this.loginState = LoginState.logouting
        this.triggerEvent('onLoginStateChange', this.loginState)
        console.log(this.roomkit, 'this.roomkit')
        if (this.roomkit) {
          await this.roomkit.getAuthService().logout()
        }
        this._resetState()
        this.triggerEvent('onLoginStateChange', this.loginState)
        // 向外通知已经退出登录
      } catch (error) {
        logger.error(TAG_NAME, 'logout fail: ', error)
        throw error
      }
    },
    // 进入房间
    async joinRoom ({roomId, nickName, openCamera, openMicrophone, tag}) {
      openCamera = openCamera === 'true' || openCamera === true
      openMicrophone = openMicrophone === 'true' || openMicrophone === true
      logger.log(TAG_NAME, 'joinRoom')
      try {
        const data = await this.roomService.joinRoom({
          roomId, // 房间id
          nickName, // 用户昵称
          tag, // 用户标签，可不填
        },
        {
          noAudio: !openMicrophone, // 不开启音频，默认不开启
          noVideo: !openCamera, // 不开启视频，默认不开启
          noCloudRecord: false, // 不开启屏幕录制，默认不开启
        })
        logger.log(TAG_NAME, data, 'joinRoom: joinRoom success')
        this.setData({
          loading: false,
          myUid: data.avRoomUid
        })
        const myUid = data.avRoomUid
        // 开启聊天室模块
        if (!this.data.offChatRoom) {
          const {enableOrientChat, tags, defaultDirectionalTags} = this.data
          const tagInfo = {
            // enableOrientChat - 是否开启定向发送消息模式，默认关闭
            enableOrientChat: enableOrientChat === undefined ? false : enableOrientChat,
            tags,
            defaultDirectionalTags
          }
          this.setChatRoomInfo(this.inRoomService, nickName, tagInfo)
        }
        // 获取会议信息
        await this.getMeetingInfo(() => {
          // videoAttendeeOff: 入会时关闭摄像头；audioAttendeeOff：入会时关闭麦克风
          logger.log(this.data.videoAttendeeOff, this.data.audioAttendeeOff, 'video audio attendeeOff')
          // 入会时关闭音视频需要逐一提示（主持人不受控制）
          if (this.data.audioAttendeeOff && (this.data.hostUid !== myUid)) {
            wx.showToast({
              title: '您已被静音',
              icon: 'none'
            })
            setTimeout(() => {
              wx.showToast({
                title: '主持人设置了全体关闭视频',
                icon: 'none'
              })
            }, 1500)
          } else if (this.data.videoAttendeeOff && (this.data.hostUid !== myUid)) {
            wx.showToast({
              title: '主持人设置了全体关闭视频',
              icon: 'none'
            })
          }
          // 本端开启音频或者视频(主持人不受控制)
          if (this.data.hostUid === myUid) {
            // 主持人
            if (openCamera || openMicrophone) {
              let mediaType = '' // 为空表示同时播放音视频
              if (openCamera && openMicrophone) {
                mediaType = ''
              } else {
                mediaType = openCamera ? 'video' : 'audio'
              }
              this._playStream(mediaType, this.inRoomService.getMyUserId())
            }
          } else {
            // 非主持人
            const allowOpenCamera = openCamera && !this.data.videoAttendeeOff
            const allowOpenAudio = openMicrophone && !this.data.audioAttendeeOff
            console.log(allowOpenCamera, allowOpenAudio, 'allowOpenCamera allowOpenAudio')
            if (allowOpenCamera || allowOpenAudio) {
              let mediaType = '' // 为空表示同时播放音视频
              if(allowOpenCamera && allowOpenAudio) {
                mediaType = ''
              } else {
                mediaType = allowOpenCamera ? 'video' : 'audio'
              }
              console.log('入会音视频开关设置', mediaType, openMicrophone, openCamera)
              this._playStream(mediaType, this.inRoomService.getMyUserId())
            }
          }
          this._setList()
        })
        this._isActive = true
        this._setToolsHide()
        this._offlineHandle()
      } catch (error) {
        logger.error(TAG_NAME, 'joinRoom fail: ', error)
        this.setData({
          loading: false,
        })
        throw Error('joinRoom fail: ', error)
      }
    },

    /**
     * 退房，停止推流和拉流，并重置数据
     * @param {Boolean} end 如果是房间主持人，在离开房间时是否直接结束房间
     * @returns {Promise}
     */
    async leaveRoom (end = false) {
      logger.log(TAG_NAME, 'leaveRoom')
      try {
        // 避免重复离开(快速离开在入会存在_isActive为undefined的情况)
        if (this._isActive === false) {
          return
        }
        if (!this.roomkit) {
          throw Error('SDK_UN_INITIALIZE')
        }
        await this.roomService.leaveCurrentRoom(end)
        this._isActive = false
        logger.log('leaveRoom successed')
      } catch(err) {
        logger.error(TAG_NAME, 'leaveRoom fail: ', error)
        throw Error('leaveRoom fail: ', error)
      }
    },

    // 加入超时15s后销毁组件（防止小程序SocketTask超出卡在loading页面）
    _joinOverTime() {
      this.joinTimer = setTimeout(async() => {
        if (this.data.loading) {
          logger.error('_joinOverTime 加入会议超时，请删除小程序后重试')
          await this.destroy()
          wx.showToast({
            title: '加入会议超时，请删除小程序后重试',
            icon: 'none',
            duration: 2000
          })
          wx.navigateBack()
        }
        clearTimeout(this.joinTimer)
      }, 15000)
    },

    // 更新用户信息
    _setList() {
      return new Promise(resolve => {
        logger.log(this.inRoomService.getAllUsers(), '_setList getAllUsers')
        const allUserArr = this.inRoomService.getAllUsers()
        const oldAllUserArr = this.data.userList || []
        const myInfo = this.inRoomService.getMyUserInfo()
        logger.log(TAG_NAME, myInfo, 'getMyUserInfo')
        const onlineUserMember = allUserArr.length || 1
        const hostInfo = allUserArr.find(user => user.avRoomUid === this.data.hostUid)
        const focusUid = this.data.meetingInfo && this.data.meetingInfo.focusAvRoomUid
        // 还原焦点视频
        if (focusUid) {
          const focusIndex = allUserArr.findIndex(user => user.avRoomUid === focusUid)
          focusIndex > -1 && (allUserArr[focusIndex] = {...allUserArr[focusIndex], isFocus: true})
        }
        // 设置置顶
        const topUser = oldAllUserArr.find(user => {
          return user.isTop
        })
        if(topUser) {
          const topIndex = allUserArr.findIndex(user => user.accountId === topUser.accountId)
          if(topIndex > -1) {
            allUserArr[topIndex] = {...allUserArr[topIndex], ...{ isTop: true }}
          }
        }
        this.data.userList = allUserArr // 不在setData更新数组，放到sortuserList，否则会页面刷新两次位置不对
        this.setData({
          onlineUserMember,
          smallScreenShow: onlineUserMember > 1,
          myInfo,
          host: hostInfo ? hostInfo.nickName : '',
          hostNickName: hostInfo ? hostInfo.nickName : ''
        }, () => {
          logger.log(this.data.userList, '_setList userList')
          // this.getHostNickName()
          this._sortUserList()
          resolve()
        })
      })
    },

    // 更新自己的信息（操作栏状态）
    _updateMyInfo() {
      let myInfo = this.inRoomService.getMyUserInfo()
      myInfo = {...this.data.myInfo, ...myInfo}
      this.setData({
        myInfo
      })
    },

    /**
     * 设置焦点视频优先级规则
     * 1. 优先展示主持人设置的焦点视频
     * 2. 再展示自己设置的置顶视频
     * 3. 再展示开启了视频画面的视频或者视频共享画面
     * 4. 最后展示开启了麦克风的视频
     **/
    _sortUserList() {
      if(this.data.sortListTimer) {
        return
      }
      // 防止频繁排序更新
      this.data.sortListTimer = setTimeout(() => {
        const userList = this.data.userList
        userList.sort((pre, next) => {
          // 0 表示不变，-1表示pre排前面，1表示next排前面
          if ((pre.screenSharing && next.screenSharing) || (!pre.screenSharing && !next.screenSharing)) { // 都开共享屏幕或都没有共享
            if ((pre.isFocus && next.isFocus) || (!pre.isFocus && !next.isFocus)) { // 都是焦点或者非焦点
              if((pre.isTop && next.isTop) || (!pre.isTop && !next.isTop)) { // 都是置顶或者非置顶
                const isPreVideo = pre.video === 1
                const isNextVideo = next.video === 1 || next.screenSharing === 1
                if((isPreVideo && isNextVideo) || (!isPreVideo && !isNextVideo)) { // 视频或者共享屏幕都开或者都关的时候
                  const isPreAudio = pre.audio === 1
                  const isNextAudio = next.audio === 1
                  if((isPreAudio && isNextAudio) || (!isPreAudio && !isNextAudio)) {// 音频或者共享屏幕都开或者都关的时候
                    if (!isPreAudio && !isNextAudio) {
                      if(pre.stream && next.stream ) { // 都存在流或者都不存在流的时候
                        const isPreHost = pre.avRoomUid === this.data.hostUid
                        const isNextHost = next.avRoomUid === this.data.hostUid
                        if (isPreHost || isNextHost) { // 如果都是静音优先展示主持人画面
                          return !!isPreHost > !!isNextHost ? -1 : 1
                        }else {
                          return 0
                        }
                      } else if(!pre.stream && !next.stream) {
                        return 0
                      } else {
                        return !!pre.stream > !!next.stream ? -1 : 1
                      }
                    } else {
                      pre.volume = pre.volume || 0;
                      next.volume = next.volume || 0;
                      return next.volume === pre.volume ? 0 // 音量相同
                      : (pre.volume > next.volume ?  -1 : 1) // 音量大的排前面
                    }
                  } else {
                    return !!isPreAudio > !!isNextAudio ? -1 : 1
                  }
                } else {
                  return !!isPreVideo > !!isNextVideo ? -1 : 1
                }
              } else { // 有一个置顶
              return !!pre.isTop > !!next.isTop ? -1 : 1
            }
          } else { // 两个不同时为焦点视频
              // 如果pre为焦点则排前面
              return !!pre.isFocus > !!next.isFocus ? -1 : 1
            }
          } else {
            // console.log(pre.screenSharing, next.screenSharing, !!pre.screenSharing , !!next.screenSharing ,  pre.nickName, next.nickName, '!!pre.screenSharing > !!next.screenSharing ')

            // 如果pre为共享屏幕则排前面
            return !!pre.screenSharing > !!next.screenSharing ? -1 : 1
          }
        })
        this.setData({
          userList
        })
        this.data.sortListTimer = null
        logger.log(userList, '设置焦点视频')
      }, 100) // 增加100ms，防止100ms内多次触发
    },

    _setTop(userId) { // 本端置顶
      const index = this.data.userList.findIndex(user => {
        return user.isTop
      })
      index > -1 && (this.data.userList[index].isTop = false)
      this._updateUserById({isTop: true}, userId)
    },
    /**
     * 本端推流
     * @param mediaType 媒体类型，用于更新数据
     */
    _pusherStart() {
      logger.log(TAG_NAME, '_pusherStart')
      if (!this.data.userList.length) return
      let myInfo =  this.data.myInfo
      if (!myInfo) return
      const newInfo = this.inRoomService.getMyUserInfo()
      myInfo = {...myInfo, ...newInfo}

      if (myInfo.stream && myInfo.stream.pusherContext) {
        logger.log(TAG_NAME, '开始推流')
        // 推流
        // myInfo.stream.pusherContext.stop({
        //   complete: () => {
        //     logger.log(TAG_NAME, '重新推流')
            myInfo.stream.pusherContext.start({
              success: () => {
                logger.log(TAG_NAME, '推流成功')
              },
              fail: (err) => {
                logger.error(TAG_NAME, '推流失败', err)
              },
            })
          // },
        // })
      }
      this.setData({
        myInfo
      })
      this._updateUserById({
        audio: newInfo.audio,
        video: newInfo.video,
        stream: myInfo.stream
      }, myInfo.accountId).then(() => {
        this._sortUserList()
      })
    },

    /**
     * 重置状态
     */
    _resetState() {
      this.setData({
        userList: [],
        showChatRoom: false,
        isAudioConfirm: false,
        isVideoConfirm: false,
        isSettingConfirm: false,
        hasHided: false,
        isOriginCameraOn: false,
        isOriginMicOn: false
      })
      this._isActive = false
      this.loginState = LoginState.idle
      clearTimeout(this.joinTimer)
      wx.removeStorageSync(TAG_NAME + "-enableRealtimeLog")
      console.log('_resetState done')
      // todo 是否需要去除roomkit
      // this.roomkit = null
    },

    /**
     * 保持屏幕常亮
     */
    _keepScreenOn() {
      setInterval(() => {
        wx.setKeepScreenOn({
          keepScreenOn: true,
        })
      }, 20000)
    },

    // 延迟6s隐藏操作栏
    _setToolsHide() {
      this.timer && clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        // 5s内没有点击行为就隐藏tools
        if (!this.boradClick) {
          this.setData({
            toolsVisible: false,
          })
        } else {
          this._setToolsHide()
          this.setData({
            toolsVisible: false,
          })
          this.boradClick = false
        }
      }, 6000)
    },

    // 点击空白区显示隐藏操作栏
    _onclickRoomBoard() {
      let toolsVisible = this.data.toolsVisible
      this.setData({
        toolsVisible: !toolsVisible,
      })
      this.boradClick = true
      this._setToolsHide()
    },

    // 点击操作栏
    _onclickTools() {
      this.boradClick = true
      this._setToolsHide()
    },

    /**
    * 切换前后摄像头-默认front
    */
    switchCamera() {
      const position = this.getInRoomVideoController.switchCamera()
      logger.log(TAG_NAME, 'switchCamera', position)
      const myIndex = this.data.userList.findIndex(user => user.avRoomUid === this.data.myUid)
      if(myIndex < 0) {
        return
      }
      this.data.userList[myIndex].stream.frontCamera = position
    },

    /**
    * 切换前后摄像头-默认speaker
    */
    switchAudioOutPutMode () {
      const audioOutPutMode = this.data.audioOutPutMode
      logger.log(TAG_NAME, 'switchAudioOutPutMode', audioOutPutMode)
      this.setData({
        audioOutPutMode: audioOutPutMode === 'speaker' ? 'ear' : 'speaker'
      })
    },

    // 本端视频开关
    _toggleVideo () {
      const enableCamera = this.data.myInfo && this.data.myInfo.stream ? this.data.myInfo.video === 1 : false
      logger.log(TAG_NAME, `_toggleVideo ${enableCamera ? '关闭' : '开启'}摄像头`)

      // 主持人全体关闭且不让自主打开videoAllowSelfOn存在undefined(主持人身份不影响)
      if (this.data.videoAllowSelfOn === false && !enableCamera && (this.data.hostUid !== this.data.myUid)) {
        wx.showToast({
          title: '主持人管控中，无法开启',
          icon: 'none',
          duration: 2000,
        })
        return
      }
      // 未开启摄像头权限
      logger.log(this.data.noVideoAuthSetting, 'noVideoAuthSetting')
      if (this.data.noVideoAuthSetting) {
        this.handleOpenSetting()
        return
      }
      this.getInRoomVideoController.muteMyVideo(enableCamera)
      this.setData({
        btnVideoLoading: true
      })
    },

    // 本端音频开关
    _toggleAudio () {
      const enableMic = this.data.myInfo && this.data.myInfo.stream ? this.data.myInfo.audio === 1 : false
      logger.log(TAG_NAME, `_toggleAudio ${enableMic ? '关闭' : '开启'}麦克风`)

      // 主持人全体关闭且不让自主打开audioAllowSelfOn存在undefined
      if (this.data.audioAllowSelfOn === false && !enableMic && (this.data.hostUid !== this.data.myUid)) {
        wx.showToast({
          title: '主持人管控中，无法开启',
          icon: 'none',
          duration: 2000,
        })
        return
      }
      // 未开启麦克风权限
      if (this.data.noAudioAuthSetting) {
        this.handleOpenSetting()
        return
      }
      this.getInRoomAudioController.muteMyAudio(enableMic)
      this.setData({
        btnAudioLoading: true
      })
    },


    // 关闭本端音视频
    async muteMyMedia() {
      try {
        logger.log('muteMyMedia')
        const enableCamera = this.data.myInfo && this.data.myInfo.stream ? this.data.myInfo.video === 1 : false
        const enableMic = this.data.myInfo && this.data.myInfo.stream ? this.data.myInfo.audio === 1 : false
        if (enableMic) {
          await this.getInRoomAudioController.muteMyAudio(enableMic)
          this.setData({
            isOriginMicOn: true,
          })
        }
        if (enableCamera) {
          await this.getInRoomVideoController.muteMyVideo(enableCamera)
          this.setData({
            isOriginCameraOn: true,
          })
        }
      } catch(error) {
        logger.error(error, 'muteMyMedia')
        throw Error(error, 'muteMyMedia')
      }
    },

    // 小程序启动，或从后台进入前台显示时需要触发的toast提示
    onShowToast() {
      // 如果被动关闭了音频
      if (this.data.isOriginMicOn || this.data.isOriginCameraOn) {
        // 用定时器是因为屏幕翻转，toast样式被覆盖
        setTimeout(() => {
          wx.showToast({
            title: '您的音视频设备已被关闭，如有需要请重新开启',
            icon: 'none',
            duration: 3000,
            success: () => {
              this.setData({
                isOriginCameraOn: false,
                isOriginMicOn: false,
                hasHided: false
              })
            }
          })
        }, 2000)
      }
    },

    /**
     * 播放流数据
     * @param uid
     * @param mediaType 播放的媒体类型
     */
    _playStream(mediaType, userId) {
      logger.log(TAG_NAME, '_playStream', mediaType, userId)
      if (mediaType === 'slaveAudio') return
      // 如果本端不需要订阅
      if(this.inRoomService.isMySelf(userId)) {
        logger.log(TAG_NAME, '_playStream 本端', mediaType, userId)
        this.getInRoomVideoController
        .attachRendererToUserVideoStream({mediaType, userId})
        .then(() => {
          logger.info(TAG_NAME, '本端attach成功')
          this._pusherStart()
        })
        return
      }
      // 订阅主流
      if(mediaType !== 'screen') {
        logger.log(TAG_NAME, '_playStream 其他端主流', mediaType, userId)
        this.getInRoomVideoController.subscribeRemoteVideo({
          userId,
          subscribe: true,
          mediaType,
          context: this,
        }).then(stream => {
          const userInfo = this.inRoomService.getUserInfoById(userId)
          if (!userInfo) return
          logger.info(TAG_NAME, '订阅主流成功', stream, userInfo)
            // 发布音视频
          
          this._updateUserById({
            stream: {
              ...userInfo.stream,
              url: userInfo.stream && userInfo.stream.url,
            }
          }, userId).then(() => {
            this.getInRoomVideoController.attachRendererToUserVideoStream({mediaType, userId}).then(() => {
              const userInfo = this.inRoomService.getUserInfoById(userId)
              logger.info(TAG_NAME, '播放主流成功', userInfo)
            }).catch(err => {
              const userInfo = this.inRoomService.getUserInfoById(userId)
              logger.error(TAG_NAME, '播放主流失败：', err, userInfo)
            })
          })
        }).catch(err => {
          logger.error('订阅主流失败：', err, userId)
        })
      }else {
        if(this.inRoomService.isMySelf(userId)) { // 如果本端不需要订阅
          // todo 后续添加小程序屏幕共享
          return
        }
        logger.log(TAG_NAME, '_playStream 其他端辅流', mediaType, userId)
        this.getInRoomVideoController.subscribeRemoteVideoSubStream({
          userId,
          subscribe: true,
          context: this,
        }).then(stream => {
          const userInfo = this.inRoomService.getUserInfoById(userId)
          logger.info(TAG_NAME, '订阅辅流成功', stream, userInfo)
            // 发布音视频
          this._updateUserById({
            stream: {
              ...userInfo.stream,
              subStreamUrl: userInfo.stream.subStreamUrl,
            }
          }, userId).then(() => {
            this.getInRoomVideoController.attachRendererToUserVideoSubStream({userId}).then(() => {
              const userInfo = this.inRoomService.getUserInfoById(userId)
              logger.info(TAG_NAME, '播放辅流成功', userInfo, this.data.userList)
            }).catch(err => {
              const userInfo = this.inRoomService.getUserInfoById(userId)
              logger.error(TAG_NAME, '播放辅流失败：', err, userInfo)
            })
          })
        }).catch(err => {
          logger.error('订阅辅流失败：', err, userId)
        })
      }
    },

    /**
     * 小画面相关事件
     */
    _toggleSmallScreen() {
      this.setData({
        smallScreenShow: !this.data.smallScreenShow
      })
    },

    _playerStateChange(event) {
      const { code, message, nickname, userId } = event.detail
      // const { nickname } = event.currentTarget.dataset
      switch (code) {
        case -2301:
          logger.error(`获取 ${nickname} 流失败`, message, code, userId)
          // wx.showToast({
          //   title: `获取 ${nickname} 流失败`,
          //   icon: 'none',
          //   duration: 2000,
          // })
          if (typeof this.data.retryRemoteObj[userId] !== 'number') {
            // 第一次拉流失败，放入待重连的列表中
            this.data.retryRemoteObj[userId] = -1
            if (this.data.isConnected) {
              this.retryRemoteStream(userId)
            }
          } else if (this.data.retryRemoteObj[userId] > -1) {
            // 已重试过一次，直接退出
            wx.showToast({
              title: `请重新加入房间`,
              icon: 'none',
              duration: 2000,
            })
            this.triggerEvent('leave')
            return
          }
          break
        case 6000:
          logger.error(TAG_NAME, message, code)
          // wx.showToast({
          //   title: `live-player拉流挂起`,
          //   icon: 'none',
          //   duration: 2000,
          // })
          break;
        default:
          logger.warn(TAG_NAME, '_playerStateChange', message, code, userId)
          break
      }
    },

    // 重新连接远端流
    retryRemoteStream(userId) {
      logger.log(TAG_NAME, 'retryRemoteStream', userId)
      const retryMember = userId
        ? [userId]
        : Object.keys(this.data.retryRemoteObj)
      const retryRemoteObj = this.data.retryRemoteObj
      logger.debug('断网重连后，重新拉之前失败的远端流', retryRemoteObj)
      retryMember.map(async (userId) => {
        if (retryRemoteObj[userId] === -1) {
          logger.debug('=== 重试 ', userId)
          const member = this.data.userList.filter(
            (item) => item.accountId === userId
          )
          if (member) {
            const { stream, accountId } = member
            try {
              retryRemoteObj[userId]++
              if (member.screenSharing === 1) {
                stream.subStreamUrl = ''
                this._updateUserById({ stream }, accountId)
                this.playRemoteSubVideo(accountId)
              } else if (member.video === 1) {
                stream.url = ''
                this._updateUserById({ stream }, accountId)
                this._playStream('video', accountId)
              } else if (member.audio === 1) {
                this._playStream('audio', accountId)
              } else {
                retryRemoteObj[userId]--
              }
            } catch (error) {
              console.error(error, 'retryRemoteStream err')
              wx.showToast({
                title: `请重新加入房间`,
                icon: 'none',
                duration: 2000,
              })
              this.triggerEvent('leave')
            }
          }
        }
      })
      // 重置每个成员的画面，修复推流正常但画面卡住的问题
      const list = this.data.userList
      this.setData({
        userList: [],
      })
      this.setData({
        userList: list,
      })
    },

    // 对端音量大小监听
    _playerAudioVolumeNotify:prevent(function (event) {
      const {userId, volume} = event.detail
      // console.log('_playerAudioVolumeNotify', userId, volume)
      // const userId = event.currentTarget.dataset.userid
      // const volume = event.detail.volume
      // logger.logButNotReport(TAG_NAME, userId, '_playerAudioVolumeNotify', volume)

      if (!volume) return
      const hasFocusUser = this.data.userList.find(user => { return user.isFocus || user.isTop })
      // 存在焦点视频就不设置了
      if (hasFocusUser) return
      // 5s更新参会者音量
      this._updateUserById({volume}, userId).then(() => {
        this._sortUserList()
      })
    }, 5000),
    // 本端音量大小监听
    _pusherAudioVolumeNotify:prevent(function (event) {
      const {userId, volume} = event.detail
      // console.log('pusherAudioVolumeNotify', userId, volume)
      // const userId = event.currentTarget.dataset.userid
      // const volume = event.detail.volume
      // logger.logButNotReport(TAG_NAME, userId, '_pusherAudioVolumeNotify', volume)
      if (!volume) return
      const hasFocusUser = this.data.userList.find(user => { return user.isFocus || user.isTop })
      // 存在焦点视频就不设置了
      if (hasFocusUser) return
      // 5s更新本端音量
      this._updateUserById({volume}, userId).then(() => {
        this._sortUserList()
      })
    }, 5000),

    _pusherStateChangeHandler(event) {
      const { code, message } = event.detail
      switch (code) {
        case 0: // 未知状态码，不做处理
          logger.log(TAG_NAME, message, code)
          break
        case 1001:
          logger.log(TAG_NAME, '已经连接推流服务器', code)
          break
        case 1002:
          logger.log(TAG_NAME, '已经与服务器握手完毕,开始推流', code)
          break
        case 1003:
          logger.log(TAG_NAME, '打开摄像头成功', code)
          break
        case 1004:
          logger.log(TAG_NAME, '录屏启动成功', code)
          break
        case 1005:
          logger.log(TAG_NAME, '推流动态调整分辨率', code)
          break
        case 1006:
          logger.log(TAG_NAME, '推流动态调整码率', code)
          break
        case 1007:
          logger.log(TAG_NAME, '首帧画面采集完成', code)
          break
        case 1008:
          logger.log(TAG_NAME, '编码器启动', code)
          break
        case 2003:
          logger.log(TAG_NAME, '渲染首帧视频', code)
          break
        case -1301:
          logger.error(TAG_NAME, '打开摄像头失败: ', code)
          break
        case -1302:
          logger.error(TAG_NAME, '打开麦克风失败: ', code)
          break
        case -1303:
          logger.error(TAG_NAME, '视频编码失败: ', code)
          break
        case -1304:
          logger.error(TAG_NAME, '音频编码失败: ', code)
          break
        case -1307:
          logger.error(TAG_NAME, '推流连接断开: ', code)
          this._pusherStart()
          this._updateMyInfo()
          break
        case 5000:
          logger.log(TAG_NAME, '小程序被挂起: ', code)
          // 20200421 iOS 微信点击胶囊圆点会触发该事件
          // 触发 5000 后，底层SDK会退房，返回前台后会自动进房
          break
        case 5001:
          // 20200421 仅有 Android 微信会触发该事件
          logger.log(TAG_NAME, '小程序悬浮窗被关闭: ', code)
          break
        case 1021:
          logger.log(TAG_NAME, '网络类型发生变化，需要重新进房', code)
          break
        case 2007:
          logger.log(TAG_NAME, '本地视频播放loading: ', code)
          break
        case 2004:
          logger.log(TAG_NAME, '本地视频播放开始: ', code)
          break
        default:
          logger.log(TAG_NAME, message, code)
          break
      }
    },

    // pusher渲染错误事件
    _pusherErrorHandler(event) {
      logger.log(TAG_NAME, '_pusherErrorHandler', event.detail.errCode )
      // 未开启摄像头或者麦克风权限:需要关闭音视频按钮
      if (event.detail.errCode === 10001 || event.detail.errCode === 10002) {
        if (event.detail.errCode === 10001) {
          this.getInRoomVideoController.muteMyVideo(true)
          this.setData({
            noVideoAuthSetting: true
          })
        }
        if (event.detail.errCode === 10002) {
          this.getInRoomAudioController.muteMyAudio(true)
          this.setData({
            noAudioAuthSetting: true
          })
        }

        // 温馨提示弹窗显示
        setTimeout(() => {
          this.handleOpenSetting()
        }, 1000)
      }
    },

    // 弹窗让用户打开摄像头麦克风
    handleOpenSetting() {
      logger.log(this.data.isSettingConfirm, 'this.data.isSettingConfirm')
      if (this.data.isSettingConfirm) return
      const _this = this
      wx.showModal({
        title: '无法使用摄像头和麦克风',
        content: '该功能需要摄像头，请允许小程序访问您的摄像头和麦克风权限',
        confirmText: '前往设置',
        success (res) {
          if (res.confirm) {
            wx.openSetting({
              success(res) {
                logger.log('成功', res.authSetting)
                _this.setData({
                  isSettingConfirm: false,
                  noAudioAuthSetting: false,
                  noVideoAuthSetting: false
                })
                wx.navigateBack()
              },
              fail(err) {
                _this.setData({
                  isSettingConfirm: false
                })
                logger.log('失败', err)
              }
            })
          } else if (res.cancel) {
            logger.log('用户放弃授权')
            _this.setData({
              isSettingConfirm: false,
              noAudioAuthSetting: true,
              noVideoAuthSetting: true
            })
          }
        }
      })
      this.setData({
        isSettingConfirm: true
      })
    },

    // 点击离开会议
    _clickLeaveRoom(event) {
      const affirm = event.detail.value
      if (!affirm) return
      // 向外通知已经离开房间
      this.triggerEvent('leave')
      // this.leaveRoom()
    },

    _showLeaveRoomSheet () {
      this.setData({
        leaveRoomSheetShow: true
      })
    },

    // 点击用户列表:只有开启视频的用户才能置顶
    _clickUserList(event) {
      const { accountid, name, video, isfocus, istop } = event.currentTarget.dataset
      console.log(accountid, name, video, isfocus, istop, '_clickUserList')
      // 没有开启视频&没有置顶
      if (!video && !istop) return
      // 已经置顶
      const focusSheetBtns = istop ? [{text: '取消置顶', value: false}] : [{text: '确认置顶', value: true}]
      this.setData({
        focusSheetBtns,
        currentUserUserId: accountid,
        currentUserIsTop: istop,
        currentUserIsFocus: isfocus,
        selectedUserNickName: name,
        focusSheetShow: true
      })
    },

    // 点击置顶确认按钮
    _clickSetFocusUser(event) {
      const affirm = event.detail.value
      logger.log(affirm,event, 'affirm')
      if (affirm) {
        this.handleSetFocusUser()
      } else {
        // 取消置顶
        this.handleCancelFocusUser()
      }
    },

    // 设置置顶视频
    handleSetFocusUser() {
      logger.log(TAG_NAME, 'handleSetFocusUser', this.data.currentUserUserId)
      // 已经是焦点视频
      if (this.data.currentUserIsFocus) {
        wx.showToast({
          title: '已在画面中展示',
          icon: 'none',
          duration: 2000
        })
        this.setData({
          focusSheetShow: false
        })
        return
      }
      const hasSetTopUser = this.data.userList.find(user => user.isTop)
      // 取消已经置顶的
      if (hasSetTopUser) {
        this._updateUserById({isTop: false}, hasSetTopUser.accountId).then(() => {
          this._updateUserById({isTop: true}, this.data.currentUserUserId).then(() => {
            this._sortUserList()
          })
        })
      } else {
        this._updateUserById({isTop: true}, this.data.currentUserUserId).then(() => {
          this._sortUserList()
        })
      }
      this.setData({
        focusSheetShow: false
      })
      wx.showToast({
        title: '置顶成功',
        icon: 'none',
        duration: 2000
      })
    },

    // 取消置顶视频
    handleCancelFocusUser() {
      logger.log(TAG_NAME, 'handleCancelFocusUser', this.data.currentUserUserId)
      this._updateUserById({isTop: false}, this.data.currentUserUserId).then(() => {
        this._sortUserList()
      })
      this.setData({
        currentUserUserId: '',
        currentUserIsTop: '',
        currentUserIsFocus: '',
        selectedUserNickName: '',
        focusSheetShow: false
      })
      wx.showToast({
        title: '已取消置顶',
        icon: 'none',
        duration: 2000
      })
    },

    // 打开会议详情弹窗
    _handleOpenInfoDialog() {
      this.setData({
        meetingInfoDialogShow: true
      })
    },

    // 打开成员列表弹窗
    handleShowUserList() {
      if (!this.data.userList.length) return
      this.setData({
        memberListDialogShow: true
      })
    },

    /**
     * 复制会议id
     */
    handleCopy(event) {
      wx.setClipboardData({
        data: event.currentTarget.dataset.copy
      })
    },

    /**
     * 获取会议信息
     * type: 控制类型，audio音频，video视频，whiteboard白板
     * state: 全局控制状态，1：全体关闭控制，0：取消全体关闭控制
     * attendeeOff: 入会后自动关闭，0：无，1：关闭，2：关闭且不能自行操作，默认不操作(会议中不可修改)
     * allowSelfOn: 允许自行解除关闭控制，true：允许，false：不允许，默认允许(会议中可二次修改)
     * meetingMaxCount: 创建会议时设置的总人数，没有时页面展示在线人数，可以设置比在线人数少
     */
    getMeetingInfo(callback) {
      return this.roomkit.inRoomServiceImpl.getCurrentRoomInfoForce()
        .then(info => {
          const extraData = info.roomInfo.extraData && JSON.parse(info.roomInfo.extraData)
          logger.log(TAG_NAME, 'getMeetingInfo', info.roomInfo)
          info.roomInfo.settings.controls && info.roomInfo.settings.controls.forEach(item => {
            // 是否允许自我解除静音
            if (item.type === 'audio') {
              this.setData({
                audioAllowSelfOn: item.allowSelfOn === undefined ? true : item.allowSelfOn,
                audioAttendeeOff: item.state === 1 ? item.attendeeOff : false
              })
            } else if (item.type === 'video') {
              this.setData({
                videoAllowSelfOn: item.allowSelfOn === undefined ? true : item.allowSelfOn,
                videoAttendeeOff: item.state === 1 ? item.attendeeOff : false
              })
            }
          })
          this.setData({
            meetingInfo: info.roomInfo,
            meetingMaxCount: extraData && extraData.maxCount,
            meetingExtraData: extraData,
            hostUid: info.roomInfo && info.roomInfo.hostAvRoomUid // joinRoom时需要拿到此字段
          })
          this.getHostNickName()
          // 部分手机resolve出去不执行，故采取callback
          callback && callback()
          return Promise.resolve()
        })
        .catch(error => {
          logger.error(TAG_NAME, 'getMeetingInfo fail: ', error);
          throw Error('getMeetingInfo err', error)
        })
    },

    /**
     * 获取此时主持人昵称
     */
    getHostNickName() {
      const hostAccountId = this.data.meetingInfo && this.data.meetingInfo.hostAccountId
      if (hostAccountId && this.data.userList.length) {
        const hostInfo = this.data.userList.find(user => user.accountId === hostAccountId)
        // 主持人离开后信息需要置空
        this.setData({
          hostNickName: hostInfo && hostInfo.nickName || '',
          hostUid: hostInfo && hostInfo.avRoomUid || ''
        })
      }
    },

    // 服务器变成推拉流地址
    _onSyncDone(data) {
      logger.log(TAG_NAME, '_onSyncDone', data)
    },
    _onRoomUserJoin(members) {
      logger.log(TAG_NAME, '_onRoomUserJoin', members.userList)
      this._setList()
    },
    _onRoomUserLeave(data) {
      logger.log(TAG_NAME, '_onRoomUserLeave', data.userList)
        // 主持人离开
        if (data.userList[0].avRoomUid === this.data.meetingInfo.focusAvRoomUid) {
          this.setData({
            'meetingInfo.focusAvRoomUid': '',
          })
        }
      this._setList()
    },
    // 通知应用程序房间被解散
    _onRtcChannelClosed(data) {
      logger.log('会议结束', data, '_onRtcChannelClosed')
      wx.showToast({
        title: '主持人已结束会议',
        icon: 'none'
      })
      this.roomService.destroy()
      this.unbindClientEventListener()
      this.unbindInRoomServiceListener()
      this.triggerEvent('meetingClosed')
    },
    _onRoomUserStreamAdded(data) {
      logger.log(TAG_NAME, '_onRoomUserStreamAdded', data)
      try {
        const {userId, mediaType} = data
        this._playStream(mediaType, userId)
      } catch (error) {
        logger.error(TAG_NAME, '_onStreamAdded fail: ', error)
      }
    },
    _onRoomUserStreamRemove(data) {
      logger.log(TAG_NAME, '_onRoomUserStreamRemove', data)
    },
    _onRtcError(data) {
      logger.log(TAG_NAME, '_onRtcError', data)
    },
    _onRtcSyncDone(data) {
      logger.log(TAG_NAME, '_onRtcSyncDone', data)
    },
    _onRtcReconnected(data) {
      logger.log(TAG_NAME, '_onRtcReconnected', data)
      this.getMeetingInfo().then(() => {
        this._updateStreamByOffline()
      })
    },
    async _onRtcDisconnected() {
      logger.log('会议结束', '_onRtcDisconnected')
      // 已经触发了踢出，否则提示消息不准确
      if (this.data.userIsKicked) return
      // wx.showToast({
      //   title: '当前会议连接已断开',
      //   icon: 'none',
      //   duration: 2000
      // })
      // this.leaveRoom()
      await this.logout()
      // this.roomService.destroy()
      this.triggerEvent('disconnect')
    },
    // 被踢出
    _onKicked(event) {
      logger.log('会议结束', TAG_NAME, '_onKicked', event)
      this.setData({
        userIsKicked: true
      })
      wx.showToast({
        title: '因被主持人移出或切换至其他设备，您已退出会议',
        icon: 'none',
        duration: 2000
      })
      this.roomService.destroy()
      this.unbindInRoomServiceListener()
      this.unbindClientEventListener()
      // 延迟执行，以免异常弹窗未被看到
      setTimeout(() => {
        this.triggerEvent('kicked')
      }, 1000)
    },
    _onAblityNotSupport(event) {
      logger.log('会议结束', TAG_NAME, '_onAblityNotSupport', event)
      wx.showToast({
        title: `房间媒体协商出现问题：${event.nickName || event.userId || event.uid}的视频无法解码`,
        icon: 'none',
        duration: 2000
      })
    },
    _onRtcSendCommandOverTime(data) {
      logger.log(TAG_NAME, '_onRtcSendCommandOverTime')
    },

    setChatRoomInfo(inRoomService, nickName, tagInfo) {
      // 获取聊天室controller & accountInfo
      const {roomInfo} = inRoomService.getCurrentRoomInfo();
      const accountInfo = this.roomkit.authServiceImpl.getAccountInfo()
      const { imAccid, imAppKey, imToken } = accountInfo
      const chatRoomController = inRoomService.getInRoomChatController()
      this.setData({
        chatRoomController: {
          enterChatRoom: chatRoomController.enterChatRoom.bind(chatRoomController),
          exitChatRoom: chatRoomController.exitChatRoom.bind(chatRoomController),
          sendTextMessage: chatRoomController.sendTextMessage.bind(chatRoomController),
          resendTextMessage: chatRoomController.resendTextMessage.bind(chatRoomController),
          updateChatRoomRole: chatRoomController.updateChatRoomRole.bind(chatRoomController),
          // destroy: chatRoomController.destroy.bind(chatRoomController),
          getMembers: chatRoomController.getMembers.bind(chatRoomController),
          getHistoryMsgs: chatRoomController.getHistoryMsgs.bind(chatRoomController),
          on: this.inRoomService.on.bind(this.inRoomService),
          off: this.inRoomService.off.bind(this.inRoomService),
        },
        chatRoomInfo: {
          imAccid,
          imAppKey,
          imToken,
          chatroomId: roomInfo.chatRoomId,
          chatroomNick: nickName,
          tagInfo
        }
      })
    },
    toggleChatRoom() {
      if(!this.data.chatRoomInfo || !this.data.chatRoomController) {
        wx.showToast({
          title: '正在初始化请稍后',
          icon: 'none'
        })
        return
      }
      this.setData({
        showChatRoom: true
      })
    },
    onChatRoomClose() {
      this.setData({
        showChatRoom: false
      })
    },
    onChatRoomEnter() {
      // 删除该方法则聊天室无滑入动画效果
    },
    onUnReadChange(data) {
      this.setData({
        unReadCount: data.detail
      })
    },
    // G2的监听
    bindClientEventListener() {
      const inRoomService = this.inRoomService

      inRoomService.on(CLIENT_EVENT.CLIENT_JOIN, this._onRoomUserJoin.bind(this))
      inRoomService.on(CLIENT_EVENT.CLIENT_LEAVE, this._onRoomUserLeave.bind(this))
      inRoomService.on(CLIENT_EVENT.LIVEROOMCLOSE, this._onRtcChannelClosed.bind(this))
      inRoomService.on(CLIENT_EVENT.STREAM_ADDED, this._onRoomUserStreamAdded.bind(this))
      inRoomService.on(CLIENT_EVENT.STREAM_REMOVED, this._onRoomUserStreamRemove.bind(this))
      inRoomService.on(CLIENT_EVENT.ERROR, this._onRtcError.bind(this))
      inRoomService.on(CLIENT_EVENT.SYNC_DONE, this._onRtcSyncDone.bind(this))
      inRoomService.on(CLIENT_EVENT.RECONNECT, this._onRtcReconnected.bind(this))
      inRoomService.on(CLIENT_EVENT.DISCONNECT, this._onRtcDisconnected.bind(this))
      inRoomService.on(CLIENT_EVENT.SENDCOMMANDOVERTIME, this._onRtcSendCommandOverTime.bind(this))
      inRoomService.on(CLIENT_EVENT.CLIENT_BANNED, this._onKicked.bind(this))
      inRoomService.on(CLIENT_EVENT.ABILITY_NOT_SUPPORT, this._onAblityNotSupport.bind(this))
    },
    bindInRoomServiceListener() {
      const inRoomService = this.inRoomService

      // 会控
      inRoomService.on( // 音频更新
        MEETING_EVENT.ROOM_USER_AUDIO_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_AUDIO_STATUS_CHANGED))
      inRoomService.on( // 视频更新
        MEETING_EVENT.ROOM_USER_VIDEO_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_VIDEO_STATUS_CHANGED))
      inRoomService.on( // 焦点视频更新
        MEETING_EVENT.ROOM_USER_VIDEO_PIN_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_VIDEO_PIN_STATUS_CHANGED))
      inRoomService.on( // 主持人更新
        MEETING_EVENT.ROOM_HOST_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_HOST_CHANGED))
      inRoomService.on( // 用户昵称更新
        MEETING_EVENT.ROOM_USER_NAME_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_NAME_CHANGED))
      inRoomService.on( // 共享屏幕状态更新
        MEETING_EVENT.ROOM_USER_SCREEN_SHARE_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_SCREEN_SHARE_STATUS_CHANGED))
      inRoomService.on( // 锁定会议更新
        MEETING_EVENT.ROOM_LOCK_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_LOCK_STATUS_CHANGED))
    },
    _bindMeetingControlListener(type) {
      const handleMap = {
        [MEETING_EVENT.ROOM_USER_AUDIO_STATUS_CHANGED]: this._onRoomUserAudioStatusChanged.bind(this),
        [MEETING_EVENT.ROOM_USER_VIDEO_STATUS_CHANGED]: this._onRoomUserVideoStatusChanged.bind(this),
        [MEETING_EVENT.ROOM_USER_VIDEO_PIN_STATUS_CHANGED]: this._onRoomUserVideoPinStatusChanged.bind(this),
        [MEETING_EVENT.ROOM_HOST_CHANGED]: this._onRoomHostChanged.bind(this),
        [MEETING_EVENT.ROOM_USER_NAME_CHANGED]: this._onRoomUserNameChanged.bind(this),
        [MEETING_EVENT.ROOM_USER_SCREEN_SHARE_STATUS_CHANGED]: this._onRoomUserScreenShareStatusChanged.bind(this),
        [MEETING_EVENT.ROOM_LOCK_STATUS_CHANGED]: this._onRoomLockStatusChanged.bind(this),
      }
      return handleMap[type]
    },

    // G2的监听
    unbindClientEventListener() {
      const inRoomService = this.inRoomService

      inRoomService.off(CLIENT_EVENT.CLIENT_JOIN)
      inRoomService.off(CLIENT_EVENT.CLIENT_LEAVE)
      inRoomService.off(CLIENT_EVENT.LIVEROOMCLOSE)
      inRoomService.off(CLIENT_EVENT.STREAM_ADDED)
      inRoomService.off(CLIENT_EVENT.STREAM_REMOVED)
      inRoomService.off(CLIENT_EVENT.CLIENT_BANNED)
      inRoomService.off(CLIENT_EVENT.ERROR)
      inRoomService.off(CLIENT_EVENT.SYNC_DONE)
      inRoomService.off(CLIENT_EVENT.RECONNECT)
      inRoomService.off(CLIENT_EVENT.DISCONNECT)
      inRoomService.off(CLIENT_EVENT.SENDCOMMANDOVERTIME)
      inRoomService.off(CLIENT_EVENT.ABILITY_NOT_SUPPORT)
    },
    unbindInRoomServiceListener() {
      const inRoomService = this.inRoomService

      // 会控
      inRoomService.off( // 音频更新
        MEETING_EVENT.ROOM_USER_AUDIO_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_AUDIO_STATUS_CHANGED))
      inRoomService.off( // 视频更新
        MEETING_EVENT.ROOM_USER_VIDEO_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_VIDEO_STATUS_CHANGED))
      inRoomService.off( // 焦点视频更新
        MEETING_EVENT.ROOM_USER_VIDEO_PIN_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_VIDEO_PIN_STATUS_CHANGED))
      inRoomService.off( // 主持人更新
        MEETING_EVENT.ROOM_HOST_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_HOST_CHANGED))
      inRoomService.off( // 用户昵称更新
        MEETING_EVENT.ROOM_USER_NAME_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_NAME_CHANGED))
      inRoomService.off( // 共享屏幕状态更新
        MEETING_EVENT.ROOM_USER_SCREEN_SHARE_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_USER_SCREEN_SHARE_STATUS_CHANGED))
      inRoomService.off( // 锁定会议更新
        MEETING_EVENT.ROOM_LOCK_STATUS_CHANGED,
        this._bindMeetingControlListener(MEETING_EVENT.ROOM_LOCK_STATUS_CHANGED))
    },

    _onRoomUserAudioStatusChanged({
      userId,
      status, // 1: 'audioOn', 2: 'audioOff', 3: 'mutedByHost', 4: 'waitingOpen',
    }) {
      logger.log(TAG_NAME, 'event: 更新音频状态', userId, status)
      const isMySelf = this.inRoomService.isMySelf(userId)
      const myInfo = this.data.myInfo
      // 主持人开启
      if(status === 'waitingOpen') {
        if(!isMySelf || this.data.isAudioConfirm) return
        // 已经开启了就不处理(roomkit会将audio改为4,需要还原状态)
        if (myInfo.audio === 1) return
        wx.showModal({
          title: '是否打开麦克风',
          content: '主持人邀请您发言，是否开启麦克风以使其他成员听到您的声音',
          confirmText: '是',
          cancelText: '否',
          success: (res) => {
            // 未开启麦克风权限
            if (this.data.noAudioAuthSetting) {
              this.setData({
                isAudioConfirm: false
              })
              this.handleOpenSetting()
              return
            }
            if (res.confirm) {
              this.setData({
                audioAllowSelfOn: true,
                isAudioConfirm: false
              })
              wx.showToast({
                title: '开启成功，请发言',
                icon: 'none',
                duration: 2000
              })
              this.getInRoomAudioController.muteMyAudio(false)
            } else if (res.cancel) {
              logger.log('用户点击取消')
              this.setData({
                isAudioConfirm: false
              })
            }
          }
        })
        this.setData({
          isAudioConfirm: true
        })
        return
      }
      // 开启麦克风
      if (status === 'audioOn') {
        if (isMySelf) {
          // 未开启麦克风权限
          if (this.data.noAudioAuthSetting) {
            this.setData({
              isAudioConfirm: true
            })
            this.handleOpenSetting()
            return
          }
          this._pusherStart()
          this.setData({
            btnAudioLoading: false
          })
          return
          // 更新操作栏状态
          // this._updateMyInfo()
        }
        this._updateUserById({ audio: 1 }, userId).then(() => {
          this._sortUserList()
          return
        })
      }
      // 关闭麦克风
      if (status === 'mutedByHost' || status === 'audioOff') {
        if(status === 'mutedByHost') {
          // 已经静音了就不处理
          if (isMySelf && myInfo.audio === 1) {
            wx.showToast({
              title: '主持人已关闭您的麦克风',
              icon: 'none',
              duration: 2000
            })
          }
        }
        // 更新操作栏状态
        if (isMySelf) {
          this._updateMyInfo()
        }
        this._updateUserById({ audio: status === 'mutedByHost' ? 3 : 2 }, userId).then(() => {
          this._sortUserList()
          this.setData({
            btnAudioLoading: false
          })
        })
        // 更新会议信息
        this.getMeetingInfo()
      }
    },
    _onRoomUserVideoStatusChanged({
      userId,
      status, // 1: 'videoOn', 2: 'videoOff', 3: 'mutedByHost', 4: 'waitingOpen',
    }) {
      logger.log(TAG_NAME, 'event: 更新视频状态', userId, status)
      const isMySelf = this.inRoomService.isMySelf(userId)
      const myInfo = this.data.myInfo
      // 主持人开启
      if(status === 'waitingOpen') {
        if (!isMySelf || this.data.isVideoConfirm) return
        // 已经开启了就不处理
        if (myInfo.video === 1) return
        wx.showModal({
          title: '是否打开摄像头',
          content: '主持人邀请您开启视频，是否开启摄像头以使其他成员看您的画面',
          confirmText: '是',
          cancelText: '否',
          success: (res) => {
            // 未开启摄像头权限
            if (this.data.noVideoAuthSetting) {
              this.setData({
                isVideoConfirm: false
              })
              this.handleOpenSetting()
              return
            }
            if (res.confirm) {
              this.setData({
                videoAllowSelfOn: true,
                isVideoConfirm: false
              })
              this.getInRoomVideoController.muteMyVideo(false)
            } else if (res.cancel) {
              this.setData({
                isVideoConfirm: false
              })
              // 更新会议信息
              this.getMeetingInfo()
            }
          }
        })
        this.setData({
          isVideoConfirm: true
        })
        return
      }
      // 开启摄像头
      if (status === 'videoOn') {
        if (isMySelf) {
          // 未开启摄像头权限
          if (this.data.noVideoAuthSetting) {
            this.setData({
              isVideoConfirm: true
            })
            this.handleOpenSetting()
            return
          }
          this._pusherStart()
          this.setData({
            btnVideoLoading: false
          })
          return
          // 更新操作栏状态
          // this._updateMyInfo()
        }
        // 更新数据-推流
        const userInfo = this.inRoomService.getUserInfoById(userId)
        this._updateUserById({ video: 1 }, userId).then(() => {
          this._sortUserList()
          return
        })
      }
      // 关闭摄像头
      if (status === 'mutedByHost' || status === 'videoOff') {
        if(status === 'mutedByHost') {
          // 已经关闭了就不处理
          if (isMySelf && myInfo.video === 1) {
            wx.showToast({
              title: '主持人已关闭您的摄像头',
              icon: 'none',
              duration: 2000
            })
          }
        }
        // 更新操作栏状态
        if (isMySelf) {
          this._updateMyInfo()
        }
        this._updateUserById({ video: status === 'mutedByHost' ? 3 : 2 }, userId).then(() => {
          this._sortUserList()
          this.setData({
            btnVideoLoading: false
          })
        })
        // 更新会议信息
        this.getMeetingInfo()
      }
    },
    _onRoomUserVideoPinStatusChanged({userId,isPinned}) { // 焦点视频状态更新
      logger.log('event: 更新焦点视频', userId, isPinned)
      const isMySelf = this.inRoomService.isMySelf(userId)
      if (isMySelf) {
        wx.showToast({
          title: isPinned ? '您已被设置为焦点视频' : '您已被取消焦点视频',
          icon: 'none',
          duration: 2000
        })
      }
      const user = this.data.userList.find(user => {
        return user.isFocus
      })
      // 去除原先的focus
      if(user) {
        this._updateUserById({isFocus: false}, user.accountId).then(() => {
          this._updateUserById({ isFocus: isPinned }, userId).then(() => {
            this._sortUserList()
          })
        })
      }else {
        this._updateUserById({ isFocus: isPinned }, userId).then(() => {
          this._sortUserList()
        })
      }

    },
    _onRoomHostChanged() {
      logger.log('event: 更新主持人')
      this.getMeetingInfo()
    },
    _onRoomUserNameChanged({userId, name}) {
      logger.log('event: 更新用户昵称', userId, name)
      if(this.inRoomService.isMySelf(userId)) { //如果更新自己的信息则同步更新聊天室的昵称
        this.setData({
          'chatRoomInfo.chatroomNick': name
        })
      }
      this._updateUserById({nickName: name}, userId).then(() => {
        this.getHostNickName()
      })
    },
    _onRoomUserScreenShareStatusChanged({userId, status}) {
      logger.log('event: 共享屏幕更新', userId, status)
      this._updateUserById({
        screenSharing: status ? 1 : 0
      }, userId).then(() => {
        this._sortUserList()
      })
    },
    _onRoomLockStatusChanged({isLock}) {
      logger.log('event: 会议锁定', isLock)
    },
    // 更新远端视频流订阅
    _onUpdateSubscribeVideo(event) {
      const {isSubscribe, userId, avRoomUid, nickName} = event.detail
      console.warn('_onUpdateSubscribeVideo', nickName, isSubscribe)

      this.getInRoomVideoController.subscribeRemoteVideo({
        userId,
        subscribe: isSubscribe,
        avRoomUid,
        mediaType: 'video',
        context: this,
      }).then(stream => {
        const userInfo = this.inRoomService.getUserInfoById(userId)

        if (!isSubscribe) {
          console.warn('取消订阅视频流成功', nickName)
          userInfo.stream.playerContext.stop({
            fail: (err) => {
              console.log('停止推流失败', err)
            },
          })
          return
        }
        console.warn('订阅视频流成功', nickName, userInfo)
        if (!userInfo) return
        logger.info(TAG_NAME, '订阅视频流成功', nickName, userInfo)
          // 发布音视频
        this._updateUserById({
          stream: {
            url: userInfo.stream && userInfo.stream.url,
          }
        }, userId).then(() => {
          this.getInRoomVideoController.attachRendererToUserVideoStream({mediaType: 'video', userId}).then(() => {
            const userInfo = this.inRoomService.getUserInfoById(userId)
            logger.info(TAG_NAME, '播放视频流成功', userInfo)
          }).catch(err => {
            const userInfo = this.inRoomService.getUserInfoById(userId)
            logger.error(TAG_NAME, '播放视频流失败：', err, userInfo)
          })
        })
      }).catch(err => {
        logger.error('_onUpdateSubscribeVideo err', err, userId, nickName)
      })
    },
    _updateUserById(data, accountId) {
      logger.log('开始_updateUserById', data, accountId)
      return new Promise((resolve, reject) => {
        logger.log(TAG_NAME, '_updateUserById', {
          data,
          accountId,
        })
        let userList = this.data.userList
        // streamAdd事件先于setList时
        if (!userList.length) {
          userList = this.inRoomService.getAllUsers()
        }
        const index = userList.findIndex(user => {
          return user && user.accountId === accountId
        })
        if(index < 0) {
          resolve()
          return
        }
        if(data.stream) {
          data.stream = {...userList[index].stream, ...data.stream }
        }
        const keys = Object.keys(data)
        let key = ''
        let result = null
        if(keys.length === 1) {
          key = `userList[${index}].${keys[0]}`
          result = data[keys[0]]
        }else {
          key = `userList[${index}]`
          result = {...userList[index], ...data}
        }
        this.setData({
          [key]: result,
        }, () => {
          resolve()
        })
      })
    },
    _onReload() { // 重新连接网络进行加载
      // todo
    },
    _offlineHandle() {
      wx.onNetworkStatusChange(res => {
        if(this.data.isConnected && res.isConnected) { // 已经是联网状态且最新状态也是联网不操作
          return
        }
        if (this.data.isConnected && !res.isConnected) {
          // 断网开始计时，计时器，0-10s重连成功则保留，10s-50s左右等待联网成功退出或继续等待，50s及以上rtc会断连退出
          this.disconnectTime = new Date().getTime()
          console.log('断网时刻', this.disconnectTime)
        }
        this.setData({
          isConnected: res.isConnected
        })
        this._leaveByOffline(res.isConnected)
        if(res.isConnected) { // 更新状态
          // 断连后恢复
          if (this.disconnectTime) {
            // 1. 如果在0-10s内重连成功则正常往下走
            console.log(
              '断网后重连间隔',
              (new Date().getTime() - this.disconnectTime) / 1000
            )
            if ((new Date().getTime() - this.disconnectTime) / 1000 > 20) {
              // 2.如果重连时间超过超过10s的话，联网后手动退出，以免推拉流异常
              wx.showToast({
                title: '请重新加入房间',
                icon: 'none',
                duration: 1500,
              })
              this.disconnectTime = 0
              this.triggerEvent('leave')
              return
            }
          }
          this.retryRemoteStream()

          if (this.data.hasHided) {
            // 恢复网络后保持原有onHide逻辑
            this.muteMyMedia().then(() => {
              this.onShowToast()
            }).catch(err => {
              logger.error(err, 'muteMyMedia error')
              setTimeout(() => {
                this.muteMyMedia()
              }, 1500)
            })
          }
          // logger.log('联网，更新状态')
          // this.getMeetingInfo().then(() => {
          //   logger.log('获取meetingInfo完成')
          //   this._updateStreamByOffline()
          // })
        }
      })
    },
    _updateStreamByOffline() {
      logger.log('联网获取用户信息')
      this._setList().then(() => {
        logger.log('更新用户', this.data.userList)
        this.data.userList.forEach(user => {
          logger.log('重新拉流', user.stream)
          if(user.stream) {
            if(user.screenSharing === 1) {
              this._playStream('sreen', user.accountId)
              return
            }
          }
          const audioStatusMap = {
              1: 'audioOn',
              2: 'audioOff',
              3: 'mutedByHost',
              4: 'waitingOpen'
            }
            const videoStatusMap = {
              1: 'videoOn',
              2: 'videoOff',
              3: 'mutedByHost',
              4: 'waitingOpen'
            }
            this._onRoomUserAudioStatusChanged({
              userId: user.accountId,
              status: audioStatusMap[user.audio]
            })
            this._onRoomUserVideoStatusChanged({
              userId: user.accountId,
              status: videoStatusMap[user.video]
            })
        })
      })

    },
    _leaveByOffline(isConnected) {
      wx.showToast({
        title: isConnected ? '当前网络已恢复' : '当前网络已断开',
        icon: 'none',
        duration: 1500
      })
    },
  }
})
