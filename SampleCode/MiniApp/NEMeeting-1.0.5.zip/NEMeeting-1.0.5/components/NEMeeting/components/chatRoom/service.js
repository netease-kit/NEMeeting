import { logger } from '../../../NEChatRoomUI/utils/logger';
import { formatDate } from '../../utils/index';
export function getHistoryService(request, imAccid, options={
  limit: 100,
  reverse: true,
}) {
  return request.getHistoryMsgs(options).then(res => {
    let msgs = res.msgs;
    return msgs.filter(msg => {
        return msg.type !== 'notification' || (msg.type === 'notification' && msg.text)
      }).map(msg => {
        msg = formateMsg(msg, imAccid)
        return msg
      })
  }) 
}

export async function getMemberServices(request, imAccid) {
  const members = (
    await Promise.all([
      _getMembers(request, { guest: true, limit: 2000 }),
      _getMembers(request, { guest: false, limit: 10 }),
    ])
  ).flat()
  const res = parseMemberInfo(
    members.filter(item => item.account !== imAccid && item.online)
  )
  return res
}

function parseMemberInfo(members) {
  return members.map((item) => {
    // TODO 这里IM SDK获取用户信息居然没有返回tags，先把tags传入到custom字段hack一下，后面需要SDK修改后再去掉
    let tags = []
    try {
      tags = JSON.parse(item.custom).tags
    } catch (e) {
      tags = []
    }
    return {
      ...item,
      tags: tags && tags.length ? tags : ['未分类'],
    }
  })
}

export function _getMembers(request, options) {
  return request.getMembers(options)
}


export function handleRecMsgService(msgs) {
  let unReadMsgsCount = 0 // 获取未读消息
  msgs =  msgs.filter(msg => {
    if(msg.type !== 'notification') {
      unReadMsgsCount += 1
    }
    return msg.type !== 'notification' || (msg.type === 'notification' && msg.text)
  }).map(msg => {
    msg = formateMsg(msg)
    return msg
  }) 
  return {
    msgs,
    unReadMsgsCount
  }
}

function formateMsg(msg, myAccountId) {
  msg.time = formatDate(msg.time, 'yyyy-MM-dd hh:mm:ss')
  msg.fromAvatar = msg.fromAvatar || ''
  myAccountId && (msg.isMe = msg.from === myAccountId)
  return msg
}
const handleMap = {
  text: (request, params, myId) => {
    return new Promise((resolve, reject) => {
      logger.log('params', params)
      request.sendTextMessage({
        ...params,
        done (err, msg) {
          msg = formateMsg(msg, myId)
          if (err) {
            reject(err)
          } else {
            resolve(msg)
          }
        }
      })
    })
  }
}
export function handleSendMsgService(request, params, myId) {
  return handleMap[params.type](request, params, myId)
}