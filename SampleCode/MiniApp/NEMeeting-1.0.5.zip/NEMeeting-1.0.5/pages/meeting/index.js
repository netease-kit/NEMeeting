Page({
  data: {
    config: {
      debug: true, // 是否开启调试模式
      appKey: '', // 云信 appKey
      deviceId: '', // 设备唯一id
      nickName: '', // 昵称
      tag: '', // [可选] 用户标签
      tags: '', // [可选] 聊天室当前用户的标签分组，最多填写一个
      defaultDirectionalTags: '', // [可选] 聊天室定向发送消息的标签组
      enableOrientChat: true, // [可选] 是否开启聊天室定向发送消息模式，默认关闭
      baseDomain: '', // [可选] 请求的domain地址
      offChatRoom: false, // [可选] 关闭聊天室功能，默认开启
      enableRealtimeLog: true, // 是否开启实时日志上报（微信公众号后台查看），默认开启便于获取日志
      neRtcServerAddresses: {},
      imPrivateConf: {}
    }
  },
  
  onLoad: function (options) {
    const config = Object.assign(this.data.config, options)
    this.setData({
      config,
      'config.accountToken': decodeURIComponent(config.accountToken),
      'config.baseDomain': decodeURIComponent(config.baseDomain),
      'config.debug': config.debug === 'true'
    })
    // 开启私有化部署(这里保证两个对象的参数准确)
    if (options.isPrivatization === 'true' && options.neRtcServerAddresses && options.imPrivateConf) {
      this.setData({
        'config.neRtcServerAddresses': JSON.parse(config.neRtcServerAddresses),
        'config.imPrivateConf': JSON.parse(config.imPrivateConf),
      })
    }
    const {debug, appKey, baseDomain, offChatRoom, tags, enableOrientChat, enableRealtimeLog, neRtcServerAddresses, imPrivateConf} = this.data.config
    let defaultDirectionalTags = this.data.config.defaultDirectionalTags.split(/[,，]/).filter(item => !!item)
    this.meetingComponent = this.selectComponent('#meeting-component')
    this.meetingComponent.initSDK({
      debug,
      appKey,
      baseDomain,
      offChatRoom,
      tags,
      defaultDirectionalTags,
      enableOrientChat,
      enableRealtimeLog,
      neRtcServerAddresses,
      imPrivateConf
    })
    console.log('初始化SDK完成')
    if (config.type == 1) {
      this.loginWithAccount({
        username: options.username,
        password: options.password
      })
    }
    if (config.type == 2) {
      this.loginWithToken({
        accountId: options.accountId,
        token: decodeURIComponent(options.accountToken)
      })
    }
    if (config.type == 3) {
      const {meetingId, nickName, openCamera, openMicrophone, tag} = this.data.config
      this.meetingComponent.anonymousJoinMeeting({
        roomId: meetingId,
        nickName, 
        openCamera, 
        openMicrophone, 
        tag
      }).catch(err => {
        console.error('anonymousJoinMeeting', err)
        wx.showToast({
          title: '匿名入会失败',
          icon: 'none',
          duration: 2000,
          complete: () => {
            setTimeout(() =>{
              wx.navigateBack({
                delta: 1,
              })
            }, 1000)
          }
        })
      })
    }
  },

  // 保险起见，离开页面需要销毁
  onUnload: function () {
    console.log('meeting/index onUnload')
    try {
      this.meetingComponent.logout().then(() => {
        this.destroy()
      })
    } catch (err) {
      console.error(error, 'onUnload error')
    }
  },

  // 除非页面销毁和登出操作，否则登录一直有效，不能登录2次哦
  async loginWithAccount (params) {
    this.meetingComponent.loginWithAccount(params).catch(err => {
      console.error('loginWithAccount', err)
      wx.showToast({
        title: '登录失败',
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() =>{
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      })
    })
  },

  async loginWithToken (params) {
    this.meetingComponent.loginWithToken(params).catch(err => {
      console.error('loginWithToken', err)
      wx.showToast({
        title: '登录失败',
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() =>{
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        }
      })
    })
  },

  onLoginStateChange(status) {
    console.log(status.detail, 'login status')
    if (status.detail === 'logined') {
      const {meetingId, nickName, openCamera, openMicrophone, tag} = this.data.config
      this.meetingComponent.joinRoom({
        roomId: meetingId,
        nickName, 
        openCamera, 
        openMicrophone, 
        tag
      }).catch(err => {
        console.error(err, 'meeting/index.js joinRoom err')
        this.meetingComponent.logout()
        wx.showToast({
          title: '加入失败',
          icon: 'none',
          duration: 1500,
          complete: () => {
            setTimeout(() =>{
              wx.navigateBack({
                delta: 1,
              })
            }, 1500)
          }
        })
      })
    }
  },
  // 离开房间的一些处理在这里
  async leaveRoom() {
    console.log('收到离开会议')
    try {
      await this.meetingComponent.leaveRoom()
      await this.meetingComponent.logout()
      console.log('leaveRoom done')
    } catch (error) {
      console.error('meeting/index.js leaveRoom ', error)
    } finally {
      console.log('leaveRoom finally')
      wx.navigateBack()
    }
  },
  onMeetingClosed() {
    console.log('onMeetingClosed')
    this.destroy()
  },
  onDisconnect() {
    console.log('onDisconnect')
    this.destroy()
  },
  onKicked() {
    console.log('onKicked')
    this.destroy()
  }, 
  destroy() {
    try {
      this.meetingComponent.destroy()
      const currentRoute = getCurrentPages().pop().route
      if (currentRoute === 'pages/meeting/index') {
        wx.navigateBack()
      }
    } catch (error) {
      console.error(error, 'destroy error')
    }
  }
})