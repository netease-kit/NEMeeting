import { getHistoryService, getMemberServices, handleRecMsgService, handleSendMsgService } from './service';
import { logger } from '../../utils/logger.js'

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    chatRoomController: {
      type: Object,
    },
    chatRoomInfo: {
      type: Object,
      observer: function(newVal, oldVal) {
        if(newVal) { // 显示聊天室重置未读消息
          this.setData({
            tagInfo: newVal.tagInfo
          })
        }
      }
    },
    visiable: {
      type: Boolean,
      observer: function(newVal, oldVal) {
        if(newVal) { // 显示聊天室重置未读消息
          this.data.unReadMsgsCount = 0
          this.triggerEvent('unReadChange', 0)
        }
      }
    }
  },

  lifetimes: {
    attached: function () {
      // 在组件实例进入页面节点树时执行
      this.enterChatRoom()
    },
    ready: function () {
      // 在组件在视图层布局完成后执行
    },
    detached: function () {
      // 在组件实例被从页面节点树移除时执行
      this.unbindListener()
      this.exitChatRoom()
    },
  },
  /**
   * 组件的初始数据
   */
  data: {
    msgs: [],
    tagInfo: {},
    unReadMsgsCount: 0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onSendMsg(data) {
      const msg = data.detail;
      logger.log(msg, 'onSendMsg')
      if (!(msg.content && msg.content.trim())) {
        wx.showToast({
          title: '无法发送内容为空的消息',
          icon: 'none',
          duration: 1000,
        })
        return
      }
      this.handleSendMsg({
        text: msg.content,
        type: msg.type,
        toAccids: msg.toAccids,
        custom: msg.custom,
      });
    },
    onResendMsg(event) { // 重复消息
      const {msg} = event.detail
      logger.log(event, 'event');
      this.handleSendMsg({
        resend: true,
        idClient: msg.idClient,
        flow: msg.flow,
        status: msg.status,
        text: msg.text,
        type: msg.type,
        toAccids: msg.toAccids,
        custom: msg.custom,
      })
    },
    onClose() {
      this.triggerEvent('close');
    },
    handleSendMsg(params) {
      handleSendMsgService(
        this.properties.chatRoomController, 
        params,
        this.properties.chatRoomInfo.imAccid
      ).then(msg => {
        const oldMsgs = this.data.msgs;
        if(msg.resend && msg.status === 'success') { // 如果是重新发送的
          const index = oldMsgs.findIndex(item => {
            return item.idClient === msg.idClient
          })
          if(index > -1) {
            oldMsgs[index] = msg;
          }
          this.setData({
            msgs: oldMsgs
          })
          return
        }else if(!msg.resend) {
          if(msg.status === 'fail') {
            const { chatroomNick } = this.properties.chatRoomInfo
            msg.fromNick = chatroomNick || ''
          }
          this.setData({
            msgs: [...oldMsgs, msg]
          })
        }
        if(msg.status === 'fail') {
          wx.showToast({
            title: '发送失败，请重试',
            icon: 'none',
            duration: 2000
          })
        }
      }).catch(err => {
        logger.error(err)
      })
    },
    enterChatRoom() {
      if(this.properties.chatRoomInfo && this.properties.chatRoomController) {
        const { imAccid, imAppKey, imToken, chatroomId, chatroomNick, tagInfo } = this.properties.chatRoomInfo
        this.properties.chatRoomController.enterChatRoom({
          imAccid,
          imAppKey,
          imToken,
          chatroomId,
          chatroomNick,
          tags: tagInfo.tags,
          notifyTargetTags: JSON.stringify({ tag: '.*', matchType: 'regex' }),
          // TODO 这里IM SDK获取用户信息居然没有返回tags，先把tags传入到custom字段hack一下，后面需要SDK修改后再去掉
          chatroomCustom: JSON.stringify({
            tags: tagInfo.tags
          }),
        }).then(() => {
          // this.getHistoryMsgs();
          this.getMembers()
          this.bindListener();
        })
      }
    },
    exitChatRoom() {
      this.properties.chatRoomController.exitChatRoom()
    },
    handleRecMsg(newMsgs) { // 处理收到的消息
      const oldMsgs = this.data.msgs || []
      const { msgs, unReadMsgsCount } = handleRecMsgService(newMsgs)
      this.changeUnReadMsgCount(unReadMsgsCount) 
      this.setData({
        msgs: [...oldMsgs, ...msgs]
      })
    },
    changeUnReadMsgCount(unReadMsgsCount) {
      if(!this.properties.visiable) { // 如果未显示聊天室，则增加未读消息
        this.data.unReadMsgsCount = this.data.unReadMsgsCount + unReadMsgsCount
        this.triggerEvent('unReadChange', this.data.unReadMsgsCount)
      }
    },
    bindListener() { // 绑定消息监听
      this.properties.chatRoomController.on('onRoomChatMessageReceived', ({messages}) => {
        logger.log('收到msg:', messages)
        const type = messages[0].attach && messages[0].attach.type
        const updateListType = ['memberExit', 'memberEnter', 'kickMember', 'updateChatroom']
        this.handleRecMsg(messages)

        if (updateListType.includes(type)) {
          this.getMembers()
        }
      })
    },
    unbindListener() {
      this.properties.chatRoomController.off('onRecvMsg')
    },
    getHistoryMsgs() { // 获取历史消息
      getHistoryService(
        this.properties.chatRoomController, 
        this.properties.chatRoomInfo.imAccid
      ).then(msgs => {
        this.setData({
          msgs: msgs
        })
      })
    },
    getMembers() { // 获取在线人数
      getMemberServices(
        this.properties.chatRoomController,
        this.properties.chatRoomInfo.imAccid
      ).then(members => {
        logger.log(members, 'getMembers')
        let memberList = []
        let defaultAccids = []
        let defaultNames = []
        let tagInfo = this.properties.chatRoomInfo.tagInfo
        const defaultDirectionalTags = tagInfo.defaultDirectionalTags || []
        members.forEach(item => {
          if (!memberList.length) {
            memberList.push({
              tags: item.tags[0],
              value: item.tags[0],
              children: [{ account: item.account, value: item.nick, tags: item.tags[0], checked: false }],
              checked: false
            })
          } else {
            const member = memberList.find(memberItem => item.tags[0] === memberItem.tags)
            if (member) {
              member.children.push({ account: item.account, value: item.nick, tags: item.tags[0], checked: false })
            } else {
              memberList.push({
                tags: item.tags[0],
                value: item.tags[0],
                children: [{ account: item.account, value: item.nick, tags: item.tags[0], checked: false }],
                checked: false
              })
            }
          }
          // 查询定向标签组的account
          if (defaultDirectionalTags.includes(item.tags[0])) {
            defaultAccids.push(item.account)
            defaultNames.push(item.nick)
          }
        })
        tagInfo.defaultAccids = defaultAccids
        tagInfo.defaultNames = defaultNames
        tagInfo.members = memberList,
        tagInfo.allMembers = members,
        this.setData({
          tagInfo
        })
      })
    }
  }
})
