// components/NEMeeting/components/mediaPlayer/mediaPlayer.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isMe: {
      type: Boolean,
    },
    audioOutPutMode: {
      type: String,
    },
    index: {
      type: Number,
      observer: function(newVal, oldVal) {
        console.log(this.properties.member.nickName, newVal, oldVal, 'mediaPlayer index')
        this.index = newVal
        this.oldIndex = oldVal
      }
    },
    member: {
      type: Object,
      observer: function(newVal, oldVal) {
        console.log(newVal.nickName, this.properties.video === 1 ? '视频开' : '视频关', '序号', this.oldIndex || 0 + '-->' + this.index || 0, 'mediaPlayer member')
        // 之前没有订阅过视频流
        if ((this.properties.index <= 3) && this.properties.member.stream && !this.properties.member.stream.url) {
          this.updateSubscribeVideo(true)
        }
        // 之前订阅过视频流
        if ((this.properties.index > 3) && (this.properties.video === 3) && (this.properties.member.stream && this.properties.member.stream.url)) {
          this.updateSubscribeVideo(false)
        }
      }
    },
    video: {
      type: Number, // 1: 'audioOn', 2: 'audioOff', 3: 'mutedByHost', 4: 'waitingOpen',
    },
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 订阅/取消订阅视频
    updateSubscribeVideo(isSubscribe) {
      // 没开启视频||本端
      if (this.properties.video === 0 || this.properties.isMe) return
      console.log('用户：' + this.properties.member.nickName, (isSubscribe ? '开始订阅视频流' : '取消订阅视频流'))
      this.triggerEvent('updateSubscribeVideo', { 
        isSubscribe: isSubscribe,
        userId: this.properties.member.accountId,
        avRoomUid: this.properties.member.avRoomUid,
        nickName: this.properties.member.nickName,
      });
    },
    _pusherStateChangeHandler(event) {
      const { code, message } = event.detail
      this.triggerEvent('pusherStateChangeHandler', { 
        code,
        message
      });
    },
    _pusherErrorHandler(event) {
      const { errCode } = event.detail
      this.triggerEvent('pusherErrorHandler', { 
        errCode
      });
    },
    _pusherAudioVolumeNotify(event) {
      this.triggerEvent('pusherAudioVolumeNotify', { 
        volume: event.detail.volume,
        userId: this.properties.member.accountId
      });
    },
    _playerStateChange(event) {
      const { code, message } = event.detail
      this.triggerEvent('playerStateChange', { 
        code,
        message,
        nickname: this.properties.member.nickName,
        userId: this.properties.member.accountId
      });
    },
    _playerAudioVolumeNotify(event) {
      this.triggerEvent('playerAudioVolumeNotify', { 
        volume: event.detail.volume,
        userId: this.properties.member.accountId
      });
    }
  }
})
