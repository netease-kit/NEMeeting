const version = '3.12.0'

export default version
