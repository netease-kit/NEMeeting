const { logger } = require('../../components/NEMeeting/utils/logger')

Page({
  data: {
    config: {
      debug: true, // 是否开启调试模式
      appKey: '', // 云信 appKey
      deviceId: '', // 设备唯一id
      nickName: '', // 昵称
      role: 'member', // 加入NERoom房间的默认角色
      tag: '', // [可选] 用户标签
      chatroomTag: '', // [可选] 聊天室当前用户的标签分组，最多填写一个
      defaultDirectionalTags: '', // [可选] 聊天室定向发送消息的标签组
      enableOrientChat: true, // [可选] 是否开启聊天室定向发送消息模式，默认关闭
      baseDomain: '', // [可选] 请求的domain地址
      offChatRoom: false, // [可选] 关闭聊天室功能，默认开启
      neRtcServerAddresses: {},
      imPrivateConf: {},
    },
  },

  onLoad: function (options) {
    const config = Object.assign(this.data.config, options)
    console.log(options, config, 'config')
    this.setData({
      config,
      'config.accountToken': decodeURIComponent(config.accountToken),
      'config.baseDomain': decodeURIComponent(config.baseDomain),
      'config.debug': config.debug === 'true',
    })
    // 开启私有化部署(这里保证两个对象的参数准确)
    if (
      options &&
      options.neRtcServerAddresses !== {} &&
      options.imPrivateConf !== {}
    ) {
      this.setData({
        'config.neRtcServerAddresses': JSON.parse(config.neRtcServerAddresses),
        'config.imPrivateConf': JSON.parse(config.imPrivateConf),
      })
    }
    let {
      debug,
      appKey,
      baseDomain,
      offChatRoom,
      enableOrientChat,
      neRtcServerAddresses,
      imPrivateConf,
    } = this.data.config
    let defaultDirectionalTags = this.data.config.defaultDirectionalTags
      .split(/[,，]/)
      .filter((item) => !!item)
    this.meetingComponent = this.selectComponent('#meeting-component')
    this.meetingComponent.initSDK({
      debug,
      appKey,
      baseDomain,
      offChatRoom,
      defaultDirectionalTags,
      enableOrientChat,
      neRtcServerAddresses,
      imPrivateConf,
    })
    console.log('初始化SDK完成')
    if (config.type == 1) {
      this.loginWithToken({
        accountId: options.accountId,
        accountToken: decodeURIComponent(options.accountToken),
      })
    }
    if (config.type == 2) {
      this.meetingComponent
        .anonymousJoinMeeting()
        .then(() => {
          console.log('匿名登录成功')
        })
        .catch((err) => {
          wx.showToast({
            title: err || '登录失败',
            icon: 'none',
            duration: 2000,
            complete: () => {
              setTimeout(() => {
                wx.navigateBack({
                  delta: 1,
                })
              }, 1000)
            },
          })
        })
    }
  },

  // 离开页面需要调登出接口，否则无法销毁im房间
  onUnload: function () {
    console.log('meeting/index.js onUnload')
    this.destroy()
  },

  // 除非页面销毁和登出操作，否则登录一直有效，不能登录2次哦
  async loginWithToken(params) {
    this.meetingComponent.loginWithToken(params).catch((err) => {
      wx.showToast({
        title: err || '登录失败',
        icon: 'none',
        duration: 2000,
        complete: () => {
          setTimeout(() => {
            wx.navigateBack({
              delta: 1,
            })
          }, 1000)
        },
      })
    })
  },

  onLoginStateChange(status) {
    console.log(status.detail, 'login status')
    if (status.detail === 'logined') {
      const { role, meetingId, nickName, openCamera, openMicrophone, tag } =
        this.data.config
      let chatroomTag = this.data.config.chatroomTag
        .split(/[,，]/)
        .filter((item) => !!item)
      const initialProperties = {
        // initialProperties里的key名称不可更改，自定义属性需要跟服务端确认统一添加
        tag: {
          // 用户默认标签
          value: tag,
        },
        chatroomTag: {
          // 聊天室标签组，value需要转字符串
          value: JSON.stringify(chatroomTag),
        },
      }
      this.meetingComponent
        .joinRoom({
          role,
          meetingId,
          nickName,
          openCamera,
          openMicrophone,
          initialProperties,
        })
        .catch(async (err) => {
          let errMsg = '加入失败'
          switch (err.code) {
            case 3104:
            case 1004:
              errMsg = '会议不存在'
              break
            case 3102:
              errMsg = '会议已结束'
              break
            case 1019:
              errMsg = '房间已锁定'
              break
            case 1020:
              errMsg = '小程序暂不支持入会密码，请使用其他客户端入会'
              break
            default:
              console.log(err, '加入失败')
          }
          // 加入失败后需要先退出登录
          try {
            await this.meetingComponent.logout()
          } catch (error) {
            console.error(error, ' 加入房间失败后的登出失败')
          } finally {
            // fix快速离开当前页面时入会失败弹窗未出现的问题
            wx.hideToast()
            setTimeout(()=>{
              wx.showToast({
                title: errMsg,
                icon: 'none',
                duration: 2000,
                complete: () => {
                  setTimeout(() => {
                    wx.navigateBack({
                      delta: 1,
                    })
                  }, 2000)
                },
              })
            }, 100)
          }
        })
    }
  },
  // 离开房间的一些处理在这里
  async leaveRoom() {
    console.log('收到离开会议')
    try {
      await this.meetingComponent.leaveRoom()
      await this.meetingComponent.logout()
      wx.navigateBack()
    } catch (error) {
      console.error('meeting/index.js leaveRoom ', error)
      wx.navigateBack()
    }
  },
  // 结束房间
  async endRoom() {
    console.log('收到结束会议')
    try {
      await this.meetingComponent.endRoom()
      wx.navigateBack()
    } catch (error) {
      console.error('meeting/index.js endRoom ', error)
      wx.navigateBack()
    }
  },
  // 会议结束
  onMeetingClosed() {
    console.log('onMeetingClosed')
    this.destroy()
  },
  // 当前会议连接已断开
  onDisconnect() {
    console.log('onDisconnect')
    this.destroy()
  },
  // 因被主持人移出或切换至其他设备被踢出
  onKicked() {
    console.log('onKicked')
    this.destroy()
  },
  destroy() {
    try {
      this.meetingComponent.destroy()
    } catch (error) {
      console.error(error, 'destroy error')
    } finally {
      setTimeout(() => {
        const currentRoute = getCurrentPages().pop().route
        if (currentRoute === 'pages/meeting/index') {
          wx.navigateBack()
        }
      }, 2000)
    }
  },
})
