const version = '3.2.0'

export default version
