import {
  getHistoryService,
  getMemberServices,
  handleRecMsgService,
  handleSendMsgService,
  formateMsg,
} from './service'
import { logger } from '../../utils/logger.js'

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    chatRoomController: {
      type: Object,
      observer: function (newVal, oldVal) {
        if (newVal) {
          this.getMembers()
        }
      },
    },
    chatRoomInfo: {
      type: Object,
      observer: function (newVal, oldVal) {
        if (newVal) {
          // 显示聊天室重置未读消息
          this.setData({
            tagInfo: newVal.tagInfo,
          })
        }
      },
    },
    visiable: {
      type: Boolean,
      observer: function (newVal, oldVal) {
        if (newVal) {
          // 显示聊天室重置未读消息
          this.data.unReadMsgsCount = 0
          this.triggerEvent('unReadChange', 0)
        }
      },
    },
    chatRoomMsgs: {
      type: Object,
      observer: function (newVal) {
        if (newVal) {
          // console.log('----chatRoomMsgs', newVal)
          this.onReceiveMsgs(newVal)
        }
      },
    },
  },

  lifetimes: {
    attached: function () {
      console.log('attached')
      // 在组件实例进入页面节点树时执行
      this.enterChatRoom()
    },
    ready: function () {
      // 在组件在视图层布局完成后执行
    },
    detached: function () {
      // 在组件实例被从页面节点树移除时执行
      // this.unbindListener()
      // this.exitChatRoom()
    },
  },
  /**
   * 组件的初始数据
   */
  data: {
    msgs: [],
    tagInfo: {},
    unReadMsgsCount: 0,
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // onSendMsg(data) {
    //   const msg = data.detail
    //   logger.log(msg, 'onSendMsg')
    //   if (!(msg.content && msg.content.trim())) {
    //     wx.showToast({
    //       title: '无法发送内容为空的消息',
    //       icon: 'none',
    //       duration: 1000,
    //     })
    //     return
    //   }
    //   this.handleSendMsg({
    //     text: msg.content,
    //     type: msg.type,
    //     toAccids: msg.toAccids,
    //     custom: msg.custom,
    //   })
    // },
    onSendMsg(data) {
      const msg = data.detail
      logger.log(msg, 'onSendMsg')
      if (!(msg.content && msg.content.trim())) {
        wx.showToast({
          title: '无法发送内容为空的消息',
          icon: 'none',
          duration: 1000,
        })
        return
      }
      this.handleSendMsg({
        text: msg.content,
        type: msg.type,
        toAccids: msg.toAccids,
        custom: msg.custom,
      })
    },
    onResendMsg(event) {
      // 重复消息
      const { msg } = event.detail
      logger.log(event, 'event')
      this.handleSendMsg({
        idClient: msg.idClient,
        text: msg.text,
        type: msg.type,
        toAccids: msg.toAccids,
      })
    },
    onClose() {
      this.triggerEvent('close')
    },
    handleSendMsg(params) {
      // console.log('--------------handleSendMsg params-------------', params)
      handleSendMsgService(this.properties.chatRoomController, params)
        .then((msg) => {
          console.log('--------msg-----------', msg)
          const { imAccid } = this.properties.chatRoomInfo
          msg = formateMsg(msg, imAccid)
          const oldMsgs = this.data.msgs
          if (msg.resend && msg.status === 'success') {
            // 如果是重新发送的
            const index = oldMsgs.findIndex((item) => {
              return item.idClient === msg.idClient
            })
            if (index > -1) {
              oldMsgs[index] = msg
            }
            this.setData({
              msgs: oldMsgs,
            })
            return
          } else if (!msg.resend) {
            // 发送失败或者断网消息
            if (msg.status === 'fail' || !msg.status) {
              const { chatroomNick } = this.properties.chatRoomInfo
              msg.fromNick = chatroomNick || ''
              wx.showToast({
                title: '发送失败，请重试',
                icon: 'none',
                duration: 2000,
              })
              return
            }
            // 正常消息
            this.setData({
              msgs: [...oldMsgs, msg],
            })
          }
        })
        .catch((err) => {
          logger.error(err)
        })
    },
    enterChatRoom() {
      console.log(
        'this.properties.chatRoomInfo && this.properties.chatRoomController',
        this.properties.chatRoomInfo,
        this.properties.chatRoomController
      )
      if (this.properties.chatRoomInfo && this.properties.chatRoomController) {
        this.properties.chatRoomController
          .enterChatRoom()
          .then(() => {
            console.log(
              '--------------------enterChatRoom success------------------'
            )
            this.getHistoryMsgs()
            this.getMembers()
            // this.bindListener()
          })
          .catch((err) => {
            console.log('err', err)
          })
      }
    },
    exitChatRoom() {
      this.properties.chatRoomController.exitChatRoom()
    },
    handleRecMsg(newMsgs) {
      // 处理收到的消息
      const oldMsgs = this.data.msgs || []
      const { msgs, unReadMsgsCount } = handleRecMsgService(newMsgs)
      // console.log('--------unReadMsgs---------------', msgs, unReadMsgsCount)
      this.changeUnReadMsgCount(unReadMsgsCount)
      this.setData({
        msgs: [...oldMsgs, ...msgs],
      })
    },
    changeUnReadMsgCount(unReadMsgsCount) {
      if (!this.properties.visiable) {
        // 如果未显示聊天室，则增加未读消息
        this.data.unReadMsgsCount = this.data.unReadMsgsCount + unReadMsgsCount
        this.triggerEvent('unReadChange', this.data.unReadMsgsCount)
      }
    },
    onReceiveMsgs(data) {
      console.log('--------onReceiveMsgs---------', data)
      const messages = data
      logger.log('收到msg:', messages)
      const type = messages[0].attach && messages[0].attach.type
      const updateListType = [
        'memberExit',
        'memberEnter',
        'kickMember',
        'updateChatroom',
      ]
      this.handleRecMsg.call(this, messages)
      if (updateListType.includes(type)) {
        this.getMembers.call(this)
      }
    },
    getHistoryMsgs() {
      // 获取历史消息
      getHistoryService(
        this.properties.chatRoomController,
        this.properties.chatRoomInfo.imAccid
      ).then((msgs) => {
        logger.log(msgs, 'getHistoryMsgs')
        this.setData({
          msgs: msgs,
        })
      })
    },
    getMembers() {
      if (!this.properties.chatRoomController) {
        console.error('not init chatroom')
        return
      }
      let memberList = []
      let defaultAccids = []
      let defaultNames = []
      let tagInfo = this.properties.chatRoomInfo.tagInfo
      const defaultDirectionalTags = tagInfo.defaultDirectionalTags || []
      let members = this.properties.chatRoomController.getMembers
      const { imAccid } = this.properties.chatRoomInfo // 本端uuid
      members = members.filter(
        (item) => item.isInChatroom && item.accountId !== imAccid
      )
      // console.log('---------members------------', members)
      // members = members.map((item) => {
      //   return {
      //     ...item,
      //     tags: chatroomTag
      //   }
      // })
      console.log('---------getMembers members------------', members)
      members.forEach((item) => {
        if (!memberList.length) {
          memberList.push({
            tags: item.tags[0],
            value: item.tags[0],
            children: [
              {
                account: item.uuid,
                value: item.nickName,
                tags: item.tags[0],
                checked: false,
              },
            ],
            checked: false,
          })
        } else {
          const member = memberList.find(
            (memberItem) => item.tags[0] === memberItem.tags
          )
          if (member) {
            member.children.push({
              account: item.uuid,
              value: item.nickName,
              tags: item.tags[0],
              checked: false,
            })
          } else {
            memberList.push({
              tags: item.tags[0],
              value: item.tags[0],
              children: [
                {
                  account: item.uuid,
                  value: item.nickName,
                  tags: item.tags[0],
                  checked: false,
                },
              ],
              checked: false,
            })
          }
        }
        // 查询定向标签组的account
        if (defaultDirectionalTags.includes(item.tags[0])) {
          defaultAccids.push(item.uuid)
          defaultNames.push(item.nickName)
        }
      })
      tagInfo.defaultAccids = defaultAccids
      tagInfo.defaultNames = defaultNames
      console.log('----------tagInfo------------', tagInfo)
      ;(tagInfo.members = memberList),
        (tagInfo.allMembers = members),
        this.setData({
          tagInfo,
        })
    },
    // getMembers() {
    //   // 获取在线人数
    //   getMemberServices(
    //     this.properties.chatRoomController,
    //     this.properties.chatRoomInfo.imAccid
    //   ).then((members) => {
    //     logger.log(members, 'getMembers')
    //     let memberList = []
    //     let defaultAccids = []
    //     let defaultNames = []
    //     let tagInfo = this.properties.chatRoomInfo.tagInfo
    //     const defaultDirectionalTags = tagInfo.defaultDirectionalTags || []
    //     members.forEach((item) => {
    //       if (!memberList.length) {
    //         memberList.push({
    //           tags: item.tags[0],
    //           value: item.tags[0],
    //           children: [
    //             {
    //               account: item.account,
    //               value: item.nick,
    //               tags: item.tags[0],
    //               checked: false,
    //             },
    //           ],
    //           checked: false,
    //         })
    //       } else {
    //         const member = memberList.find(
    //           (memberItem) => item.tags[0] === memberItem.tags
    //         )
    //         if (member) {
    //           member.children.push({
    //             account: item.account,
    //             value: item.nick,
    //             tags: item.tags[0],
    //             checked: false,
    //           })
    //         } else {
    //           memberList.push({
    //             tags: item.tags[0],
    //             value: item.tags[0],
    //             children: [
    //               {
    //                 account: item.account,
    //                 value: item.nick,
    //                 tags: item.tags[0],
    //                 checked: false,
    //               },
    //             ],
    //             checked: false,
    //           })
    //         }
    //       }
    //       // 查询定向标签组的account
    //       if (defaultDirectionalTags.includes(item.tags[0])) {
    //         defaultAccids.push(item.account)
    //         defaultNames.push(item.nick)
    //       }
    //     })
    //     tagInfo.defaultAccids = defaultAccids
    //     tagInfo.defaultNames = defaultNames
    //     ;(tagInfo.members = memberList),
    //       (tagInfo.allMembers = members),
    //       this.setData({
    //         tagInfo,
    //       })
    //   })
    // },
  },
})
