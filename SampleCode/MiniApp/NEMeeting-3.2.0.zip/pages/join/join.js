import { prevent } from '../../utils/index'
Page({
  data: {
    debug: false,
    meetingId: '',
    nickName: '',
    openCamera: false,
    openMicrophone: false,
    isPrivatization: false, // 是否开启私有化部署
    tag: '',
    chatroomTag: '', // [可选] 聊天室当前用户的标签分组，最多填写一个
    defaultDirectionalTags: '', // [可选] 聊天室定向发送消息的标签组
    enableOrientChat: false, // [可选] 是否开启聊天室定向发送消息模式，默认关闭
    accountId: '',
    accountToken: '',
    appKey: '',
    baseDomain: 'https://roomkit.netease.im',
    neRtcServerAddresses: {
      demoServer: '',
      channelServer: '',
      statisticsServer: '',
      roomServer: '',
      compatServer: '',
      nosLbsServer: '',
      nosUploadSever: '',
      nosTokenServer: '',
      useIPv6: false,
    },
    imPrivateConf: {
      lbs_web: '',
      link_web: '',
      link_ssl_web: true,
      nos_uploader_web: '',
      https_enabled: true,
      nos_downloader: '',
      nos_accelerate: '',
      nos_accelerate_host: '',
      nt_server: '',
    },
    loginTypeArr: [
      { value: 1, title: 'token登录' },
      { value: 2, title: '匿名登录' },
    ],
    type: 2,
  },
  changeHandler(e) {
    const key = e.currentTarget.dataset.key
    this.setData({
      [key]: e.detail.value,
    })
  },
  joinRoom: prevent(function () {
    if (!this.data.meetingId) {
      wx.showToast({
        title: '请填写会议Id',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    if (!this.data.nickName) {
      wx.showToast({
        title: '请填写昵称',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    if (type == 1 && (!this.data.accountToken || !this.data.accountId)) {
      wx.showToast({
        title: '请填写您的账号密码',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    if (!/^\d{1,12}$/.test(this.data.meetingId)) {
      wx.showToast({
        title: '仅支持20位及以下纯数字',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    if (
      this.data.nickName &&
      !/^[\u4e00-\u9fa5\da-zA-Z]{1,20}$/.test(this.data.nickName)
    ) {
      wx.showToast({
        title: '仅支持20位及以下文本、字母及数字组合',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    const url = '/pages/meeting/index'

    const {
      debug,
      meetingId,
      nickName,
      openCamera,
      openMicrophone,
      appKey,
      tag,
      chatroomTag,
      enableOrientChat,
      defaultDirectionalTags,
      type,
      accountId,
      baseDomain,
      isPrivatization,
    } = this.data

    let queryParams = {
      debug,
      meetingId,
      nickName,
      openCamera,
      openMicrophone,
      appKey,
      tag,
      chatroomTag,
      enableOrientChat,
      defaultDirectionalTags,
      type,
      accountId,
      accountToken: encodeURIComponent(this.data.accountToken),
      baseDomain: encodeURIComponent(baseDomain),
      isPrivatization,
    }

    // 开启私有化部署
    if (isPrivatization) {
      const neRtcServerAddresses = JSON.stringify(
        this.data.neRtcServerAddresses
      )
      const imPrivateConf = JSON.stringify(this.data.imPrivateConf)
      queryParams = {
        ...queryParams,
        ...{ neRtcServerAddresses, imPrivateConf },
      }
    }

    const finalUrl = Object.keys(queryParams).reduce((prev, cur) => {
      return `${prev}${prev === url ? '?' : '&'}${cur}=${queryParams[cur]}`
    }, url)
    wx.navigateTo({ url: finalUrl })
  }, 2000),
})
