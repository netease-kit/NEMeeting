## v3.4.1(2022-09-08)

### Bug Fixes

- **meeting-wx-vue-ui:** 🐛 替换 rtc-sdk v4.6.11 的 neroom-sdk 文件
- **meeting-wx-vue-ui:** 🐛 修复会控操作相关的问题

## v3.2.2(2022-06-30)

**Note:** Version bump only for package @xkit-yx/meeting-wx-ui

# 3.2.0 (2022-06-28)

### Bug Fixes

- **meeting-wx-vue-ui:** 🐛 成员白板状态回调修改、增加日志
- **meeting-wx-vue-ui:** 🐛 成员加入去重
- **meeting-wx-vue-ui:** 🐛 成员离开的 leave 事件延后 1s，以免弹窗不被看见
- **meeting-wx-vue-ui:** 🐛 成员离开时更新聊天室分类列表
- **meeting-wx-vue-ui:** 🐛 成员屏幕共享属性统一用 screenSharing
- **meeting-wx-vue-ui:** 🐛 定向发送消息过长显示省略号
- **meeting-wx-vue-ui:** 🐛 定向聊天点击名称实际未选中的问题
- **meeting-wx-vue-ui:** 🐛 断网 20s 后退出，20s 重连并处理远端拉流问题
- **meeting-wx-vue-ui:** 🐛 断网超时重连退出房间
- **meeting-wx-vue-ui:** 🐛 断网后自动离开房间
- **meeting-wx-vue-ui:** 🐛 更新 userList 方法单独抽离，同时更新在线人数等数据
- **meeting-wx-vue-ui:** 🐛 过滤不在 rtc 房间内的成员
- **meeting-wx-vue-ui:** 🐛 开启音视频弹窗中添加现有状态的判断
- **meeting-wx-vue-ui:** 🐛 聊天室成员分类不展示自己
- **meeting-wx-vue-ui:** 🐛 聊天室定向开启时选中成员与展示同步问题,eslint
- **meeting-wx-vue-ui:** 🐛 配合 roomkit-api 调整
- **meeting-wx-vue-ui:** 🐛 提取操作本端音视频的公共方法
- **meeting-wx-vue-ui:** 🐛 修复本端刚加入是 isJoinRtc 为 false 被误筛的 bug
- **meeting-wx-vue-ui:** 🐛 修复断网离开失败的问题
- **meeting-wx-vue-ui:** 🐛 修复 roomkit 销毁异常问题
- **meeting-wx-vue-ui:** 🐛 与线上服统一，处理无聊天室通知
- **meeting-wx-vue-ui:** 🐛 fix：焦点视频排序逻辑，进出房间不再获取远端数据
- **meeting-wx-vue-ui:** 🐛 fix:入会前未设置焦点用户

### NEW Features

- **meeting-wx-vue-ui:** 🎸 底层替换 neroom-sdk
- **meeting-wx-vue-ui:** 🎸 onRtcAbilityNotSupport 回调

# CHANGELOG

# 2021-11-25 @ v1.0.0

## Added

- 首次发布版本

# 2022-01-05 @ v1.0.1

## Changed

- 支持私有化部署

# 2022-02-18 @ v1.0.2

## Changed

- 聊天室增加开关
- 聊天室支持定向消息

# 2022-04-08 @ v1.0.3

## Changed

- 进入后台关闭音视频
- 用户列表增加描述文案
- im 增加 customTag 区分来自哪个端
