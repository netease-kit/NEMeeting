const version = '3.4.1'

export default version
