import RoomKitMiniappSDK from './resources/sdk/neroom-wx-sdk.cjs'

import {
  sendRequest,
  isIphoneX,
  prevent,
  AttendeeOffType,
  Role,
  RoleName,
  _generateMember,
} from './utils/index.js'
import { logger } from './utils/logger.js'
const TAG_NAME = 'meeting-component'
const LoginState = {
  idle: 'idle',
  logining: 'logining',
  logined: 'logined',
  logouting: 'logouting',
}

Component({
  lifetimes: {
    created: function () {
      // 在组件实例刚刚被创建时执行
    },
    attached: function () {
      // 在组件实例进入页面节点树时执行
      this._init()
    },
    ready: function () {
      // 在组件在视图层布局完成后执行
    },
    detached: function () {
      // 在组件实例被从页面节点树移除时执行
      // this.destroy()
      this._resetState()
    },
    error: function (error) {
      // 每当组件方法抛出错误时执行
    },
  },
  // 组件所在页面的生命周期
  pageLifetimes: {
    show: function () {
      // 页面被展示
      this.onShowToast()
      logger.addFilterMsg(TAG_NAME)
      // 修复：ios设备开启听筒后切至后台，切回来时wx系统错误使用扬声器输出声音的问题
      // 修复：安卓手机退到后台再返回，输出音源被微信切换
      this.switchAudioOutPutMode().then(() => {
        setTimeout(() => {
          this.switchAudioOutPutMode()
        }, 100)
      })
    },
    hide: function () {
      if (this.data.isHideMute) {
        // 页面被隐藏
        this.setData({
          hasHided: true,
        })
        this.muteMyMedia()
      }
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    debug: false,
    offChatRoom: false,
    enableOrientChat: false,
    extraData: {}, // 会议额外信息
    userList: [],
    smallScreenShow: true,
    cameraPosition: 'front', // back-后置，front-前置
    audioOutPutMode: 'speaker', // speaker-扬声器， ear-听筒
    isIphoneX: isIphoneX(),
    showChatRoom: false, // 显示聊天室
    meetingInfo: null,
    hostNickName: '',
    meetingInfoDialogShow: false,
    memberListDialogShow: false,
    chatRoomController: null,
    chatRoomInfo: null,
    chatRoomMsgs: null,
    unReadCount: 0, // 未读消息
    leaveRoomSheetShow: false, // 离开会议弹窗开关
    focusSheetShow: false, // 设置焦点用户开关
    toolsVisible: true, // 操作栏显示开关
    onlineUserMember: 1, // 在线人数
    meetingMaxCount: 0, // 会议预置总人数
    selectedUserNickName: '', // 当前选择置顶的用户昵称
    focusSheetBtns: [{ text: '置顶', value: true }],
    leaveRoomBtns: [{ text: '退出会议', value: true }],
    loading: true,
    isSettingConfirm: false,
    noAudioAuthSetting: false, // 是否关闭麦克风权限
    noVideoAuthSetting: false, // 是否关闭摄像头权限
    btnAudioLoading: false, // 开启音频的按钮loading
    btnVideoLoading: false, // 开启视频的按钮loading
    isConnected: true, // 断网是否重连，用于当用户wifi和流量同时开启时候会走两次网络监听
    sortListTimer: null, // 刷新排序做节流
    isHideMute: true, // 小程序最小化后是否需要后台关闭音视频
    enableRealtimeLog: true, // 是否开启实时日志上报（微信公众号后台查看）
    disconnectTime: 0, // 断连的具体时间
    retryRemoteObj: {},
  },

  /**
   * 组件的方法列表
   */
  methods: {
    _init() {
      logger.log(TAG_NAME, '_init')
      this._keepScreenOn()
      this._setToolsHide()
    },

    /**
     * 初始化
     * @param param
     * @param param.debug 是否开启调试模式
     * @param param.appKey appKey
     * @param param.baseDomain [可选] 发起请求的domain，默认https://roomkit.netease.im
     * @param param.offChatRoom [可选] 关闭聊天室功能，默认开启
     * @param param.defaultDirectionalTags [可选] 聊天室定向发送消息的标签组
     * @param param.enableOrientChat [可选] 是否开启聊天室定向发送消息模式，默认关闭
     * @param param.neRtcServerAddresses [可选] G2 sdk 私有化配置
     * @param param.imPrivateConf [可选] IM sdk 私有化配置
     * @param param.isHideMute [可选] 小程序最小化后是否需要后台关闭音视频，默认开启
     * @param param.enableRealtimeLog [可选] 是否开启实时日志上报（微信公众号后台查看），默认开启
     */
    initSDK({
      debug,
      appKey,
      baseDomain,
      offChatRoom,
      defaultDirectionalTags,
      enableOrientChat,
      neRtcServerAddresses,
      imPrivateConf,
      isHideMute,
      enableRealtimeLog,
    }) {
      try {
        // 聊天室用户标签
        // const tagsArr = tags ? [tags] : ['']
        this.setData({
          _appKey: appKey,
          _baseDomain: baseDomain,
        })
        // 初始化
        const roomkit = new RoomKitMiniappSDK({
          debug,
        })
        roomkit.initialize({
          appKey,
          serverConfig: {
            roomKitServerConfig: {
              roomServer: baseDomain || 'https://meeting-api.netease.im',
            },
            imServerConfig: imPrivateConf,
            rtcServerConfig: neRtcServerAddresses,
          },
        })

        // 开启私有化
        if (
          imPrivateConf &&
          imPrivateConf.link &&
          neRtcServerAddresses &&
          neRtcServerAddresses.roomServer
        ) {
          this.isPrivatization = true
        }

        isHideMute =
          isHideMute === undefined
            ? this.data.isHideMute
            : isHideMute === 'true' || isHideMute === true
        enableRealtimeLog =
          enableRealtimeLog === undefined
            ? this.data.enableRealtimeLog
            : enableRealtimeLog === 'true' || enableRealtimeLog === true

        this.setData({
          debug,
          offChatRoom,
          enableOrientChat,
          // tags: tagsArr,
          defaultDirectionalTags,
          isHideMute,
        })

        this.roomkit = roomkit
        this._authService = roomkit.getService('authService')
        this._roomService = roomkit.getService('roomService')
        this._messageService = roomkit.getService('messageService')
        this._meetingStatus = 'unlogin'
        this.getDeviceId()
        logger.log('authService', this._authService)
        logger.log('roomService', this._roomService)
        logger.log('messageService', this._messageService)
        logger.log(TAG_NAME, '_initSDK', roomkit)
      } catch (err) {
        logger.error(err, 'err')
        this.setData({
          loading: false,
        })
      }

      // 开启实时日志上传
      if (enableRealtimeLog) {
        wx.setStorageSync(TAG_NAME + '-enableRealtimeLog', true)
      } else {
        wx.removeStorageSync(TAG_NAME + '-enableRealtimeLog')
      }
    },

    // 组件销毁reset
    async destroy() {
      if (!this.roomkit) {
        logger.log('roomkit已销毁')
        return
      }
      logger.log(TAG_NAME, 'destroy')
      wx.offNetworkStatusChange()
      try {
        if (this.roomkit) {
          await this.roomkit.release()
          console.log('已销毁')
        }
        this._resetState()
      } catch (error) {
        logger.log('destroy failed', error)
      }
    },

    // 获取roomkit
    getRoomKit() {
      return this.roomkit
    },

    /**
     * NERoom房间监听
     */
    _addRoomListener() {
      logger.log(this.roomContext, 'this.roomContext')
      this.roomContext.addRoomListener({
        // 成员音频状态回调
        onMemberAudioMuteChanged: (member, mute, operator) => {
          logger.log(
            '监听事件:' + 'onMemberAudioMuteChanged',
            member,
            mute,
            operator?.uuid === member?.uuid
              ? '自己操作'
              : `${operator?.name}:操作`
          )
          member = _generateMember(member)
          operator = _generateMember(operator)
          this._updateUserById({ audio: member.audio }, member.accountId).then(
            () => {
              this._sortUserList()
            }
          )
          const isMySelf = member.accountId === this.data.myUuid // 变更成员是否本人
          const isOperateBySelf = member.accountId === operator.accountId // 是否为本人操作的变更
          isMySelf && this._updateMyInfo(member)
          if (!isMySelf) return // 以下只对当前用户做处理
          // 静音
          if (mute) {
            // 初始化主持人单独开启字段
            this.openAudioByHost = false
            if (!isOperateBySelf) {
              wx.showToast({
                title: '您已被静音',
                icon: 'none',
                duration: 2000,
              })
            }
          } else {
            // 非主持人端提示被解除静音
            if (this.data.myInfo.role !== Role.host && !isOperateBySelf) {
              wx.showToast({
                title: '主持人已将您解除静音，您可以自由发言',
                icon: 'none',
                duration: 2000,
              })
            }
          }
          this.setData({
            btnAudioLoading: false,
          })
        },
        // 成员视频状态回调
        onMemberVideoMuteChanged: async (member, mute, operator) => {
          logger.log(
            '监听事件:' + 'onMemberVideoMuteChanged',
            member,
            mute,
            operator?.uuid === member?.uuid
              ? '自己操作'
              : `${operator?.name}:操作`
          )
          member = _generateMember(member)
          operator = _generateMember(operator)
          this._updateUserById({ video: member.video }, member.accountId).then(
            () => {
              this._sortUserList()
            }
          )
          const isMySelf = member.accountId === this.data.myUuid // 变更成员是否本人
          const isOperateBySelf = member.accountId === operator.accountId // 是否为本人操作的变更
          isMySelf && this._updateMyInfo(member)
          // 关闭视频
          if (mute) {
            // 初始化主持人单独开启字段
            this.openVideoByHost = false
            if (!isOperateBySelf && isMySelf) {
              wx.showToast({
                title: '您已被停止视频',
                icon: 'none',
                duration: 2000,
              })
            }
          } else {
            if (isMySelf) {
              if (isOperateBySelf) {
                // 自己操作
              } else {
                // 他人操作
              }
            } else {
              // 远端开启视频
              if (member.screenSharing === 1) {
                // 有共享画面
                // if (member.main) { // 如果是主屏幕则订阅播放共享画面
                this.playRemoteSubVideo(member.accountId)
                // } else { // 如果是非主屏且画面开启则订阅视频画面
                //   if (member.video === 1) {
                //     this.playRemoteVideo(member.accountId, member.main ? 0 : 1);
                //   }
                // }
              } else if (member.video === 1) {
                this.playRemoteVideo(member.accountId, 'video')
              } else if (member.audio === 1) {
                // todo 这步是否必要
                this.playRemoteVideo(member.accountId, 'audio')
              }
            }
          }
          if (isMySelf) {
            this.setData({
              btnVideoLoading: false,
            })
          }
        },
        // 成员屏幕共享状态回调
        onMemberScreenShareStateChanged: async (
          member,
          isSharing,
          operator
        ) => {
          logger.log(
            '监听事件:' + 'onMemberScreenShareStateChanged',
            member,
            isSharing,
            operator?.uuid === member?.uuid
              ? '自己操作'
              : `${operator?.name}:操作`
          )
          member = _generateMember(member)
          this._updateUserById(
            {
              screenSharing: member.screenSharing,
            },
            member.accountId
          ).then(() => {
            this._sortUserList()
          })
          const isMySelf = member.accountId === this.data.myUuid // 变更成员是否本人
          isMySelf && this._updateMyInfo(member)
          if (isSharing) {
            this.playRemoteSubVideo(member.accountId)
          } else {
            member.video && this.playRemoteVideo(member.accountId, 'video')
          }
        },
        // 成员白板开启/关闭的状态回调
        onMemberWhiteboardStateChanged: async (member, isOpen, operator) => {
          logger.log(
            '监听事件:' + 'onMemberWhiteboardStateChanged',
            member,
            isOpen,
            operator?.uuid === member?.uuid
              ? '自己操作'
              : `${operator?.name}:操作`
          )
          member = _generateMember(member)
          this._updateUserById(
            {
              whiteBoardShare: member.whiteBoardShare,
            },
            member.accountId
          ).then(() => {
            this._sortUserList()
          })
          const isMySelf = member.accountId === this.data.myUuid // 变更成员是否本人
          isMySelf && this._updateMyInfo(member)
          if (isOpen) {
            this.playRemoteSubVideo(member.accountId)
          } else {
          }
        },
        // 成员进入房间回调
        onMemberJoinRoom: (members) => {
          logger.log('监听事件:' + 'onMemberJoinRoom', members)
          // 主持人
          members.map((item) => {
            item = _generateMember(item)
            if (item.role === Role.host) {
              this.hostUuid = item.uuid
              this.hostNickName = item.name
            }
            if (item.uuid === members[0].uuid) {
              item.isInChatroom = true
            }
            const index = this.members.findIndex(
              (origin) => origin.uuid === item.uuid
            )
            if (index > -1) {
              this.members.splice(index, 1, item)
            } else {
              this.members.push(item)
            }
            this.setData({
              hostNickName: item.name,
            })
            this.setMemberInfo()
          })
          this.setData({
            'chatRoomController.getMembers': this.members,
          })
          this._sortUserList()
        },
        // 成员名称改变回调
        onMemberNameChanged: (member, name) => {
          logger.log('监听事件:' + 'onMemberNameChanged', member, name)
          member = _generateMember(member)
          this.members = this.members.map((item) => {
            if (item.uuid === member.uuid) {
              item.name = member.name
              item.nickName = member.name
              return item
            }
            return item
          })
          if (member.role === Role.host) {
            this.hostUuid = member.uuid
            this.hostNickName = name
          }
          console.log(
            '-----------成员名称改变回调-this.members----',
            this.members
          )
          // this.emit('onMemberNameChanged', member, name)
          this.setData({
            'chatRoomController.getMembers': this.members,
          })
          if (member.uuid === this.data.myUuid) {
            //如果更新自己的信息则同步更新聊天室的昵称
            this.setData({
              'chatRoomInfo.chatroomNick': name,
            })
          }
          this._updateUserById({ nickName: name }, member.uuid).then(() => {
            this.setData({
              hostNickName: this.hostNickName,
            })
          })
        },
        // 成员加入RTC频道回调
        onMemberJoinRtcChannel: async (members) => {
          const member = _generateMember(members[0])
          logger.log('监听事件:' + 'onMemberJoinRtcChannel', members)
          if (this.data.myInfo) {
            wx.showToast({
              title: member.nickName + '加入会议',
              icon: 'none',
            })
          }
        },
        // 成员离开聊天室回调
        onMemberLeaveChatroom: (members) => {
          logger.log('监听事件:' + 'onMemberLeaveChatroom', members)
        },
        // 成员离开房间回调
        onMemberLeaveRoom: (members) => {
          logger.log('监听事件:' + 'onMemberLeaveRoom', members)
          const member = members[0]
          logger.debug('onMemberLeaveRoom用户离开:  %i %t', member.uuid)
          // 主持人离开
          if (member.uuid === this.hostUuid) {
            this.hostUuid = ''
            this.hostNickName = ''
            this.setData({
              hostNickName: '',
            })
          }
          if (member.uuid !== this.data.myUuid) {
            // 这里不用重新获取远端数据，防止成员顺序变更后重新排序带来的画面重绘
            const leaveUserIndex = this.members.findIndex(
              (item) => item.accountId === member.uuid
            )
            if (leaveUserIndex > -1) {
              this.members.splice(leaveUserIndex, 1)
            }
            this.setData({
              'chatRoomController.getMembers': this.members,
            })
            this.setMemberInfo()
          } else {
            // 本端离开
            const reason = member.reason
            if (reason.type === 'SELF_KICK') {
              if (member.reason.deviceId !== this.getDeviceId()) {
                return
              } else {
                wx.showToast({
                  title: '您已在其他设备登录',
                  icon: 'none',
                })
              }
            } else if (reason.type === 'ADMIN_KICK') {
              wx.showToast({
                title: '您已被主持人移出会议',
                icon: 'none',
              })
            }
            // 延迟执行，以免异常弹窗未被看到
            setTimeout(() => {
              this.triggerEvent('leave')
            }, 1000)
          }
        },
        // 成员离开RTC频道回调
        onMemberLeaveRtcChannel: (members) => {
          logger.log('监听事件:' + 'onMemberLeaveRtcChannel', members)
          // 相关逻辑在onMemberLeaveRoom中处理
        },
        // 成员角色变更回调
        onMemberRoleChanged: (member, beforeRole, afterRole) => {
          member = _generateMember(member)
          logger.log(
            '监听事件:' + 'onMemberRoleChanged',
            member,
            beforeRole,
            afterRole
          )
          this._onMemberRoleChanged(member, beforeRole, afterRole)
        },
        // 聊天室消息回调
        onReceiveChatroomMessages: (messages) => {
          logger.log(
            '监听事件:' + TAG_NAME,
            'onReceiveChatroomMessages',
            messages
          )
          this.setData({
            chatRoomMsgs: messages,
          })
          // logger.log('监听事件:' + 'onReceiveChatroomMessages', messages);
        },
        // 房间属性变更回调
        onRoomPropertiesChanged: (properties) => {
          logger.log('监听事件: onRoomPropertiesChanged', properties)
          this._onRoomPropertiesChanged(properties)
        },
        // 房间锁定状态回调
        onRoomLockStateChanged: (isLocked) => {
          logger.log('监听事件:' + TAG_NAME, 'event: 会议锁定', isLocked)
          this.triggerEvent('onRoomLockStateChanged', isLocked)
        },
        // 成员属性修改回调（handsUp:举手，wbDrawable:取消白板授权）
        onMemberPropertiesChanged: (userUuid, properties) => {
          logger.log(
            '监听事件:' + TAG_NAME,
            'onMemberPropertiesChanged',
            userUuid,
            properties
          )
        },
        // 成员属性删除回调（handsUp:举手，wbDrawable:取消白板授权）
        onMemberPropertiesDeleted: (member, properties) => {
          logger.log(TAG_NAME, 'onMemberPropertiesDeleted', member, properties)
          // yqtodo：回调处理
        },
        // 房间属性删除回调
        onRoomPropertiesDeleted: (keys) => {
          logger.log(TAG_NAME, 'onRoomPropertiesDeleted', keys)
          if (keys) {
            Object.keys(keys).forEach((key) => {
              if (key === 'focus') {
                this._cancelFocus().then(() => {
                  this._sortUserList()
                })
              }
            })
          }
        },
        // 房间结束回调
        onRoomEnded: (reason) => {
          logger.log('监听事件: onRoomEnded', reason)
          if (reason === 9) {
            // 被移除
            this._onKicked(reason)
          } else {
            wx.showToast({
              title: '主持人已结束会议',
              icon: 'none',
            })
            this.roomContext.leaveRoom()
            this.triggerEvent('meetingClosed')
          }
        },
        // 当前说话最大声者变更回调
        onRtcActiveSpeakerChanged: (speaker) => {
          logger.log(TAG_NAME, 'onRtcActiveSpeakerChanged', speaker)
        },
        // RTC频道错误回调
        onRtcError: (data) => {
          logger.log('监听事件: onRtcError', data)
        },
        // 网络状态变更回调
        onRoomConnectStateChanged: (data) => {
          logger.log('监听事件: onRoomConnectStateChanged', data)
          this._connectionStateChange(data)
        },
        // 通知应用程序协商不支持事件
        onRtcAbilityNotSupport: (event) => {
          logger.log('监听事件: onRtcAbilityNotSupport', event)
          const { uid, code } = event
          if (code === 406 && uid === this.data.myUuid) {
            wx.showToast({
              title: `远端视频格式不支持，解码失败`,
              icon: 'none',
              duration: 3000,
            })
          }
        },
        onMemberStreamChanged: (member) => {
          logger.log('监听事件: onMemberStreamChanged', member)
          member = _generateMember(member)
          this._updateUserById({ stream: member.stream }, member.accountId)
          const isMySelf = member.accountId === this.data.myUuid // 变更成员是否本人
          isMySelf && this._updateMyInfo(member)
        },
      })
    },

    /**
     * RTC房间监听
     */
    _addRtcListener() {
      this.rtcController.addListener({
        onCameraDeviceChanged: (data) => {
          logger.log('onCameraDeviceChanged', data)
          this.triggerEvent('deviceChange')
        },
        onSpeakerDeviceChanged: (data) => {
          logger.log('onSpeakerDeviceChanged', data)
          this.triggerEvent('deviceChange')
        },
        onRecordDeviceChanged: (data) => {
          logger.log('onRecordDeviceChanged', data)
          this.triggerEvent('deviceChange')
        },
      })
    },

    /**
     * 会控消息监听
     */
    _addMessageChannelListener() {
      this._messageService.addMessageChannelListener({
        // 消息透传
        onReceiveCustomMessage: (res) => {
          logger.log('onReceiveCustomMessage:', res)
          let body = res.data.body
          if (Object.prototype.toString.call(body) == '[object String]') {
            body = JSON.parse(body)
          }
          // 主持人可开启
          switch (body.type) {
            case 1:
              logger.debug('开启mic请求 %t')
              this.openAudioByHost = true
              this.myAudioBeOpened()
              break
            case 2:
              logger.debug('开启camera请求 %t')
              this.openVideoByHost = true
              this.myVideoBeOpened()
              break
            case 3:
              logger.debug('开启音视频请求 %t')
              // 非主持人或者联席主持人打开自己的
              this.openVideoByHost = true
              this.openAudioByHost = true
              this.myAudioBeOpened()
              this.myVideoBeOpened()
              break
          }
        },
      })
    },

    // 匿名登录
    anonymousJoinMeeting() {
      logger.log(TAG_NAME, 'anonymousJoinMeeting')
      this.loginState = LoginState.logining
      this.triggerEvent('onLoginStateChange', this.loginState)

      return new Promise(async (resolve, reject) => {
        try {
          // 超时未加入处理
          this._joinOverTime()
          const res = await sendRequest({
            url: `${this.data._baseDomain}/scene/apps/${this.data._appKey}/v1/anonymous/login`,
            header: {
              deviceId: this.getDeviceId(),
            },
          })
          if (res) {
            this.setData({
              _userUuid: res.userUuid,
              _userToken: res.userToken,
            })
          }
          this._authService
            .login(res.userUuid, res.userToken)
            .then((res) => {
              logger.log(TAG_NAME, 'anonymousJoinMeeting response', res)
              this.loginState = LoginState.logined
              this._isAnonymous = true
              this.triggerEvent('onLoginStateChange', this.loginState)
              resolve()
            })
            .catch((error) => {
              logger.error(TAG_NAME, 'anonymousJoinMeeting fail: ', error)
              reject(error)
            })
        } catch (err) {
          clearTimeout(this.joinTimer)
          logger.error(TAG_NAME, 'anonymousJoinMeeting fail: ', err)
          reject(err)
        }
      })
    },

    // token登录
    loginWithToken(params) {
      console.log(params, 8888)
      return new Promise((resolve, reject) => {
        try {
          logger.log(TAG_NAME, 'loginWithToken', params)
          this.loginState = LoginState.logining
          // 超时未加入处理
          this._joinOverTime()
          this.triggerEvent('onLoginStateChange', this.loginState)
          if (!this.roomkit) {
            throw Error('SDK_UN_INITIALIZE')
          }
          this.setData({
            _userUuid: params.accountId,
            _userToken: params.accountToken,
          })
          this._authService
            .login(params.accountId, params.accountToken)
            .then((res) => {
              logger.log(TAG_NAME, 'loginWithToken response', res)
              this.loginState = LoginState.logined
              this.triggerEvent('onLoginStateChange', this.loginState)
              resolve()
            })
            .catch((error) => {
              logger.error(TAG_NAME, 'loginWithToken fail: ', error)
              reject(error)
            })
        } catch (error) {
          clearTimeout(this.joinTimer)
          logger.error(TAG_NAME, 'loginWithToken fail: ', err)
          reject(err)
        }
      })
    },

    // 登出
    async logout() {
      logger.log(TAG_NAME, 'logout')
      if (this.loginState === LoginState.logouting) {
        return
      }
      try {
        this.loginState = LoginState.logouting
        this.triggerEvent('onLoginStateChange', this.loginState)
        if (this.roomkit) {
          await this._authService.logout()
        }
        // 向外通知已经退出登录
      } catch (error) {
        logger.error(TAG_NAME, 'logout fail: ', error)
        throw error
      } finally {
        this._resetState()
        this.triggerEvent('onLoginStateChange', this.loginState)
      }
    },

    // 进入房间
    async joinRoom(options) {
      logger.log(options, 'joinRoom options')
      let openCamera =
        options.openCamera === 'true' || options.openCamera === true
      let openMicrophone =
        options.openMicrophone === 'true' || options.openMicrophone === true

      try {
        // 再加入roomkit房间
        await this._joinRoomKit(options)
        this._addRoomListener()
        // this._addRtcListener()
        this._addMessageChannelListener()

        // 加入rtc房间
        await this.rtcController.joinRtcChannel()
        logger.log(TAG_NAME, 'joinRoom success')
        // 处理会议信息
        this.getAllUserList()
        await this.getMeetingInfo()
        this._sortUserList()
        this._subscribeRemoteStream()
        this._offlineHandle()
        logger.log(
          this.videoAttendeeOff,
          this.audioAttendeeOff,
          'video audio attendeeOff'
        )

        // 主持人入会
        if (this.hostUuid === this.data.myUuid) {
          // 主持人
          if (openCamera || openMicrophone) {
            if (openCamera) {
              await this.operateMyAVStream('video', true)
            }
            if (openMicrophone) {
              await this.operateMyAVStream('audio', true)
            }
          }
        } else {
          // audioAttendeeOff / videoAttendeeOff未设置时值为空
          const audioAllowed = this.audioAttendeeOff
            ? this.audioAttendeeOff === AttendeeOffType.disable
            : true
          const videoAllowed = this.videoAttendeeOff
            ? this.videoAttendeeOff === AttendeeOffType.disable
            : true

          // 开启音频或者视频入会&允许被开启
          if (openCamera && videoAllowed) {
            await this.operateMyAVStream('video', true)
          }
          if (openMicrophone && audioAllowed) {
            await this.operateMyAVStream('audio', true)
          }
          console.log(
            this.audioAttendeeOff,
            this.videoAttendeeOff,
            'audioAttendeeOff, videoAttendeeOff'
          )
          // 主持人开启全体关闭
          if (
            this.audioAttendeeOff &&
            this.audioAttendeeOff !== AttendeeOffType.disable
          ) {
            wx.showToast({
              title: '您已被静音',
              icon: 'none',
            })
            if (this.videoAttendeeOff !== AttendeeOffType.disable) {
              setTimeout(() => {
                wx.showToast({
                  title: '主持人设置了全体关闭视频',
                  icon: 'none',
                })
              }, 1500)
            }
          } else if (this.videoAttendeeOff !== AttendeeOffType.disable) {
            wx.showToast({
              title: '主持人设置了全体关闭视频',
              icon: 'none',
            })
          }
        }

        // 开启聊天室模块
        if (!this.data.offChatRoom) {
          const { enableOrientChat, tags, defaultDirectionalTags } = this.data
          const tagInfo = {
            // enableOrientChat - 是否开启定向发送消息模式，默认关闭
            enableOrientChat:
              enableOrientChat === undefined ? false : enableOrientChat,
            // tags,
            defaultDirectionalTags,
          }
          this.setChatRoomInfo(this.chatController, options.nickName, tagInfo)
        }
        this._isActive = true
        this._meetingStatus = 'login'
        this.setData({
          loading: false,
        })
      } catch (error) {
        await this.destroy()
        this.setData({
          loading: false,
        })
        logger.error('joinRoom fail: ', error)
        return Promise.reject(error)
      }
    },

    // 进入Roomkit房间
    async _joinRoomKit(options) {
      try {
        const roomInfo = await sendRequest({
          url: `${this.data._baseDomain}/scene/meeting/${this.data._appKey}/v1/info/${options.meetingId}`,
          method: 'GET',
          header: {
            user: this.data._userUuid || '',
            token: this.data._userToken || '',
            deviceId: this.getDeviceId(),
          },
        })
        console.log(roomInfo, 'roomInfo')
        this._meetingInfo = roomInfo
        const roomUuid = roomInfo && roomInfo.roomUuid
        return this._roomService
          .joinRoom({
            role: options.role,
            roomUuid,
            userName: options.nickName,
            password: options.password,
            initialProperties: options.initialProperties,
          })
          .then((res) => {
            console.log(res, '_joinRoomKit res')
            const roomContext = this._roomService.getRoomContext(roomUuid)
            this.roomContext = roomContext
            this.rtcController = roomContext.rtcController
            this.chatController = roomContext.chatController
            console.log('roomContext', roomContext)
            console.log('rtcController', this.rtcController)
            console.log('chatController', this.chatController)
          })
      } catch (err) {
        return Promise.reject(err)
      }
    },

    /**
     * 退房，停止推流和拉流，并重置数据
     * @param {Boolean} end 如果是房间主持人，在离开房间时是否直接结束房间
     * @returns {Promise}
     */
    async leaveRoom() {
      logger.log(TAG_NAME, 'leaveRoom')
      try {
        if (!this._isActive) {
          return
        }
        if (!this.roomkit) {
          throw Error('SDK_UN_INITIALIZE')
        }
        logger.log('leave() %t')
        await this.roomContext.leaveRoom()
        this._isActive = false
        logger.log('leaveRoom successed')
      } catch (e) {
        return Promise.reject(e)
      }
    },

    /**
     * 获取成员信息
     */
    getAllUserList() {
      const remoteMembers = this.roomContext.remoteMembers
      const localMember = this.roomContext.localMember
      const roomProperties = this.roomContext.roomProperties
      this.focusUuid =
        this.focusUuid ||
        (roomProperties.focus ? roomProperties.focus.value : 0)
      this.localMember = _generateMember(localMember)
      const inRtcRemoteMembers = remoteMembers.filter(
        (item) => item.isInRtcChannel === true
      )
      let members = [localMember, ...inRtcRemoteMembers]
      // 过滤不在rtc房间内的成员
      this.members = members.map((member) => {
        member = _generateMember(member)
        if (member.role === Role.host) {
          this.hostUuid = member.uuid
          this.hostNickName = member.nickName
        }
        // 还原焦点视频
        if (member.uuid === this.focusUuid) {
          member.isFocus = true
        }
        // 小程序置顶成员
        if (member.uuid === this.localTopUserId) {
          member.isTop = true
        }
        // 主持人设置
        if (member.role === Role.host) {
          this.hostUuid = member.uuid
          this.hostNickName = member.name
        }
        return member
      })
      console.log(this.members, 'getAllUserList')
      this.setData({
        myInfo: this.localMember,
        myUuid: this.localMember.uuid,
        userList: this.members,
        hostNickName: this.hostNickName,
      })
      this.setMemberInfo()
    },

    // 设置成员相关参数
    setMemberInfo() {
      const onlineUserMember = this.members.length || 1
      this.setData({
        userList: this.members,
        onlineUserMember,
        smallScreenShow: onlineUserMember > 1,
      })
    },

    /**
     * 获取会议信息
     * type: 控制类型，audio音频，video视频，whiteboard白板
     * state: 全局控制状态，1:全体关闭控制，0:取消全体关闭控制
     * attendeeOff: 入会后自动关闭，0:无，1:关闭，2:关闭且不能自行操作，默认不操作(会议中不可修改)
     * allowSelfOn: 允许自行解除关闭控制，true:允许，false:不允许，默认允许(会议中可二次修改)
     * meetingMaxCount: 创建会议时设置的总人数，没有时页面展示在线人数，可以设置比在线人数少
     */
    async getMeetingInfo() {
      const roomProperties = this.roomContext.roomProperties
      const screenSharersAvRoomUid =
        this.rtcController.getScreenSharingUserUuid()
      const whiteboardAvRoomUid = roomProperties.wbSharingUuid
        ? roomProperties.wbSharingUuid.value
        : 0
      this.focusUuid = roomProperties.focus ? roomProperties.focus.value : 0
      let shareMode = 0
      if (roomProperties.audioOff) {
        // 入会时音频限制
        this.audioAttendeeOff = roomProperties.audioOff.value?.split('_')[0]
      }
      if (roomProperties.videoOff) {
        // 入会时视频限制
        this.videoAttendeeOff = roomProperties.videoOff.value?.split('_')[0]
      }
      console.log(this.videoAttendeeOff, 'videoAttendeeOff')
      console.log(this.audioAttendeeOff, 'audioAttendeeOff')
      if (screenSharersAvRoomUid && whiteboardAvRoomUid) {
        shareMode = 3
      } else if (screenSharersAvRoomUid) {
        shareMode = 1
      } else if (whiteboardAvRoomUid) {
        shareMode = 2
      }
      const {
        subject,
        startTime,
        endTime,
        type,
        settings,
        shortMeetingNum,
        meetingNum,
      } = this._meetingInfo
      const extraData =
        settings.roomInfo.roomProperties &&
        settings.roomInfo.roomProperties.extraData &&
        settings.roomInfo.roomProperties.extraData.value
      const meetingData = {
        meetingId: meetingNum,
        hostUuid: this.hostUuid,
        hostNickName: this.hostNickName,
        focusUuid: this.focusUuid,
        screenSharersAvRoomUid: screenSharersAvRoomUid
          ? [screenSharersAvRoomUid]
          : [],
        screenSharersAccountId: screenSharersAvRoomUid
          ? [screenSharersAvRoomUid]
          : [],
        properties: roomProperties,
        password: this.roomContext.password,
        subject,
        startTime,
        endTime,
        type, // 1即刻会议2个人会议3预约会议
        shareMode,
        extraData,
        settings: settings,
        shortId: shortMeetingNum,
        sipCid: this.roomContext.sipId,
        videoAttendeeOff: this.videoAttendeeOff,
        audioAttendeeOff: this.audioAttendeeOff,
      }
      const meetingMaxCount = extraData ? JSON.parse(extraData).maxCount : ''
      this.setData({
        meetingInfo: meetingData,
        hostNickName: this.hostNickName,
        meetingExtraData: extraData,
        meetingMaxCount,
      })
      console.log(
        { members: this.members, meeting: meetingData },
        'meetingInfo'
      )
      return Promise.resolve({
        code: 200,
        ret: {
          members: this.members,
          meeting: meetingData,
        },
      })
    },

    // 加入超时15s后销毁组件（防止小程序SocketTask超出卡在loading页面）
    _joinOverTime() {
      logger.log('_joinOverTime')
      this.joinTimer = setTimeout(async () => {
        if (this.data.loading) {
          logger.warn('加入会议超时，请删除小程序后重试')
          await this.destroy()
          wx.showToast({
            title: '加入会议超时，请删除小程序后重试',
            icon: 'none',
            duration: 2000,
          })
          wx.navigateBack()
        }
        clearTimeout(this.joinTimer)
      }, 15000)
    },

    /**
     * 更新自己的信息（操作栏状态）
     * @param {*} member _generateMember之后的本地信息
     */
    _updateMyInfo(member) {
      logger.log(TAG_NAME, '_updateMyInfo', member)
      if (member && member.accountId !== this.data.myUuid) return
      let myInfo = member || _generateMember(this.roomContext.localMember)
      myInfo = { ...this.data.myInfo, ...myInfo }
      this.setData({
        myInfo,
      })
    },

    /**
     * 设置焦点视频优先级规则
     * 1. 优先展示主持人设置的焦点视频
     * 2. 再展示自己设置的置顶视频
     * 3. 再展示开启了视频画面的视频或者视频共享画面
     * 4. 最后展示开启了麦克风的视频
     **/
    _sortUserList() {
      if (this.data.sortListTimer) {
        return
      }
      // 防止频繁排序更新
      this.data.sortListTimer = setTimeout(() => {
        const userList = this.data.userList
        userList.sort((pre, next) => {
          // 0 表示不变，-1表示pre排前面，1表示next排前面
          if (
            (pre.screenSharing && next.screenSharing) ||
            (!pre.screenSharing && !next.screenSharing)
          ) {
            // 都开共享屏幕或都没有共享
            if (
              (pre.isFocus && next.isFocus) ||
              (!pre.isFocus && !next.isFocus)
            ) {
              // 都是焦点或者非焦点
              if ((pre.isTop && next.isTop) || (!pre.isTop && !next.isTop)) {
                // 都是置顶或者非置顶
                if (pre.stream && next.stream) {
                  // 都存在流或者都不存在流的时候
                  const isPreVideo = pre.video === 1
                  const isNextVideo =
                    next.video === 1 || next.screenSharing === 1
                  if (
                    (isPreVideo && isNextVideo) ||
                    (!isPreVideo && !isNextVideo)
                  ) {
                    // 视频或者共享屏幕都开或者都关的时候
                    const isPreAudio = pre.audio === 1
                    const isNextAudio = next.audio === 1
                    if (
                      (isPreAudio && isNextAudio) ||
                      (!isPreAudio && !isNextAudio)
                    ) {
                      // 音频或者共享屏幕都开或者都关的时候
                      // 如果都是静音优先展示主持人画面
                      if (!isPreAudio && !isNextAudio) {
                        const isPreHost = pre.accountId === this.hostUuid
                        const isNextHost = next.accountId === this.hostUuid
                        if (isPreHost || isNextHost) {
                          return !!isPreHost > !!isNextHost ? -1 : 1
                        } else {
                          return 0
                        }
                      } else {
                        pre.volume = pre.volume || 0
                        next.volume = next.volume || 0
                        return next.volume === pre.volume
                          ? 0 // 音量相同
                          : pre.volume > next.volume
                          ? -1
                          : 1 // 音量大的排前面
                      }
                    } else {
                      return !!isPreAudio > !!isNextAudio ? -1 : 1
                    }
                  } else {
                    return !!isPreVideo > !!isNextVideo ? -1 : 1
                  }
                } else if (!pre.stream && !next.stream) {
                  return 0
                } else {
                  return !!pre.stream > !!next.stream ? -1 : 1
                }
              } else {
                // 有一个置顶
                return !!pre.isTop > !!next.isTop ? -1 : 1
              }
            } else {
              // 两个不同时为焦点视频
              // 如果pre为焦点则排前面
              return !!pre.isFocus > !!next.isFocus ? -1 : 1
            }
          } else {
            // 如果pre为共享屏幕则排前面
            return !!pre.screenSharing > !!next.screenSharing ? -1 : 1
          }
        })
        this.setData({
          userList,
        })
        this.data.sortListTimer = null
        logger.warn(userList, '设置焦点视频')
      }, 100) // 增加100ms，防止100ms内多次触发
    },

    /**
     * 重置状态
     */
    _resetState() {
      this.setData({
        userList: [],
        showChatRoom: false,
        isSettingConfirm: false,
        hasHided: false,
        isOriginCameraOn: false,
        isOriginMicOn: false,
        loading: false,
      })
      this.members = []
      this.isAudioConfirm = false
      this.isVideoConfirm = false
      this._isActive = false
      this._isAnonymous = false
      this.loginState = LoginState.idle
      this._meetingStatus = 'unlogin'
      this.isPrivatization = false
      this.openAudioByHost = false
      this.openVideoByHost = false
      clearTimeout(this.joinTimer)
      clearTimeout(this.videoLoadingTimer)
      clearTimeout(this.audioLoadingTimer)
      wx.removeStorageSync(TAG_NAME + '-enableRealtimeLog')
      // todo 是否需要去除roomkit
      // this.roomkit = null
    },

    /**
     * 保持屏幕常亮
     */
    _keepScreenOn() {
      setInterval(() => {
        wx.setKeepScreenOn({
          keepScreenOn: true,
        })
      }, 20000)
    },

    // 延迟5s隐藏操作栏
    _setToolsHide() {
      clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        // 5s内没有点击行为就隐藏tools
        if (!this.boradClick) {
          this.setData({
            toolsVisible: false,
          })
        } else {
          this._setToolsHide()
          this.setData({
            toolsVisible: false,
          })
          this.boradClick = false
        }
      }, 5000)
    },

    // 点击空白区显示隐藏操作栏
    _onclickRoomBoard() {
      let toolsVisible = this.data.toolsVisible
      this.setData({
        toolsVisible: !toolsVisible,
      })
      this.boradClick = true
      this._setToolsHide()
    },

    // 点击操作栏
    _onclickTools() {
      this.boradClick = true
      this._setToolsHide()
    },

    /**
     * 切换前后摄像头-默认front
     */
    async switchCamera() {
      logger.log(TAG_NAME, 'switchCamera')
      try {
        // deviceId为"front"|"back"
        const { deviceId } = await this.rtcController.switchDevice({
          type: 'camera',
          deviceId: '',
        })
        logger.log(TAG_NAME, 'switchCamera success', deviceId)
        const myIndex = this.data.userList.findIndex(
          (user) => user.accountId === this.data.myUuid
        )
        if (myIndex > -1) {
          this.data.userList[myIndex].stream.frontCamera = deviceId
        }
      } catch (error) {
        logger.error(error)
      }
    },

    /**
     * 切换前后摄像头-默认speaker
     */
    switchAudioOutPutMode() {
      const audioOutPutMode = this.data.audioOutPutMode
      // logger.log(TAG_NAME, 'switchAudioOutPutMode', audioOutPutMode)
      this.setData(
        {
          audioOutPutMode: audioOutPutMode === 'speaker' ? 'ear' : 'speaker',
        },
        () => {
          logger.log(
            TAG_NAME,
            '当前音频输设置为',
            audioOutPutMode === 'speaker' ? 'ear' : 'speaker'
          )
          resolve()
        }
      )
    },

    // 检测视频开关
    _checkVideoLoading() {
      this.videoLoadingTimer = setTimeout(async () => {
        if (this.data.btnVideoLoading) {
          logger.warn('打开超时，请重试')
          this.setData({
            btnVideoLoading: false,
          })
          this.getMeetingInfo()
        }
        clearTimeout(this.videoLoadingTimer)
      }, 5000)
    },

    // 检测音频开关
    _checkAudioLoading() {
      this.audioLoadingTimer = setTimeout(async () => {
        if (this.data.btnAudioLoading) {
          logger.warn('打开超时，请重试')
          this.setData({
            btnAudioLoading: false,
          })
          this.getMeetingInfo()
        }
        clearTimeout(this.audioLoadingTimer)
      }, 5000)
    },

    // 本端视频开关
    _toggleVideo() {
      const enableCamera =
        this.data.myInfo && this.data.myInfo.stream
          ? this.data.myInfo.video === 1
          : false
      logger.log(
        TAG_NAME,
        `_toggleVideo ${enableCamera ? '关闭' : '开启'}摄像头`,
        this.videoAttendeeOff
      )

      // 全体关闭且不让自主打开 && 非主持人身份
      if (
        this.videoAttendeeOff === AttendeeOffType.offNotAllowSelfOn &&
        !enableCamera &&
        this.data.myInfo.role !== Role.coHost &&
        this.data.myInfo.role !== Role.host
      ) {
        wx.showToast({
          title: '主持人管控中，无法开启',
          icon: 'none',
          duration: 2000,
        })
        return
      }
      // 未开启摄像头权限
      logger.log(this.data.noVideoAuthSetting, '未开启摄像头权限')
      if (this.data.noVideoAuthSetting) {
        this.handleOpenSetting()
        return
      }
      if (enableCamera) {
        this.operateMyAVStream('video', false)
      } else {
        this.operateMyAVStream('video', true)
      }
      this.setData({
        btnVideoLoading: true,
      })
      this._checkVideoLoading()
    },

    // 本端音频开关
    _toggleAudio() {
      const enableMic =
        this.data.myInfo && this.data.myInfo.stream
          ? this.data.myInfo.audio === 1
          : false
      logger.log(
        TAG_NAME,
        `_toggleAudio ${enableMic ? '关闭' : '开启'}麦克风`,
        this.audioAttendeeOff
      )

      // 全体关闭且不让自主打开 && 非主持人身份
      if (
        this.audioAttendeeOff === AttendeeOffType.offNotAllowSelfOn &&
        !enableMic &&
        this.data.myInfo.role !== Role.coHost &&
        this.data.myInfo.role !== Role.host
      ) {
        wx.showToast({
          title: '主持人管控中，无法开启',
          icon: 'none',
          duration: 2000,
        })
        return
      }
      // 未开启麦克风权限
      if (this.data.noAudioAuthSetting) {
        this.handleOpenSetting()
        return
      }
      if (enableMic) {
        this.operateMyAVStream('audio', false)
      } else {
        this.operateMyAVStream('audio', true)
      }
      this.setData({
        btnAudioLoading: true,
      })
      this._checkAudioLoading()
    },

    // 收到会控:开启视频
    myVideoBeOpened() {
      // 已经开启了就不处理
      if (this.isVideoConfirm || this.data.myInfo.video === 1) return
      wx.showModal({
        title: '是否打开摄像头',
        content: '主持人邀请您开启视频，是否开启摄像头以使其他成员看您的画面',
        confirmText: '是',
        cancelText: '否',
        success: (res) => {
          this.isVideoConfirm = false
          // 未开启摄像头权限
          if (this.data.noVideoAuthSetting) {
            this.handleOpenSetting()
            return
          }
          // 收到弹窗后未操作，主持人又关闭了全体视频的情况(主持人单独开启除外)
          if (
            !this.openVideoByHost &&
            this.videoAttendeeOff === AttendeeOffType.offNotAllowSelfOn &&
            res.confirm &&
            this.data.myInfo.role !== Role.coHost &&
            this.data.myInfo.role !== Role.host
          ) {
            wx.showToast({
              title: '主持人管控中，无法开启',
              icon: 'none',
              duration: 2000,
            })
            return
          }
          if (res.confirm) {
            this.operateMyAVStream('video', true)
          } else if (res.cancel) {
            logger.log('myVideoBeOpened 用户点击取消')
          }
        },
      })
      this.isVideoConfirm = true
    },
    // 收到会控:开启音频
    myAudioBeOpened() {
      // 已经开启了就不处理
      if (this.isAudioConfirm || this.data.myInfo.audio === 1) return
      wx.showModal({
        title: '是否打开麦克风',
        content: '主持人邀请您发言，是否开启麦克风以使其他成员听到您的声音',
        confirmText: '是',
        cancelText: '否',
        success: (res) => {
          this.isAudioConfirm = false
          // 未开启麦克风权限
          if (this.data.noAudioAuthSetting) {
            this.handleOpenSetting()
            return
          }
          // 收到弹窗后未操作，主持人又关闭了全体音频且不允许自己打开的情况(主持人单独开启除外)
          if (
            !this.openAudioByHost &&
            this.audioAttendeeOff === AttendeeOffType.offNotAllowSelfOn &&
            res.confirm &&
            this.data.myInfo.role !== Role.coHost &&
            this.data.myInfo.role !== Role.host
          ) {
            wx.showToast({
              title: '主持人管控中，无法开启',
              icon: 'none',
              duration: 2000,
            })
            return
          }
          if (res.confirm) {
            this.operateMyAVStream('audio', true)
          } else if (res.cancel) {
            logger.log('myAudioBeOpened 用户点击取消')
          }
        },
      })
      this.isAudioConfirm = true
    },

    // 关闭本端音视频
    async muteMyMedia() {
      try {
        logger.log('muteMyMedia')
        const enableCamera =
          this.data.myInfo && this.data.myInfo.stream
            ? this.data.myInfo.video === 1
            : false
        const enableMic =
          this.data.myInfo && this.data.myInfo.stream
            ? this.data.myInfo.audio === 1
            : false
        if (enableMic) {
          await this.operateMyAVStream('audio', false)
          this.setData({
            isOriginMicOn: true,
          })
        }
        if (enableCamera) {
          this.operateMyAVStream('video', false)
          this.setData({
            isOriginCameraOn: true,
          })
        }
      } catch (error) {
        logger.error(error, 'muteMyMedia')
        throw Error(error, 'muteMyMedia')
      }
    },

    // 小程序启动，或从后台进入前台显示时需要触发的toast提示
    onShowToast(title) {
      // 如果被动关闭了音频
      if (this.data.isOriginMicOn || this.data.isOriginCameraOn) {
        // 用定时器是因为屏幕翻转，toast样式被覆盖
        setTimeout(() => {
          wx.showToast({
            title: title || '您的音视频设备已被关闭，如有需要请重新开启',
            icon: 'none',
            duration: 3000,
            success: () => {
              this.setData({
                isOriginCameraOn: false,
                isOriginMicOn: false,
                hasHided: false,
              })
            },
          })
        }, 2000)
      }
    },

    /**
     * 小画面相关事件
     */
    _toggleSmallScreen() {
      this.setData({
        smallScreenShow: !this.data.smallScreenShow,
      })
    },

    _playerStateChange(event) {
      const { code, message } = event.detail
      const { nickname, userid } = event.currentTarget.dataset
      switch (code) {
        case -2301:
          logger.error(TAG_NAME, message, code)
          wx.showToast({
            title: `获取 ${nickname} 流失败`,
            icon: 'none',
            duration: 2000,
          })
          if (typeof this.data.retryRemoteObj[userid] !== 'number') {
            // 第一次拉流失败，放入待重连的列表中
            this.data.retryRemoteObj[userid] = -1
            if (this.data.isConnected) {
              this.retryRemoteStream(userid)
            }
          } else if (this.data.retryRemoteObj[userid] > -1) {
            // 已重试过一次，直接退出
            wx.showToast({
              title: `请重新加入房间`,
              icon: 'none',
              duration: 2000,
            })
            this.triggerEvent('leave')
            return
          }
          break
        case 6000:
          logger.error(TAG_NAME, message || '拉流被挂起', code)
          // wx.showToast({
          //   title: `live-player拉流挂起`,
          //   icon: 'none',
          //   duration: 2000,
          // })
          break
        default:
          logger.info(TAG_NAME, '_playerStateChange', message, code)
          break
      }
    },
    // 重新连接远端流
    retryRemoteStream(userid) {
      logger.log(TAG_NAME, 'retryRemoteStream', userid)
      const retryMember = userid
        ? [userid]
        : Object.keys(this.data.retryRemoteObj)
      const retryRemoteObj = this.data.retryRemoteObj
      logger.debug('断网重连后，重新拉之前失败的远端流', retryRemoteObj)
      retryMember.map(async (userid) => {
        if (retryRemoteObj[userid] === -1) {
          logger.debug('=== 重试 ', userid)
          const member = this.data.userList.filter(
            (item) => item.accountId === userid
          )
          if (member) {
            const { stream, accountId } = member
            try {
              retryRemoteObj[userid]++
              if (member.screenSharing === 1) {
                stream.subStreamUrl = ''
                this._updateUserById({ stream }, accountId)
                this.playRemoteSubVideo(accountId)
              } else if (member.video === 1) {
                stream.url = ''
                this._updateUserById({ stream }, accountId)
                this.playRemoteVideo(accountId, 'video')
              } else if (member.audio === 1) {
                this.playRemoteVideo(accountId, 'audio')
              } else {
                retryRemoteObj[userid]--
              }
            } catch (error) {
              wx.showToast({
                title: `请重新加入房间`,
                icon: 'none',
                duration: 2000,
              })
              this.triggerEvent('leave')
            }
          }
        }
      })
      // 重置每个成员的画面，修复推流正常但画面卡住的问题
      const list = this.data.userList
      this.setData({
        userList: [],
      })
      this.setData({
        userList: list,
      })
    },
    // _pusherNetStatusHandler(event) {
    //   // logger.log(TAG_NAME, '_pusherNetStatusHandler', event.detail.info)
    // },
    // 对端音量大小监听
    _playerAudioVolumeNotify: prevent(function (event) {
      const userId = event.currentTarget.dataset.userid
      const volume = event.detail.volume
      // logger.logButNotReport(TAG_NAME, userId, '_playerAudioVolumeNotify', volume)

      if (!volume) return
      const hasFocusUser = this.data.userList.find((user) => {
        return user.isFocus || user.isTop
      })
      // 存在焦点视频就不设置了
      if (hasFocusUser) return
      // 5s更新参会者音量
      this._updateUserById({ volume }, userId).then(() => {
        this._sortUserList()
      })
    }, 5000),
    // 本端音量大小监听
    _pusherAudioVolumeNotify: prevent(function (event) {
      const userId = event.currentTarget.dataset.userid
      const volume = event.detail.volume
      // logger.logButNotReport(TAG_NAME, userId, '_pusherAudioVolumeNotify', volume)
      if (!volume) return
      const hasFocusUser = this.data.userList.find((user) => {
        return user.isFocus || user.isTop
      })
      // 存在焦点视频就不设置了
      if (hasFocusUser) return
      // 5s更新本端音量
      this._updateUserById({ volume }, userId).then(() => {
        this._sortUserList()
      })
    }, 5000),

    _pusherStateChangeHandler(event) {
      const { code, message } = event.detail
      switch (code) {
        case 0: // 未知状态码，不做处理
          logger.log(TAG_NAME, message, code)
          break
        case 1001:
          logger.log(TAG_NAME, '已经连接推流服务器', code)
          break
        case 1002:
          logger.log(TAG_NAME, '已经与服务器握手完毕,开始推流', code)
          break
        case 1003:
          logger.log(TAG_NAME, '打开摄像头成功', code)
          break
        case 1004:
          logger.log(TAG_NAME, '录屏启动成功', code)
          break
        case 1005:
          logger.log(TAG_NAME, '推流动态调整分辨率', code)
          break
        case 1006:
          logger.log(TAG_NAME, '推流动态调整码率', code)
          break
        case 1007:
          logger.log(TAG_NAME, '首帧画面采集完成', code)
          break
        case 1008:
          logger.log(TAG_NAME, '编码器启动', code)
          break
        case 2003:
          logger.log(TAG_NAME, '渲染首帧视频', code)
          break
        case -1301:
          logger.error(TAG_NAME, '打开摄像头失败: ', code)
          try {
            logger.log('尝试手动开启摄像头...')
            this.operateMyAVStream('video', true)
          } catch (error) {
            logger.error(TAG_NAME, error)
          }
          break
        case -1302:
          logger.error(TAG_NAME, '打开麦克风失败: ', code)
          break
        case -1303:
          logger.error(TAG_NAME, '视频编码失败: ', code)
          break
        case -1304:
          logger.error(TAG_NAME, '音频编码失败: ', code)
          break
        case -1307:
          logger.error(TAG_NAME, '推流连接断开: ', code)
          try {
            const { video, audio } = this.data.myInfo
            logger.log('尝试手动重连...', { video, audio })
            if (video) {
              this.operateMyAVStream('video', true)
            } else if (audio) {
              this.operateMyAVStream('audio', true)
            }
          } catch (error) {
            logger.error(TAG_NAME, '手动重连异常: ', error)
          }
          this._updateMyInfo()
          break
        case 5000:
          logger.log(TAG_NAME, '小程序被挂起: ', code)
          // 20200421 iOS 微信点击胶囊圆点会触发该事件
          // 触发 5000 后，底层SDK会退房，返回前台后会自动进房
          break
        case 5001:
          // 20200421 仅有 Android 微信会触发该事件
          logger.log(TAG_NAME, '小程序悬浮窗被关闭: ', code)
          break
        case 1021:
          logger.log(TAG_NAME, '网络类型发生变化，需要重新进房', code)
          break
        case 2007:
          logger.log(TAG_NAME, '本地视频播放loading: ', code)
          break
        case 2004:
          logger.log(TAG_NAME, '本地视频播放开始: ', code)
          break
        default:
          logger.log(TAG_NAME, message, code)
          break
      }
    },

    // pusher渲染错误事件
    _pusherErrorHandler(event) {
      logger.log(TAG_NAME, '_pusherErrorHandler', event)
      // 未开启摄像头或者麦克风权限:需要关闭音视频按钮
      if (event.detail.errCode === 10001 || event.detail.errCode === 10002) {
        if (event.detail.errCode === 10001) {
          this.operateMyAVStream('video', false)
          this.setData({
            noVideoAuthSetting: true,
          })
        }
        if (event.detail.errCode === 10002) {
          this.operateMyAVStream('audio', false)
          this.setData({
            noAudioAuthSetting: true,
          })
        }

        // 温馨提示弹窗显示
        setTimeout(() => {
          this.handleOpenSetting()
        }, 1000)
      }
    },

    // 弹窗让用户打开摄像头麦克风
    handleOpenSetting() {
      logger.log(this.data.isSettingConfirm, 'this.data.isSettingConfirm')
      if (this.data.isSettingConfirm) return
      wx.showModal({
        title: '无法使用摄像头和麦克风',
        content: '该功能需要摄像头，请允许小程序访问您的摄像头和麦克风权限',
        confirmText: '前往设置',
        success: (res) => {
          if (res.confirm) {
            wx.openSetting({
              success: (res) => {
                logger.log('成功', res.authSetting)
                this.setData({
                  isSettingConfirm: false,
                  noAudioAuthSetting: false,
                  noVideoAuthSetting: false,
                })
                wx.navigateBack()
              },
              fail: (err) => {
                this.setData({
                  isSettingConfirm: false,
                })
                logger.log('失败', err)
              },
            })
          } else if (res.cancel) {
            logger.log('用户放弃授权')
            this.setData({
              isSettingConfirm: false,
              noAudioAuthSetting: true,
              noVideoAuthSetting: true,
            })
          }
        },
      })
      this.setData({
        isSettingConfirm: true,
      })
    },

    // 点击离开会议
    _clickLeaveRoom(event) {
      const affirm = event.detail.value
      if (!affirm) return
      // 向外通知已经离开房间
      this.triggerEvent('leave')
      // this.leaveRoom()
    },

    _showLeaveRoomSheet() {
      this.setData({
        leaveRoomSheetShow: true,
      })
    },

    // 点击用户列表:只有开启视频的用户才能置顶
    _clickUserList(event) {
      const { accountid, name, video, isfocus, istop } =
        event.currentTarget.dataset
      // 没有开启视频&没有置顶
      if (!video && !istop) return
      // 已经置顶
      const focusSheetBtns = istop
        ? [{ text: '取消置顶', value: false }]
        : [{ text: '确认置顶', value: true }]
      this.setData({
        focusSheetBtns,
        currentUserUserId: accountid,
        currentUserIsTop: istop || '',
        currentUserIsFocus: isfocus,
        selectedUserNickName: name,
        focusSheetShow: true,
      })
    },

    // 点击置顶确认按钮
    _clickSetFocusUser(event) {
      const affirm = event.detail.value
      // logger.log(affirm, event, 'affirm')
      if (affirm) {
        this.handleSetFocusUser()
      } else {
        // 取消置顶
        this.handleCancelFocusUser()
      }
    },

    // 设置置顶视频
    handleSetFocusUser() {
      logger.log(TAG_NAME, 'handleSetFocusUser', this.data.currentUserUserId)
      // 已经是焦点视频
      if (this.data.currentUserIsFocus) {
        wx.showToast({
          title: '已在画面中展示',
          icon: 'none',
          duration: 2000,
        })
        this.setData({
          focusSheetShow: false,
        })
        return
      }
      const hasSetTopUser = this.data.userList.find((user) => user.isTop)
      // 取消已经置顶的
      if (hasSetTopUser) {
        this._updateUserById({ isTop: false }, hasSetTopUser.accountId).then(
          () => {
            this._updateUserById(
              { isTop: true },
              this.data.currentUserUserId
            ).then(() => {
              this._sortUserList()
            })
          }
        )
      } else {
        this._updateUserById({ isTop: true }, this.data.currentUserUserId).then(
          () => {
            this._sortUserList()
          }
        )
      }
      this.setData({
        focusSheetShow: false,
      })
      this.localTopUserId = this.data.currentUserUserId
      wx.showToast({
        title: '置顶成功',
        icon: 'none',
        duration: 2000,
      })
    },

    // 取消置顶视频
    handleCancelFocusUser() {
      logger.log(TAG_NAME, 'handleCancelFocusUser', this.data.currentUserUserId)
      this._updateUserById({ isTop: false }, this.data.currentUserUserId).then(
        () => {
          this._sortUserList()
        }
      )
      this.setData({
        currentUserUserId: '',
        currentUserIsTop: '',
        currentUserIsFocus: '',
        selectedUserNickName: '',
        focusSheetShow: false,
      })
      this.localTopUserId = ''
      wx.showToast({
        title: '已取消置顶',
        icon: 'none',
        duration: 2000,
      })
    },

    // 打开会议详情弹窗
    _handleOpenInfoDialog() {
      this.setData({
        meetingInfoDialogShow: true,
      })
    },

    // 打开成员列表弹窗
    handleShowUserList() {
      if (!this.data.userList.length) return
      this.setData({
        memberListDialogShow: true,
      })
    },

    /**
     * 复制会议id
     */
    handleCopy(event) {
      wx.setClipboardData({
        data: event.currentTarget.dataset.copy,
      })
    },
    // TODO:是否需要提示
    _connectionStateChange(_data) {
      logger.debug('_connectionStateChange() 网络状态发生了变化: %o %t', _data)
      if (!this._isActive) {
        return
      }
      if (_data && _data.curState === 'DISCONNECTED') {
        logger.error('检测到网络中断 %t')
        this.triggerEvent('networkError')
        if (_data.prevState === 'CONNECTING') {
          logger.log('rtc重连失败，离开房间')
          this.triggerEvent('leave')
        }
      } else if (_data && _data.curState === 'CONNECTING') {
        logger.debug('正在重连中 %t')
        this.triggerEvent('networkReconnect')
      } else if (
        (_data &&
          _data.prevState === 'CONNECTED' &&
          _data &&
          _data.curState === 'CONNECTED') ||
        (_data &&
          _data.prevState === 'CONNECTING' &&
          _data &&
          _data.curState === 'CONNECTED')
      ) {
        logger.debug('重连成功 %t')
        logger.debug('join() %t')
        this.triggerEvent('networkSuccess')
      }
    },

    async _subscribeRemoteStream() {
      const remoteMembers = this.data.userList.filter(
        (user) => user.accountId !== this.data.myUuid
      )
      logger.log(TAG_NAME, '_subscribeRemoteStream ', remoteMembers)
      remoteMembers.map(async (member) => {
        if (member.screenSharing === 1) {
          // 有共享画面
          // if (member.main) { // 如果是主屏幕则订阅播放共享画面
          this.playRemoteSubVideo(member.accountId)
          // } else { // 如果是非主屏且画面开启则订阅视频画面
          //   if (member.video === 1) {
          //     this.playRemoteVideo(member.accountId, member.main ? 0 : 1);
          //   }
          // }
        } else if (member.video === 1) {
          this.playRemoteVideo(member.accountId, 'video')
        } else if (member.audio === 1) {
          this.playRemoteVideo(member.accountId, 'audio')
        }
      })
    },

    playRemoteVideo(userId, streamType) {
      logger.log(TAG_NAME, 'playRemoteVideo ', { userId, streamType })
      this.rtcController.setupRemoteStreamContext(userId, 'video', this)
      this.rtcController.subscribeRemoteVideoStream(userId, streamType)
    },

    playRemoteSubVideo(userId) {
      logger.log(TAG_NAME, 'playRemoteSubVideo ', { userId })
      this.rtcController.setupRemoteStreamContext(userId, 'screen', this)
      this.rtcController.subscribeRemoteVideoSubStream(userId)
    },

    // 被踢出
    _onKicked(data) {
      logger.log(TAG_NAME, '_onKicked', data)
      wx.showToast({
        title: '因被主持人移出或切换至其他设备，您已退出会议',
        icon: 'none',
        duration: 2000,
      })
      this._roomService.destroy()
      this.triggerEvent('kicked')
    },
    // 成员角色变更
    _onMemberRoleChanged(member, beforeRole, afterRole) {
      if (this.data.myUuid === member.uuid) {
        this.setData({
          'myInfo.role': member.role,
        })
        if (member.role === Role.host) {
          wx.showToast({
            title: '您已经成为主持人',
            icon: 'none',
          })
        }
        if (member.role === Role.coHost) {
          wx.showToast({
            title: '您已经成为联席主持人',
            icon: 'none',
          })
        }
        if (beforeRole.name === Role.coHost && afterRole.name !== Role.host) {
          wx.showToast({
            title: '已被取消设为联席主持人',
            icon: 'none',
          })
        }
      } else {
        // 如果本端是主持人或者联席主持人则收到设置联席主持人的通知
        if (
          this.data.myInfo.role === Role.coHost ||
          this.data.myInfo.role === Role.host
        ) {
          const _member = this.members.find((item) => item.uuid === member.uuid)
          console.log(_member, '_member')
          if (member.role == Role.coHost) {
            // 如果是设置联席主持人通知
            wx.showToast({
              title: _member.nickName + '已经成为' + RoleName[Role.coHost],
              icon: 'none',
            })
          } else if (
            member.role !== Role.coHost &&
            _member.role === Role.coHost
          ) {
            wx.showToast({
              title: _member.nickName + '已被取消设为' + RoleName[Role.coHost],
              icon: 'none',
            })
          }
        }
      }
      // 更新主持人
      if (afterRole.name === Role.host) {
        this.hostUuid = member.uuid
        this.hostNickName = member.name
        this.setData({
          hostNickName: member.name,
        })
      }
      // 更新角色
      this._updateUserById({ role: afterRole.name }, member.uuid)
    },

    setChatRoomInfo(chatController, nickName, tagInfo) {
      console.log('-----------------origin member--------------', this.members)
      this.setData({
        chatRoomController: {
          enterChatRoom: chatController.joinChatroom.bind(chatController),
          exitChatRoom: chatController.leaveChatroom.bind(chatController),
          getMembers: this.members.filter(
            (item) => item.accountId !== this.data.myUuid
          ),
          sendBroadcastTextMessage:
            chatController.sendBroadcastTextMessage.bind(chatController),
          sendGroupTextMessage:
            chatController.sendGroupTextMessage.bind(chatController),
          resendTextMessage:
            chatController.resendTextMessage.bind(chatController),
          getHistoryMsgs: chatController.getHistoryMsgs.bind(chatController),
        },
        chatRoomInfo: {
          //chatroomId: roomInfo.chatRoomId,
          chatroomNick: nickName,
          tagInfo,
          imAccid: this.data.myUuid,
          isPrivatization: this.isPrivatization,
        },
      })
    },
    toggleChatRoom() {
      // console.log('this.data.chatRoomInfo', this.data.chatRoomInfo)
      if (!this.data.chatRoomInfo || !this.data.chatRoomController) {
        wx.showToast({
          title: '正在初始化请稍后',
          icon: 'none',
        })
        return
      }
      this.setData({
        showChatRoom: true,
      })
    },
    onChatRoomClose() {
      this.setData({
        showChatRoom: false,
      })
    },
    onChatRoomEnter() {
      // 删除该方法则聊天室无滑入动画效果
    },
    onUnReadChange(data) {
      this.setData({
        unReadCount: data.detail,
      })
    },

    // 焦点视频状态更新
    _onRoomPropertiesChanged({ focus, audioOff, videoOff }) {
      // 焦点更新
      if (focus) {
        const focusUuid = focus.value
        this.focusUuid = focusUuid
        logger.log('event: 更新焦点视频', focusUuid)
        // 去除原先的focus
        this._cancelFocus().then(() => {
          // 设置焦点
          if (focusUuid) {
            const isMySelf = focusUuid === this.data.myUuid
            if (isMySelf) {
              wx.showToast({
                title: focusUuid
                  ? '您已被设置为焦点视频'
                  : '您已被取消焦点视频',
                icon: 'none',
                duration: 2000,
              })
            }
            this._updateUserById({ isFocus: true }, focusUuid).then(() => {
              logger.log('设置焦点视频用户:', focusUuid)
              this._sortUserList()
            })
          }
        })
      } else if (audioOff) {
        const value = audioOff.value?.split('_')[0]
        this.openAudioByHost = false
        this.getMeetingInfo()
        switch (value) {
          case AttendeeOffType.offNotAllowSelfOn:
          case AttendeeOffType.offAllowSelfOn:
            if (
              this.data.myInfo.role !== Role.host &&
              this.data.myInfo.role !== Role.coHost
            ) {
              wx.showToast({
                title: '主持人设置了全体静音',
                icon: 'none',
                duration: 2000,
              })
            }
            // 已关闭音频则不操作
            if (
              this.data.myInfo.audio !== 1 ||
              this.data.myInfo.role === Role.host ||
              this.data.myInfo.role === Role.coHost
            ) {
              return
            }
            this.operateMyAVStream('audio', false)
            break
          case AttendeeOffType.disable: // 解除静音
            // 已开启音频则不操作
            if (
              this.data.myInfo.audio === 1 ||
              this.data.myInfo.role === Role.host ||
              this.data.myInfo.role === Role.coHost
            ) {
              return
            }
            this.myAudioBeOpened()
            break
        }
      } else if (videoOff) {
        const value = videoOff.value?.split('_')[0]
        this.openVideoByHost = false
        this.getMeetingInfo()
        switch (value) {
          case AttendeeOffType.offNotAllowSelfOn:
          case AttendeeOffType.offAllowSelfOn:
            if (
              this.data.myInfo.role !== Role.host &&
              this.data.myInfo.role !== Role.coHost
            ) {
              wx.showToast({
                title: '主持人设置了全体关闭视频',
                icon: 'none',
                duration: 2000,
              })
            }
            // 已关闭音频则不操作
            if (
              this.data.myInfo.video !== 1 ||
              this.data.myInfo.role === Role.host ||
              this.data.myInfo.role === Role.coHost
            ) {
              return
            }
            this.operateMyAVStream('video', false)
            break
          case AttendeeOffType.disable: // 解除静音
            // 已开启音频则不操作
            if (
              this.data.myInfo.video === 1 ||
              this.data.myInfo.role === Role.host ||
              this.data.myInfo.role === Role.coHost
            ) {
              return
            }
            this.myVideoBeOpened()
            break
        }
      }
    },
    // 取消焦点视频
    _cancelFocus() {
      return new Promise((resolve, reject) => {
        const user = this.data.userList.find((user) => {
          return user.isFocus
        })
        if (user) {
          this._updateUserById({ isFocus: false }, user.accountId).then(() => {
            this._sortUserList()
            resolve()
          })
        } else {
          resolve()
        }
        logger.log('取消焦点视频用户:', user)
      })
    },
    _onRoomHostChanged() {
      logger.log('event: 更新主持人')
      this.getMeetingInfo()
    },

    _updateUserById(data, accountId) {
      // logger.log('开始_updateUserById', data, accountId)
      return new Promise((resolve, reject) => {
        logger.log(TAG_NAME, '_updateUserById', {
          data,
          accountId,
        })
        let userList = this.data.userList
        // todo: streamAdd事件先于setList时
        if (!userList.length) {
          this.getAllUserList()
        }
        const index = userList.findIndex((user) => {
          return user && user.accountId === accountId
        })
        if (index < 0) {
          resolve()
          return
        }
        if (data.stream) {
          data.stream = { ...userList[index].stream, ...data.stream }
        }
        const keys = Object.keys(data)
        let key = ''
        let result = null
        if (keys.length === 1) {
          key = `userList[${index}].${keys[0]}`
          result = data[keys[0]]
        } else {
          key = `userList[${index}]`
          result = { ...userList[index], ...data }
        }
        // 更新this.members数据
        this.members = userList
        this.setData(
          {
            [key]: result,
          },
          () => {
            resolve()
          }
        )
      })
    },
    _offlineHandle() {
      wx.onNetworkStatusChange((res) => {
        if (this.data.isConnected && res.isConnected) {
          // 已经是联网状态且最新状态也是联网不操作
          return
        }
        if (this.data.isConnected && !res.isConnected) {
          // 断网开始计时，计时器，0-10s重连成功则保留，10s-50s左右等待联网成功退出或继续等待，50s及以上rtc会断连退出
          this.data.disconnectTime = new Date().getTime()
          console.log('断网时刻', this.data.disconnectTime)
        }
        this.setData({
          isConnected: res.isConnected,
        })
        this._leaveByOffline(res.isConnected)
        if (res.isConnected) {
          // 断连后恢复
          if (this.data.disconnectTime) {
            // 1. 如果在0-10s内重连成功则正常往下走
            console.log(
              '断网后重连间隔',
              (new Date().getTime() - this.data.disconnectTime) / 1000
            )
            if ((new Date().getTime() - this.data.disconnectTime) / 1000 > 20) {
              // 2.如果重连时间超过超过10s的话，联网后手动退出，以免推拉流异常
              wx.showToast({
                title: '请重新加入房间',
                icon: 'none',
                duration: 1500,
              })
              this.data.disconnectTime = 0
              this.triggerEvent('leave')
              return
            }
          }
          this.retryRemoteStream()

          // 更新状态
          if (this.data.hasHided) {
            // 恢复网络后保持原有onHide逻辑
            this.muteMyMedia()
              .then(() => {
                this.onShowToast()
              })
              .catch((err) => {
                logger.error(err, 'muteMyMedia error')
                setTimeout(() => {
                  this.muteMyMedia()
                }, 1500)
              })
          }
          // logger.log('联网，更新状态')
          // this.getMeetingInfo().then(() => {
          //   logger.log('获取meetingInfo完成')
          //   this._updateStreamByOffline()
          // })
        }
      })
    },
    _leaveByOffline(isConnected) {
      wx.showToast({
        title: isConnected ? '当前网络已恢复' : '当前网络已断开',
        icon: 'none',
        duration: 1500,
      })
    },

    getDeviceId() {
      let uuid = RoomKitMiniappSDK.getDeviceId()
      if (uuid) {
        return uuid
      } else {
        uuid = uuid()
        wx.setStorageSync('NERoomkit-uuid', uuid)
      }
      return uuid
    },
    // _playerNetStatus(event) {
    //   // console.log('_playerNetStatus   ', event)
    // },

    // 操作本人的音视频
    async operateMyAVStream(type, isOpen) {
      if (!this.rtcController) return
      logger.log(TAG_NAME, 'operateMyAVStream', { type, isOpen })
      try {
        if (type === 'video' && isOpen) await this.rtcController.unmuteMyVideo()
        if (type === 'video' && !isOpen) await this.rtcController.muteMyVideo()
        if (type === 'audio' && isOpen) await this.rtcController.unmuteMyAudio()
        if (type === 'audio' && !isOpen) await this.rtcController.muteMyAudio()
      } catch (error) {
        logger.log(error)
        // 只对用户手动操作的异常进行提示
        if (this.data.btnVideoLoading) {
          wx.showToast({
            title: '摄像头操作失败',
            icon: 'none',
            duration: 2000,
          })
          this.setData({
            btnVideoLoading: false,
          })
        }
        if (this.data.btnAudioLoading) {
          wx.showToast({
            title: '麦克风操作失败',
            icon: 'none',
            duration: 2000,
          })
          this.setData({
            btnAudioLoading: false,
          })
        }
      }
    },
  },
})
