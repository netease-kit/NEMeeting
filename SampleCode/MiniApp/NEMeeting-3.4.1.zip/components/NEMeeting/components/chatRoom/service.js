import { logger } from '../../../NEChatRoomUI/utils/logger'
import { formatDate } from '../../utils/index'
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function getHistoryService(
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  request,
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  imAccid,
  options = {
    limit: 100,
    reverse: true,
  }
) {
  return request
    .getHistoryMsgs(options)
    .then((res) => {
      console.log('--------------getHistoryMsgs--------------', res)
      let msgs = res.data.msgs
      return msgs
        .filter((msg) => {
          return (
            msg.type !== 'notification' ||
            (msg.type === 'notification' && msg.text)
          )
        })
        .map((msg) => {
          msg = formateMsg(msg, imAccid)
          return msg
        })
    })
    .catch((err) => {
      console.log('--------------getHistoryMsgs err--------------', err)
    })
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export async function getMemberServices(request, imAccid) {
  const members = (
    await Promise.all([
      _getMembers(request, { guest: true, limit: 2000 }),
      _getMembers(request, { guest: false, limit: 10 }),
    ])
  ).flat()
  const res = parseMemberInfo(
    members.filter((item) => item.account !== imAccid && item.online)
  )
  return res
}

function parseMemberInfo(members) {
  return members.map((item) => {
    // TODO 这里IM SDK获取用户信息居然没有返回tags，先把tags传入到custom字段hack一下，后面需要SDK修改后再去掉
    let tags = []
    try {
      tags = JSON.parse(item.custom).tags
    } catch (e) {
      tags = []
    }
    return {
      ...item,
      //tags: tags && tags.length ? tags : ['未分类'],
    }
  })
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function _getMembers(request, options) {
  return request.getMembers(options)
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function handleRecMsgService(msgs) {
  let unReadMsgsCount = 0 // 获取未读消息
  msgs = msgs
    .filter((msg) => {
      if (msg.type !== 'notification') {
        unReadMsgsCount += 1
      }
      return (
        msg.type !== 'notification' || (msg.type === 'notification' && msg.text)
      )
    })
    .map((msg) => {
      msg = formateMsg(msg)
      return msg
    })
  return {
    msgs,
    unReadMsgsCount,
  }
}

export function formateMsg(msg, myAccountId) {
  msg.time = formatDate(msg.time, 'yyyy-MM-dd hh:mm:ss')
  msg.fromAvatar = msg.fromAvatar || ''
  myAccountId && (msg.isMe = msg.from === myAccountId)
  return msg
}
const handleMap = {
  orientation: (request, params) => {
    logger.log('params', params)
    return request
      .sendGroupTextMessage(params.toAccids, params.text)
      .then((res) => {
        return res.data
      })
      .catch((err) => {
        return err
      })
  },
  group: (request, params) => {
    logger.log('params', params)
    console.log('-------group.parmas.text----------', params.text)
    return request
      .sendBroadcastTextMessage(params.text)
      .then((res) => {
        return res.data
      })
      .catch((err) => {
        return err
      })
  },
  resend: (request, params) => {
    logger.log('params', params)
    console.log('-------group.parmas.text----------', params.text)
    return request
      .resendTextMessage(params.text, params.idClient, params.toAccids)
      .then((res) => {
        return res.data
      })
      .catch((err) => {
        return err
      })
  },
}
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function handleSendMsgService(request, params) {
  return handleMap[params.type](request, params)
}
