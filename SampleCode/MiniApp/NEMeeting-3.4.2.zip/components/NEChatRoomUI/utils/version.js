const version = '3.4.2'

export default version
