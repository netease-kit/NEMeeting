import version from './version'

export const uuid = () => {
  const key = 'wyyx__meeting__uuid'
  let res = wx.getStorageSync(key)
  if (!res) {
    res = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = (Math.random() * 16) | 0
      const v = c === 'x' ? r : (r & 0x3) | 0x8
      return v.toString(16)
    })
    wx.setStorageSync(key, res)
  }
  return res
}

export const requestId = () => `${+new Date() + uuid()}_id`

export const toast = (title, icon = 'none', duration, options) => {
  wx.showToast({
    title: title || '',
    icon: icon,
    image: (options && options.image) || '',
    duration: duration || 2000,
    mask: false,
  })
}

export const compareVersion = (curVersion = '', target = '') => {
  const cur = curVersion.split('.')
  const targets = target.split('.')

  if (cur.length !== 3 || targets.length !== 3) {
    return false
  }

  return cur.reduce((p, c, index) => {
    const _c = Number(c)
    const _t = Number(targets[index])

    if (_c < _t) {
      return p && false
    }

    if (_c >= _t) {
      return p && true
    }
  }, true)
}

export const parseAttachExt = (attachExt) => {
  try {
    attachExt = JSON.parse(attachExt)
    const { version, channelName } = attachExt
    if (version && channelName && compareVersion(version, '1.1.0')) {
      return attachExt
    }
    return false
  } catch (error) {
    return false
  }
}

export const prevent = (fn, delay) => {
  let last = 0
  return function (...args) {
    const cur = Date.now()
    if (cur - last > delay) {
      fn.apply(this, args)
      last = cur
    }
  }
}

/**
 * 是否为iphoneX系列（带有底部bar）
 */
export const isIphoneX = () => {
  let model =
    wx.getSystemInfoSync().model && wx.getSystemInfoSync().model.toLowerCase()
  if (
    model.indexOf('iphone x') > -1 ||
    model.indexOf('iphone 11') > -1 ||
    model.indexOf('iphone 12') > -1 ||
    (model.indexOf('unknown') > -1 && model.indexOf('iphone') > -1)
  ) {
    return true
  } else {
    return false
  }
}

/**
 * "yyyy-MM-dd hh:mm:ss.S" ==> 2006-07-02 08:09:04.423
 * "yyyy-M-d h:m:s.S"      ==> 2006-7-2 8:9:4.18
 */
export function formatDate(date, fmt = 'yyyy-MM-dd hh:mm:ss') {
  if (!date) {
    return
  }
  date = new Date(date)
  var o = {
    'M+': date.getMonth() + 1, //月份
    'd+': date.getDate(), //日
    'h+': date.getHours(), //小时
    'H+': date.getHours(), //小时
    'm+': date.getMinutes(), //分
    's+': date.getSeconds(), //秒
    'q+': Math.floor((date.getMonth() + 3) / 3), //季度
    S: date.getMilliseconds(), //毫秒
  }
  var week = {
    0: '/u65e5',
    1: '/u4e00',
    2: '/u4e8c',
    3: '/u4e09',
    4: '/u56db',
    5: '/u4e94',
    6: '/u516d',
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(
      RegExp.$1,
      (date.getFullYear() + '').substr(4 - RegExp.$1.length)
    )
  }
  if (/(E+)/.test(fmt)) {
    fmt = fmt.replace(
      RegExp.$1,
      (RegExp.$1.length > 1
        ? RegExp.$1.length > 2
          ? '/u661f/u671f'
          : '/u5468'
        : '') + week[date.getDay() + '']
    )
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      )
    }
  }
  return fmt
}

// 发请求
export const sendRequest = (params) => {
  return new Promise((resolve, reject) => {
    wx.request({
      url: params.url,
      data: params.data,
      header: {
        clientType: 'miniApp',
        versionCode: '1.1.0',
        'content-type': 'application/json;charset=utf-8',
        ...params.header,
      },
      method: params.method || 'POST',
      success: (res) => {
        if (res.data.code !== 0) {
          return reject(res.data)
        }
        resolve(res.data.data)
      },
      fail: reject,
    })
  })
}

export const RoleType = {
  participant: 1, // 参会者
  host: 2, // 主持人
  coHost: 3, // 联席主持人
}

export const Role = {
  participant: 'member', // 参会者
  host: 'host', // 主持人
  coHost: 'cohost', // 联席主持人
  ghost: 'ghost', // 影子用户
}

export const RoleName = {
  participant: '参会者',
  host: '主持人',
  coHost: '联席主持人',
  ghost: '影子用户',
}

export const AttendeeOffType = {
  offNotAllowSelfOn: 'offNotAllowSelfOn', // 开启[全体关闭视频], 允许自行打开
  offAllowSelfOn: 'offAllowSelfOn', // 开启[全体关闭视频]，不允许自行打开
  disable: 'disable', // 关闭[全体关闭视频]按钮
}

// 处理member数据
export const _generateMember = (member) => {
  member = { ...member }
  member.video = member.isVideoOn ? 1 : 0
  member.audio = member.isAudioOn ? 1 : 0
  member.screenSharing = member.isSharingScreen ? 1 : 0
  member.isFocus = !!member.isFocus
  member.isTop = !!member.isTop
  member.volume = member.volume || 0
  member.whiteBoardShare = member.isSharingWhiteboard ? 1 : 0
  member.accountId = member.uuid
  member.userId = member.uuid
  member.nickName = member.name
  member.uid = member.uuid
  member.role = member.role.name
  member.isHost = member.role === Role.host
  member.handsUps = member.properties ? member.properties.handsUp : { value: 0 }
  member.memberTag = member.properties ? member.properties.tag?.value || '' : ''
  member.tags =
    member.properties &&
    member.properties.chatroomTag &&
    member.properties.chatroomTag.value
      ? JSON.parse(member.properties.chatroomTag.value)
      : ['未分类']
  member.chatroomTag =
    member.properties &&
    member.properties.chatroomTag &&
    member.properties.chatroomTag.value
      ? JSON.parse(member.properties.chatroomTag.value)
      : ['未分类']
  member.whiteBoardInteract = member.properties
    ? member.properties.wbDrawable
      ? member.properties.wbDrawable.value
      : '0'
    : '0'
  member.stream = member.miniAppStreamInfo
  member.hostName = member.role === Role.host ? '主持人' : ''
  member.cohostName = member.role === Role.coHost ? '联席主持人' : ''
  member.isInChatroom = member.isInRtcChannel // 会议场景下加入rtc即加入聊天室
  return member
}
